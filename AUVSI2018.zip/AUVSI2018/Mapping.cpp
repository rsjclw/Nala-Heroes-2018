#include "Mapping.h"

Mapping::Mapping(QObject *parent)
	: QObject(parent)
{
	
}

Mapping::~Mapping()
{
}




