/********************************************************************************
** Form generated from reading UI file 'MainWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.7.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include <kliklabelmappping.h>
#include "clickablelabel.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionSave;
    QAction *actionSave_As;
    QAction *actionOpen;
    QWidget *centralwidget;
    QTabWidget *tabWidget;
    QWidget *tabCamera;
    QPushButton *startButton;
    ClickableLabel *labelOri;
    QPushButton *stopButton;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_10;
    QComboBox *warnaSelector;
    QStackedWidget *stackedWidget;
    QWidget *warna1;
    QWidget *layoutWidget_2;
    QVBoxLayout *verticalLayout;
    QLabel *labelWarna1;
    QFormLayout *formLayout;
    QVBoxLayout *verticalLayout_2;
    QLabel *label;
    QHBoxLayout *horizontalLayout;
    QSlider *hMin1;
    QLabel *hMinVal1;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_2;
    QHBoxLayout *horizontalLayout_2;
    QSlider *hMax1;
    QLabel *hMaxVal1;
    QVBoxLayout *verticalLayout_6;
    QLabel *label_5;
    QHBoxLayout *horizontalLayout_5;
    QSlider *sMin1;
    QLabel *sMinVal1;
    QVBoxLayout *verticalLayout_7;
    QLabel *label_6;
    QHBoxLayout *horizontalLayout_6;
    QSlider *sMax1;
    QLabel *sMaxVal1;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_3;
    QHBoxLayout *horizontalLayout_3;
    QSlider *vMin1;
    QLabel *vMinVal1;
    QVBoxLayout *verticalLayout_5;
    QLabel *label_4;
    QHBoxLayout *horizontalLayout_4;
    QSlider *vMax1;
    QLabel *vMaxVal1;
    QVBoxLayout *verticalLayout_9;
    QLabel *label_8;
    QHBoxLayout *horizontalLayout_8;
    QSlider *erode1;
    QLabel *erodeVal1;
    QVBoxLayout *verticalLayout_8;
    QLabel *label_7;
    QHBoxLayout *horizontalLayout_7;
    QSlider *dilate1;
    QLabel *dilateVal1;
    QWidget *warna2;
    QWidget *layoutWidget_3;
    QVBoxLayout *verticalLayout_29;
    QLabel *labelWarna2;
    QFormLayout *formLayout_4;
    QVBoxLayout *verticalLayout_30;
    QLabel *label_25;
    QHBoxLayout *horizontalLayout_25;
    QSlider *hMin2;
    QLabel *hMinVal2;
    QVBoxLayout *verticalLayout_31;
    QLabel *label_26;
    QHBoxLayout *horizontalLayout_26;
    QSlider *hMax2;
    QLabel *hMaxVal2;
    QVBoxLayout *verticalLayout_32;
    QLabel *label_27;
    QHBoxLayout *horizontalLayout_27;
    QSlider *sMin2;
    QLabel *sMinVal2;
    QVBoxLayout *verticalLayout_33;
    QLabel *label_28;
    QHBoxLayout *horizontalLayout_28;
    QSlider *sMax2;
    QLabel *sMaxVal2;
    QVBoxLayout *verticalLayout_34;
    QLabel *label_29;
    QHBoxLayout *horizontalLayout_29;
    QSlider *vMin2;
    QLabel *vMinVal2;
    QVBoxLayout *verticalLayout_35;
    QLabel *label_30;
    QHBoxLayout *horizontalLayout_30;
    QSlider *vMax2;
    QLabel *vMaxVal2;
    QVBoxLayout *verticalLayout_36;
    QLabel *label_31;
    QHBoxLayout *horizontalLayout_31;
    QSlider *erode2;
    QLabel *erodeVal2;
    QVBoxLayout *verticalLayout_37;
    QLabel *label_32;
    QHBoxLayout *horizontalLayout_32;
    QSlider *dilate2;
    QLabel *dilateVal2;
    QWidget *warna3;
    QWidget *layoutWidget_4;
    QVBoxLayout *verticalLayout_11;
    QLabel *labelWarna3;
    QFormLayout *formLayout_2;
    QVBoxLayout *verticalLayout_12;
    QLabel *label_9;
    QHBoxLayout *horizontalLayout_9;
    QSlider *hMin3;
    QLabel *hMinVal3;
    QVBoxLayout *verticalLayout_13;
    QLabel *label_10;
    QHBoxLayout *horizontalLayout_10;
    QSlider *hMax3;
    QLabel *hMaxVal3;
    QVBoxLayout *verticalLayout_14;
    QLabel *label_11;
    QHBoxLayout *horizontalLayout_11;
    QSlider *sMin3;
    QLabel *sMinVal3;
    QVBoxLayout *verticalLayout_15;
    QLabel *label_12;
    QHBoxLayout *horizontalLayout_12;
    QSlider *sMax3;
    QLabel *sMaxVal3;
    QVBoxLayout *verticalLayout_16;
    QLabel *label_13;
    QHBoxLayout *horizontalLayout_13;
    QSlider *vMin3;
    QLabel *vMinVal3;
    QVBoxLayout *verticalLayout_17;
    QLabel *label_14;
    QHBoxLayout *horizontalLayout_14;
    QSlider *vMax3;
    QLabel *vMaxVal3;
    QVBoxLayout *verticalLayout_18;
    QLabel *label_15;
    QHBoxLayout *horizontalLayout_15;
    QSlider *erode3;
    QLabel *erodeVal3;
    QVBoxLayout *verticalLayout_19;
    QLabel *label_16;
    QHBoxLayout *horizontalLayout_16;
    QSlider *dilate3;
    QLabel *dilateVal3;
    QWidget *warna4;
    QWidget *layoutWidget_5;
    QVBoxLayout *verticalLayout_38;
    QLabel *labelWarna4;
    QFormLayout *formLayout_5;
    QVBoxLayout *verticalLayout_39;
    QLabel *label_33;
    QHBoxLayout *horizontalLayout_33;
    QSlider *hMin4;
    QLabel *hMinVal4;
    QVBoxLayout *verticalLayout_40;
    QLabel *label_34;
    QHBoxLayout *horizontalLayout_34;
    QSlider *hMax4;
    QLabel *hMaxVal4;
    QVBoxLayout *verticalLayout_41;
    QLabel *label_35;
    QHBoxLayout *horizontalLayout_35;
    QSlider *sMin4;
    QLabel *sMinVal4;
    QVBoxLayout *verticalLayout_42;
    QLabel *label_36;
    QHBoxLayout *horizontalLayout_36;
    QSlider *sMax4;
    QLabel *sMaxVal4;
    QVBoxLayout *verticalLayout_43;
    QLabel *label_37;
    QHBoxLayout *horizontalLayout_37;
    QSlider *vMin4;
    QLabel *vMinVal4;
    QVBoxLayout *verticalLayout_44;
    QLabel *label_38;
    QHBoxLayout *horizontalLayout_38;
    QSlider *vMax4;
    QLabel *vMaxVal4;
    QVBoxLayout *verticalLayout_45;
    QLabel *label_39;
    QHBoxLayout *horizontalLayout_39;
    QSlider *erode4;
    QLabel *erodeVal4;
    QVBoxLayout *verticalLayout_46;
    QLabel *label_40;
    QHBoxLayout *horizontalLayout_40;
    QSlider *dilate4;
    QLabel *dilateVal4;
    QWidget *warna5;
    QWidget *layoutWidget_6;
    QVBoxLayout *verticalLayout_47;
    QLabel *labelWarna5;
    QFormLayout *formLayout_6;
    QVBoxLayout *verticalLayout_48;
    QLabel *label_41;
    QHBoxLayout *horizontalLayout_41;
    QSlider *hMin5;
    QLabel *hMinVal5;
    QVBoxLayout *verticalLayout_49;
    QLabel *label_42;
    QHBoxLayout *horizontalLayout_42;
    QSlider *hMax5;
    QLabel *hMaxVal5;
    QVBoxLayout *verticalLayout_50;
    QLabel *label_43;
    QHBoxLayout *horizontalLayout_43;
    QSlider *sMin5;
    QLabel *sMinVal5;
    QVBoxLayout *verticalLayout_51;
    QLabel *label_44;
    QHBoxLayout *horizontalLayout_44;
    QSlider *sMax5;
    QLabel *sMaxVal5;
    QVBoxLayout *verticalLayout_52;
    QLabel *label_45;
    QHBoxLayout *horizontalLayout_45;
    QSlider *vMin5;
    QLabel *vMinVal5;
    QVBoxLayout *verticalLayout_53;
    QLabel *label_46;
    QHBoxLayout *horizontalLayout_46;
    QSlider *vMax5;
    QLabel *vMaxVal5;
    QVBoxLayout *verticalLayout_54;
    QLabel *label_47;
    QHBoxLayout *horizontalLayout_47;
    QSlider *erode5;
    QLabel *erodeVal5;
    QVBoxLayout *verticalLayout_55;
    QLabel *label_48;
    QHBoxLayout *horizontalLayout_48;
    QSlider *dilate5;
    QLabel *dilateVal5;
    QWidget *warna6;
    QWidget *layoutWidget_7;
    QVBoxLayout *verticalLayout_56;
    QLabel *labelWarna5_2;
    QFormLayout *formLayout_7;
    QVBoxLayout *verticalLayout_57;
    QLabel *label_56;
    QHBoxLayout *horizontalLayout_49;
    QSlider *hMin6;
    QLabel *hMinVal6;
    QVBoxLayout *verticalLayout_58;
    QLabel *label_57;
    QHBoxLayout *horizontalLayout_53;
    QSlider *hMax6;
    QLabel *hMaxVal6;
    QVBoxLayout *verticalLayout_59;
    QLabel *label_61;
    QHBoxLayout *horizontalLayout_54;
    QSlider *sMin6;
    QLabel *sMinVal6;
    QVBoxLayout *verticalLayout_60;
    QLabel *label_123;
    QHBoxLayout *horizontalLayout_55;
    QSlider *sMax6;
    QLabel *sMaxVal6;
    QVBoxLayout *verticalLayout_61;
    QLabel *label_124;
    QHBoxLayout *horizontalLayout_56;
    QSlider *vMin6;
    QLabel *vMinVal6;
    QVBoxLayout *verticalLayout_62;
    QLabel *label_125;
    QHBoxLayout *horizontalLayout_57;
    QSlider *vMax6;
    QLabel *vMaxVal6;
    QVBoxLayout *verticalLayout_63;
    QLabel *label_126;
    QHBoxLayout *horizontalLayout_58;
    QSlider *erode6;
    QLabel *erodeVal6;
    QVBoxLayout *verticalLayout_64;
    QLabel *label_127;
    QHBoxLayout *horizontalLayout_59;
    QSlider *dilate6;
    QLabel *dilateVal6;
    QWidget *page;
    QWidget *layoutWidget_8;
    QVBoxLayout *verticalLayout_65;
    QLabel *labelWarna5_3;
    QFormLayout *formLayout_8;
    QVBoxLayout *verticalLayout_66;
    QLabel *label_128;
    QHBoxLayout *horizontalLayout_60;
    QSlider *hMin7;
    QLabel *hMinVal7;
    QVBoxLayout *verticalLayout_67;
    QLabel *label_129;
    QHBoxLayout *horizontalLayout_61;
    QSlider *hMax7;
    QLabel *hMaxVal7;
    QVBoxLayout *verticalLayout_68;
    QLabel *label_130;
    QHBoxLayout *horizontalLayout_62;
    QSlider *sMin7;
    QLabel *sMinVal7;
    QVBoxLayout *verticalLayout_69;
    QLabel *label_131;
    QHBoxLayout *horizontalLayout_63;
    QSlider *sMax7;
    QLabel *sMaxVal7;
    QVBoxLayout *verticalLayout_70;
    QLabel *label_132;
    QHBoxLayout *horizontalLayout_64;
    QSlider *vMin7;
    QLabel *vMinVal7;
    QVBoxLayout *verticalLayout_71;
    QLabel *label_133;
    QHBoxLayout *horizontalLayout_65;
    QSlider *vMax7;
    QLabel *vMaxVal7;
    QVBoxLayout *verticalLayout_72;
    QLabel *label_134;
    QHBoxLayout *horizontalLayout_66;
    QSlider *erode7;
    QLabel *erodeVal7;
    QVBoxLayout *verticalLayout_73;
    QLabel *label_135;
    QHBoxLayout *horizontalLayout_67;
    QSlider *dilate7;
    QLabel *dilateVal7;
    QGroupBox *groupBox_13;
    QLabel *label_69;
    QLabel *label_106;
    QLabel *label_107;
    QSpinBox *spinBoxP1;
    QSpinBox *spinBoxI1;
    QSpinBox *spinBoxD1;
    QGroupBox *groupBox_14;
    QLabel *label_80;
    QLabel *label_108;
    QLabel *label_109;
    QSpinBox *spinBoxP2;
    QSpinBox *spinBoxI2;
    QSpinBox *spinBoxD2;
    QGroupBox *groupBox_15;
    QLabel *label_87;
    QLabel *label_110;
    QSpinBox *spinBoxP3;
    QLabel *label_111;
    QSpinBox *spinBoxD3;
    QSpinBox *spinBoxI3;
    QGroupBox *groupBox_16;
    QLabel *label_54;
    QSpinBox *spinBoxBatasY;
    QLabel *labelBarunastra1;
    QWidget *tabDroneConnection;
    QLabel *imgDrone;
    QLabel *labelPrediction;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout_22;
    QHBoxLayout *horizontalLayout_52;
    QLabel *label_50;
    QLineEdit *ipHP;
    QHBoxLayout *horizontalLayout_51;
    QLabel *label_51;
    QLineEdit *portHP;
    QHBoxLayout *horizontalLayout_50;
    QPushButton *buttonConnectDrone;
    QPushButton *buttonDisconnectDrone;
    QPushButton *pushButtonTakePict;
    QWidget *tab;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    kliklabelmappping *labelMapping;
    QTableWidget *tableWidgetWaypoint;
    QGroupBox *groupBox;
    QLabel *label_78;
    QLabel *label_79;
    QLineEdit *lineEditXposition;
    QLineEdit *lineEditYposition;
    QLineEdit *lineEditKondisiMouse;
    QGroupBox *groupBox_2;
    QLineEdit *lineEditTujuanLat;
    QLineEdit *lineEditTujuanLong;
    QLabel *label_81;
    QLabel *label_82;
    QLineEdit *lineEditErrorSudut;
    QLineEdit *lineEditSudutTujuan;
    QLabel *label_24;
    QLineEdit *lineEditJarak;
    QGroupBox *groupBox_12;
    QLabel *label_104;
    QLabel *label_105;
    QLineEdit *lineEditInputLatt;
    QLineEdit *lineEditInputLong;
    QPushButton *pushButtonInputWaypoint;
    QPushButton *pushButtonSetWaypoint;
    QSpinBox *spinBoxWaypoint;
    QGroupBox *groupBox_3;
    QPushButton *pushButtonSaveAsWaypoint;
    QPushButton *pushButtonSaveWaypoint;
    QPushButton *pushButtonLoadWaypoint;
    QGroupBox *groupBox_19;
    QPushButton *pushButtonStartMission;
    QPushButton *pushButtonStopMission;
    QPushButton *pushButtonReset;
    QPushButton *pushButtonRetry;
    QPushButton *pushButtonRetry2;
    QLabel *labelArahKapal;
    QLabel *label_60;
    QLCDNumber *lcdNumberWaypoint;
    QPushButton *pushButtonEast;
    QPushButton *pushButtonSouth;
    QPushButton *pushButtonWest;
    QPushButton *pushButtonNorth;
    QWidget *tab_2;
    QGroupBox *groupBox_4;
    QLabel *label_49;
    QLabel *label_52;
    QLabel *label_90;
    QSpinBox *spinBoxWaypointMisi1;
    QSpinBox *spinBoxSudutMisi1;
    QSpinBox *spinBoxSpeedMisi1;
    QLabel *label_98;
    QSpinBox *spinBoxStopMisi1;
    QGroupBox *groupBox_5;
    QLabel *label_59;
    QLabel *label_91;
    QSpinBox *spinBoxWaypointMisi2;
    QSpinBox *spinBoxSpeedMisi2;
    QLabel *label_99;
    QSpinBox *spinBoxStopMisi2;
    QGroupBox *groupBox_6;
    QLabel *label_83;
    QLabel *label_95;
    QSpinBox *spinBoxWaypointMisi3;
    QSpinBox *spinBoxSpeedMisi3;
    QLabel *label_100;
    QSpinBox *spinBoxStopMisi3;
    QLabel *label_70;
    QSpinBox *spinBoxSetpointMisi3;
    QLabel *label_72;
    QLabel *label_74;
    QSpinBox *spinBoxSpeedMisi3Atas;
    QLabel *label_84;
    QSpinBox *spinBoxWaypointMisi3_2;
    QLCDNumber *lcdNumberCounterMisi3;
    QLineEdit *lineEditStatusMisi3;
    QLabel *label_114;
    QLabel *label_115;
    QSpinBox *spinBoxSudutMisi3;
    QLabel *label_117;
    QLineEdit *lineEditDock;
    QLCDNumber *lcdNumberPenandaMisi3;
    QLabel *label_116;
    QSpinBox *spinBoxThresholdPinger;
    QSpinBox *spinBoxMaxPinger;
    QLabel *label_118;
    QLabel *label_121;
    QSpinBox *spinBoxThresholdFrequency;
    QGroupBox *groupBox_7;
    QLabel *label_86;
    QComboBox *comboBox_2;
    QLabel *label_94;
    QSpinBox *spinBoxWaypointMisi4;
    QSpinBox *spinBoxSpeedMisi4;
    QLabel *label_101;
    QSpinBox *spinBoxStopMisi4;
    QGroupBox *groupBox_8;
    QLabel *label_88;
    QLabel *label_93;
    QSpinBox *spinBoxWaypointMisi5;
    QSpinBox *spinBoxSpeedMisi5;
    QLabel *label_102;
    QSpinBox *spinBoxStopMisi5;
    QLabel *label_66;
    QSpinBox *spinBoxSpeedMisi5Bawah;
    QLabel *label_122;
    QSpinBox *spinBoxSetpointMisi5;
    QGroupBox *groupBox_9;
    QLabel *label_89;
    QLabel *label_92;
    QSpinBox *spinBoxWaypointReturn;
    QSpinBox *spinBoxSpeedReturn;
    QLabel *label_103;
    QSpinBox *spinBoxStopReturn;
    QGroupBox *groupBox_10;
    QLineEdit *lineEditMissionStatus;
    QGroupBox *groupBox_11;
    QLabel *label_58;
    QSpinBox *spinBoxSpeedNav;
    QLabel *label_96;
    QSpinBox *spinBoxServoCamera;
    QLabel *label_55;
    QSpinBox *spinBoxTrim;
    QLabel *label_73;
    QSpinBox *spinBoxServoCamera2;
    QGroupBox *groupBox_17;
    QPushButton *pushButtonOpenPort;
    QPushButton *pushButtonClosePort;
    QLabel *label_17;
    QLabel *label_20;
    QLabel *label_21;
    QLineEdit *lineEditLattitude;
    QLineEdit *lineEditLongitude;
    QLineEdit *lineEditCompass;
    QLabel *label_22;
    QLabel *label_71;
    QLabel *label_75;
    QLabel *label_76;
    QLineEdit *lineEditSRFTengah1;
    QLineEdit *lineEditSRFTengah2;
    QLineEdit *lineEditSRFKiri;
    QLineEdit *lineEditSRFKanan;
    QLabel *label_77;
    QLineEdit *lineEditFrequency;
    QLabel *label_112;
    QLabel *label_113;
    QLineEdit *lineEditAmplitudoKiri;
    QLineEdit *lineEditAmplitudoKanan;
    QLabel *label_67;
    QLineEdit *lineEditSRFSamping;
    QGroupBox *groupBox_18;
    QLabel *label_18;
    QLabel *label_19;
    QLabel *label_23;
    QLabel *label_53;
    QLineEdit *lineEditMotorKiri;
    QLineEdit *lineEditMotorKanan;
    QLineEdit *lineEditServoKiri;
    QLineEdit *lineEditServoKanan;
    QLabel *label_68;
    QLineEdit *lineEditMotorTengah;
    QGroupBox *groupBox_20;
    QLabel *label_62;
    QLabel *label_97;
    QLabel *label_63;
    QLineEdit *serverUrl;
    QLineEdit *serverIP;
    QLineEdit *serverPort;
    QLabel *label_64;
    QPushButton *btnStartConnServer;
    QPushButton *btnStopConnServer;
    QLabel *label_65;
    QLineEdit *course;
    QGroupBox *groupBox_22;
    QLabel *label_85;
    QLabel *label_119;
    QLabel *label_120;
    QSpinBox *spinBoxWaypointMisi6;
    QSpinBox *spinBoxStopMisi6;
    QSpinBox *spinBoxSpeedMisi6;
    QMenuBar *menubar;
    QMenu *menuFIle;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1317, 933);
        actionSave = new QAction(MainWindow);
        actionSave->setObjectName(QStringLiteral("actionSave"));
        actionSave_As = new QAction(MainWindow);
        actionSave_As->setObjectName(QStringLiteral("actionSave_As"));
        actionOpen = new QAction(MainWindow);
        actionOpen->setObjectName(QStringLiteral("actionOpen"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        tabWidget = new QTabWidget(centralwidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(-10, 0, 1531, 901));
        QFont font;
        font.setPointSize(8);
        tabWidget->setFont(font);
        tabCamera = new QWidget();
        tabCamera->setObjectName(QStringLiteral("tabCamera"));
        startButton = new QPushButton(tabCamera);
        startButton->setObjectName(QStringLiteral("startButton"));
        startButton->setEnabled(true);
        startButton->setGeometry(QRect(30, 600, 200, 23));
        startButton->setMinimumSize(QSize(200, 0));
        labelOri = new ClickableLabel(tabCamera);
        labelOri->setObjectName(QStringLiteral("labelOri"));
        labelOri->setGeometry(QRect(10, 30, 480, 360));
        labelOri->setMinimumSize(QSize(480, 360));
        labelOri->setBaseSize(QSize(480, 360));
        labelOri->setFrameShape(QFrame::Box);
        stopButton = new QPushButton(tabCamera);
        stopButton->setObjectName(QStringLiteral("stopButton"));
        stopButton->setEnabled(false);
        stopButton->setGeometry(QRect(250, 600, 200, 23));
        stopButton->setMinimumSize(QSize(200, 0));
        layoutWidget = new QWidget(tabCamera);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(540, 10, 502, 661));
        verticalLayout_10 = new QVBoxLayout(layoutWidget);
        verticalLayout_10->setObjectName(QStringLiteral("verticalLayout_10"));
        verticalLayout_10->setContentsMargins(0, 0, 0, 0);
        warnaSelector = new QComboBox(layoutWidget);
        warnaSelector->setObjectName(QStringLiteral("warnaSelector"));

        verticalLayout_10->addWidget(warnaSelector);

        stackedWidget = new QStackedWidget(layoutWidget);
        stackedWidget->setObjectName(QStringLiteral("stackedWidget"));
        warna1 = new QWidget();
        warna1->setObjectName(QStringLiteral("warna1"));
        warna1->setMinimumSize(QSize(500, 400));
        layoutWidget_2 = new QWidget(warna1);
        layoutWidget_2->setObjectName(QStringLiteral("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(0, 0, 501, 600));
        verticalLayout = new QVBoxLayout(layoutWidget_2);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        labelWarna1 = new QLabel(layoutWidget_2);
        labelWarna1->setObjectName(QStringLiteral("labelWarna1"));
        labelWarna1->setMinimumSize(QSize(480, 360));
        labelWarna1->setBaseSize(QSize(480, 360));
        labelWarna1->setFrameShape(QFrame::Box);

        verticalLayout->addWidget(labelWarna1);

        formLayout = new QFormLayout();
        formLayout->setObjectName(QStringLiteral("formLayout"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        label = new QLabel(layoutWidget_2);
        label->setObjectName(QStringLiteral("label"));
        label->setMaximumSize(QSize(16777215, 100));

        verticalLayout_2->addWidget(label);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        hMin1 = new QSlider(layoutWidget_2);
        hMin1->setObjectName(QStringLiteral("hMin1"));
        hMin1->setMinimumSize(QSize(200, 0));
        hMin1->setBaseSize(QSize(200, 100));
        hMin1->setMaximum(255);
        hMin1->setOrientation(Qt::Horizontal);

        horizontalLayout->addWidget(hMin1);

        hMinVal1 = new QLabel(layoutWidget_2);
        hMinVal1->setObjectName(QStringLiteral("hMinVal1"));
        hMinVal1->setMinimumSize(QSize(25, 25));

        horizontalLayout->addWidget(hMinVal1);


        verticalLayout_2->addLayout(horizontalLayout);


        formLayout->setLayout(0, QFormLayout::LabelRole, verticalLayout_2);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        label_2 = new QLabel(layoutWidget_2);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setMaximumSize(QSize(16777215, 100));

        verticalLayout_3->addWidget(label_2);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        hMax1 = new QSlider(layoutWidget_2);
        hMax1->setObjectName(QStringLiteral("hMax1"));
        hMax1->setMinimumSize(QSize(150, 0));
        hMax1->setBaseSize(QSize(200, 100));
        hMax1->setMaximum(255);
        hMax1->setValue(255);
        hMax1->setOrientation(Qt::Horizontal);

        horizontalLayout_2->addWidget(hMax1);

        hMaxVal1 = new QLabel(layoutWidget_2);
        hMaxVal1->setObjectName(QStringLiteral("hMaxVal1"));
        hMaxVal1->setMinimumSize(QSize(25, 25));

        horizontalLayout_2->addWidget(hMaxVal1);


        verticalLayout_3->addLayout(horizontalLayout_2);


        formLayout->setLayout(0, QFormLayout::FieldRole, verticalLayout_3);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        label_5 = new QLabel(layoutWidget_2);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setMaximumSize(QSize(16777215, 100));

        verticalLayout_6->addWidget(label_5);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        sMin1 = new QSlider(layoutWidget_2);
        sMin1->setObjectName(QStringLiteral("sMin1"));
        sMin1->setMinimumSize(QSize(200, 0));
        sMin1->setBaseSize(QSize(200, 100));
        sMin1->setMaximum(255);
        sMin1->setOrientation(Qt::Horizontal);

        horizontalLayout_5->addWidget(sMin1);

        sMinVal1 = new QLabel(layoutWidget_2);
        sMinVal1->setObjectName(QStringLiteral("sMinVal1"));
        sMinVal1->setMinimumSize(QSize(25, 25));

        horizontalLayout_5->addWidget(sMinVal1);


        verticalLayout_6->addLayout(horizontalLayout_5);


        formLayout->setLayout(1, QFormLayout::LabelRole, verticalLayout_6);

        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        label_6 = new QLabel(layoutWidget_2);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setMaximumSize(QSize(16777215, 100));

        verticalLayout_7->addWidget(label_6);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        sMax1 = new QSlider(layoutWidget_2);
        sMax1->setObjectName(QStringLiteral("sMax1"));
        sMax1->setMinimumSize(QSize(150, 0));
        sMax1->setBaseSize(QSize(200, 100));
        sMax1->setMaximum(255);
        sMax1->setValue(255);
        sMax1->setOrientation(Qt::Horizontal);

        horizontalLayout_6->addWidget(sMax1);

        sMaxVal1 = new QLabel(layoutWidget_2);
        sMaxVal1->setObjectName(QStringLiteral("sMaxVal1"));
        sMaxVal1->setMinimumSize(QSize(25, 25));

        horizontalLayout_6->addWidget(sMaxVal1);


        verticalLayout_7->addLayout(horizontalLayout_6);


        formLayout->setLayout(1, QFormLayout::FieldRole, verticalLayout_7);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        label_3 = new QLabel(layoutWidget_2);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setMaximumSize(QSize(16777215, 100));

        verticalLayout_4->addWidget(label_3);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        vMin1 = new QSlider(layoutWidget_2);
        vMin1->setObjectName(QStringLiteral("vMin1"));
        vMin1->setMinimumSize(QSize(200, 0));
        vMin1->setBaseSize(QSize(200, 100));
        vMin1->setMaximum(255);
        vMin1->setOrientation(Qt::Horizontal);

        horizontalLayout_3->addWidget(vMin1);

        vMinVal1 = new QLabel(layoutWidget_2);
        vMinVal1->setObjectName(QStringLiteral("vMinVal1"));
        vMinVal1->setMinimumSize(QSize(25, 25));

        horizontalLayout_3->addWidget(vMinVal1);


        verticalLayout_4->addLayout(horizontalLayout_3);


        formLayout->setLayout(2, QFormLayout::LabelRole, verticalLayout_4);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        label_4 = new QLabel(layoutWidget_2);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setMaximumSize(QSize(16777215, 100));

        verticalLayout_5->addWidget(label_4);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        vMax1 = new QSlider(layoutWidget_2);
        vMax1->setObjectName(QStringLiteral("vMax1"));
        vMax1->setMinimumSize(QSize(150, 0));
        vMax1->setBaseSize(QSize(200, 100));
        vMax1->setMaximum(255);
        vMax1->setValue(255);
        vMax1->setOrientation(Qt::Horizontal);

        horizontalLayout_4->addWidget(vMax1);

        vMaxVal1 = new QLabel(layoutWidget_2);
        vMaxVal1->setObjectName(QStringLiteral("vMaxVal1"));
        vMaxVal1->setMinimumSize(QSize(25, 25));

        horizontalLayout_4->addWidget(vMaxVal1);


        verticalLayout_5->addLayout(horizontalLayout_4);


        formLayout->setLayout(2, QFormLayout::FieldRole, verticalLayout_5);

        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setObjectName(QStringLiteral("verticalLayout_9"));
        label_8 = new QLabel(layoutWidget_2);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setMaximumSize(QSize(16777215, 100));

        verticalLayout_9->addWidget(label_8);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));
        erode1 = new QSlider(layoutWidget_2);
        erode1->setObjectName(QStringLiteral("erode1"));
        erode1->setMinimumSize(QSize(200, 0));
        erode1->setBaseSize(QSize(200, 100));
        erode1->setMinimum(0);
        erode1->setMaximum(20);
        erode1->setOrientation(Qt::Horizontal);

        horizontalLayout_8->addWidget(erode1);

        erodeVal1 = new QLabel(layoutWidget_2);
        erodeVal1->setObjectName(QStringLiteral("erodeVal1"));
        erodeVal1->setMinimumSize(QSize(25, 25));

        horizontalLayout_8->addWidget(erodeVal1);


        verticalLayout_9->addLayout(horizontalLayout_8);


        formLayout->setLayout(3, QFormLayout::LabelRole, verticalLayout_9);

        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setObjectName(QStringLiteral("verticalLayout_8"));
        label_7 = new QLabel(layoutWidget_2);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setMaximumSize(QSize(16777215, 100));

        verticalLayout_8->addWidget(label_7);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        dilate1 = new QSlider(layoutWidget_2);
        dilate1->setObjectName(QStringLiteral("dilate1"));
        dilate1->setMinimumSize(QSize(150, 0));
        dilate1->setBaseSize(QSize(200, 100));
        dilate1->setMinimum(0);
        dilate1->setMaximum(20);
        dilate1->setValue(0);
        dilate1->setOrientation(Qt::Horizontal);

        horizontalLayout_7->addWidget(dilate1);

        dilateVal1 = new QLabel(layoutWidget_2);
        dilateVal1->setObjectName(QStringLiteral("dilateVal1"));
        dilateVal1->setMinimumSize(QSize(25, 25));

        horizontalLayout_7->addWidget(dilateVal1);


        verticalLayout_8->addLayout(horizontalLayout_7);


        formLayout->setLayout(3, QFormLayout::FieldRole, verticalLayout_8);


        verticalLayout->addLayout(formLayout);

        stackedWidget->addWidget(warna1);
        warna2 = new QWidget();
        warna2->setObjectName(QStringLiteral("warna2"));
        layoutWidget_3 = new QWidget(warna2);
        layoutWidget_3->setObjectName(QStringLiteral("layoutWidget_3"));
        layoutWidget_3->setGeometry(QRect(0, 0, 501, 600));
        verticalLayout_29 = new QVBoxLayout(layoutWidget_3);
        verticalLayout_29->setObjectName(QStringLiteral("verticalLayout_29"));
        verticalLayout_29->setContentsMargins(0, 0, 0, 0);
        labelWarna2 = new QLabel(layoutWidget_3);
        labelWarna2->setObjectName(QStringLiteral("labelWarna2"));
        labelWarna2->setMinimumSize(QSize(480, 360));
        labelWarna2->setBaseSize(QSize(480, 360));
        labelWarna2->setFrameShape(QFrame::Box);

        verticalLayout_29->addWidget(labelWarna2);

        formLayout_4 = new QFormLayout();
        formLayout_4->setObjectName(QStringLiteral("formLayout_4"));
        verticalLayout_30 = new QVBoxLayout();
        verticalLayout_30->setObjectName(QStringLiteral("verticalLayout_30"));
        label_25 = new QLabel(layoutWidget_3);
        label_25->setObjectName(QStringLiteral("label_25"));
        label_25->setMaximumSize(QSize(16777215, 100));

        verticalLayout_30->addWidget(label_25);

        horizontalLayout_25 = new QHBoxLayout();
        horizontalLayout_25->setObjectName(QStringLiteral("horizontalLayout_25"));
        hMin2 = new QSlider(layoutWidget_3);
        hMin2->setObjectName(QStringLiteral("hMin2"));
        hMin2->setMinimumSize(QSize(200, 0));
        hMin2->setBaseSize(QSize(200, 100));
        hMin2->setMaximum(255);
        hMin2->setOrientation(Qt::Horizontal);

        horizontalLayout_25->addWidget(hMin2);

        hMinVal2 = new QLabel(layoutWidget_3);
        hMinVal2->setObjectName(QStringLiteral("hMinVal2"));
        hMinVal2->setMinimumSize(QSize(25, 25));

        horizontalLayout_25->addWidget(hMinVal2);


        verticalLayout_30->addLayout(horizontalLayout_25);


        formLayout_4->setLayout(0, QFormLayout::LabelRole, verticalLayout_30);

        verticalLayout_31 = new QVBoxLayout();
        verticalLayout_31->setObjectName(QStringLiteral("verticalLayout_31"));
        label_26 = new QLabel(layoutWidget_3);
        label_26->setObjectName(QStringLiteral("label_26"));
        label_26->setMaximumSize(QSize(16777215, 100));

        verticalLayout_31->addWidget(label_26);

        horizontalLayout_26 = new QHBoxLayout();
        horizontalLayout_26->setObjectName(QStringLiteral("horizontalLayout_26"));
        hMax2 = new QSlider(layoutWidget_3);
        hMax2->setObjectName(QStringLiteral("hMax2"));
        hMax2->setMinimumSize(QSize(150, 0));
        hMax2->setBaseSize(QSize(200, 100));
        hMax2->setMaximum(255);
        hMax2->setValue(255);
        hMax2->setOrientation(Qt::Horizontal);

        horizontalLayout_26->addWidget(hMax2);

        hMaxVal2 = new QLabel(layoutWidget_3);
        hMaxVal2->setObjectName(QStringLiteral("hMaxVal2"));
        hMaxVal2->setMinimumSize(QSize(25, 25));

        horizontalLayout_26->addWidget(hMaxVal2);


        verticalLayout_31->addLayout(horizontalLayout_26);


        formLayout_4->setLayout(0, QFormLayout::FieldRole, verticalLayout_31);

        verticalLayout_32 = new QVBoxLayout();
        verticalLayout_32->setObjectName(QStringLiteral("verticalLayout_32"));
        label_27 = new QLabel(layoutWidget_3);
        label_27->setObjectName(QStringLiteral("label_27"));
        label_27->setMaximumSize(QSize(16777215, 100));

        verticalLayout_32->addWidget(label_27);

        horizontalLayout_27 = new QHBoxLayout();
        horizontalLayout_27->setObjectName(QStringLiteral("horizontalLayout_27"));
        sMin2 = new QSlider(layoutWidget_3);
        sMin2->setObjectName(QStringLiteral("sMin2"));
        sMin2->setMinimumSize(QSize(200, 0));
        sMin2->setBaseSize(QSize(200, 100));
        sMin2->setMaximum(255);
        sMin2->setOrientation(Qt::Horizontal);

        horizontalLayout_27->addWidget(sMin2);

        sMinVal2 = new QLabel(layoutWidget_3);
        sMinVal2->setObjectName(QStringLiteral("sMinVal2"));
        sMinVal2->setMinimumSize(QSize(25, 25));

        horizontalLayout_27->addWidget(sMinVal2);


        verticalLayout_32->addLayout(horizontalLayout_27);


        formLayout_4->setLayout(1, QFormLayout::LabelRole, verticalLayout_32);

        verticalLayout_33 = new QVBoxLayout();
        verticalLayout_33->setObjectName(QStringLiteral("verticalLayout_33"));
        label_28 = new QLabel(layoutWidget_3);
        label_28->setObjectName(QStringLiteral("label_28"));
        label_28->setMaximumSize(QSize(16777215, 100));

        verticalLayout_33->addWidget(label_28);

        horizontalLayout_28 = new QHBoxLayout();
        horizontalLayout_28->setObjectName(QStringLiteral("horizontalLayout_28"));
        sMax2 = new QSlider(layoutWidget_3);
        sMax2->setObjectName(QStringLiteral("sMax2"));
        sMax2->setMinimumSize(QSize(150, 0));
        sMax2->setBaseSize(QSize(200, 100));
        sMax2->setMaximum(255);
        sMax2->setValue(255);
        sMax2->setOrientation(Qt::Horizontal);

        horizontalLayout_28->addWidget(sMax2);

        sMaxVal2 = new QLabel(layoutWidget_3);
        sMaxVal2->setObjectName(QStringLiteral("sMaxVal2"));
        sMaxVal2->setMinimumSize(QSize(25, 25));

        horizontalLayout_28->addWidget(sMaxVal2);


        verticalLayout_33->addLayout(horizontalLayout_28);


        formLayout_4->setLayout(1, QFormLayout::FieldRole, verticalLayout_33);

        verticalLayout_34 = new QVBoxLayout();
        verticalLayout_34->setObjectName(QStringLiteral("verticalLayout_34"));
        label_29 = new QLabel(layoutWidget_3);
        label_29->setObjectName(QStringLiteral("label_29"));
        label_29->setMaximumSize(QSize(16777215, 100));

        verticalLayout_34->addWidget(label_29);

        horizontalLayout_29 = new QHBoxLayout();
        horizontalLayout_29->setObjectName(QStringLiteral("horizontalLayout_29"));
        vMin2 = new QSlider(layoutWidget_3);
        vMin2->setObjectName(QStringLiteral("vMin2"));
        vMin2->setMinimumSize(QSize(200, 0));
        vMin2->setBaseSize(QSize(200, 100));
        vMin2->setMaximum(255);
        vMin2->setOrientation(Qt::Horizontal);

        horizontalLayout_29->addWidget(vMin2);

        vMinVal2 = new QLabel(layoutWidget_3);
        vMinVal2->setObjectName(QStringLiteral("vMinVal2"));
        vMinVal2->setMinimumSize(QSize(25, 25));

        horizontalLayout_29->addWidget(vMinVal2);


        verticalLayout_34->addLayout(horizontalLayout_29);


        formLayout_4->setLayout(2, QFormLayout::LabelRole, verticalLayout_34);

        verticalLayout_35 = new QVBoxLayout();
        verticalLayout_35->setObjectName(QStringLiteral("verticalLayout_35"));
        label_30 = new QLabel(layoutWidget_3);
        label_30->setObjectName(QStringLiteral("label_30"));
        label_30->setMaximumSize(QSize(16777215, 100));

        verticalLayout_35->addWidget(label_30);

        horizontalLayout_30 = new QHBoxLayout();
        horizontalLayout_30->setObjectName(QStringLiteral("horizontalLayout_30"));
        vMax2 = new QSlider(layoutWidget_3);
        vMax2->setObjectName(QStringLiteral("vMax2"));
        vMax2->setMinimumSize(QSize(150, 0));
        vMax2->setBaseSize(QSize(200, 100));
        vMax2->setMaximum(255);
        vMax2->setValue(255);
        vMax2->setOrientation(Qt::Horizontal);

        horizontalLayout_30->addWidget(vMax2);

        vMaxVal2 = new QLabel(layoutWidget_3);
        vMaxVal2->setObjectName(QStringLiteral("vMaxVal2"));
        vMaxVal2->setMinimumSize(QSize(25, 25));

        horizontalLayout_30->addWidget(vMaxVal2);


        verticalLayout_35->addLayout(horizontalLayout_30);


        formLayout_4->setLayout(2, QFormLayout::FieldRole, verticalLayout_35);

        verticalLayout_36 = new QVBoxLayout();
        verticalLayout_36->setObjectName(QStringLiteral("verticalLayout_36"));
        label_31 = new QLabel(layoutWidget_3);
        label_31->setObjectName(QStringLiteral("label_31"));
        label_31->setMaximumSize(QSize(16777215, 100));

        verticalLayout_36->addWidget(label_31);

        horizontalLayout_31 = new QHBoxLayout();
        horizontalLayout_31->setObjectName(QStringLiteral("horizontalLayout_31"));
        erode2 = new QSlider(layoutWidget_3);
        erode2->setObjectName(QStringLiteral("erode2"));
        erode2->setMinimumSize(QSize(200, 0));
        erode2->setBaseSize(QSize(200, 100));
        erode2->setMaximum(20);
        erode2->setOrientation(Qt::Horizontal);

        horizontalLayout_31->addWidget(erode2);

        erodeVal2 = new QLabel(layoutWidget_3);
        erodeVal2->setObjectName(QStringLiteral("erodeVal2"));
        erodeVal2->setMinimumSize(QSize(25, 25));

        horizontalLayout_31->addWidget(erodeVal2);


        verticalLayout_36->addLayout(horizontalLayout_31);


        formLayout_4->setLayout(3, QFormLayout::LabelRole, verticalLayout_36);

        verticalLayout_37 = new QVBoxLayout();
        verticalLayout_37->setObjectName(QStringLiteral("verticalLayout_37"));
        label_32 = new QLabel(layoutWidget_3);
        label_32->setObjectName(QStringLiteral("label_32"));
        label_32->setMaximumSize(QSize(16777215, 100));

        verticalLayout_37->addWidget(label_32);

        horizontalLayout_32 = new QHBoxLayout();
        horizontalLayout_32->setObjectName(QStringLiteral("horizontalLayout_32"));
        dilate2 = new QSlider(layoutWidget_3);
        dilate2->setObjectName(QStringLiteral("dilate2"));
        dilate2->setMinimumSize(QSize(150, 0));
        dilate2->setBaseSize(QSize(200, 100));
        dilate2->setMaximum(20);
        dilate2->setValue(0);
        dilate2->setOrientation(Qt::Horizontal);

        horizontalLayout_32->addWidget(dilate2);

        dilateVal2 = new QLabel(layoutWidget_3);
        dilateVal2->setObjectName(QStringLiteral("dilateVal2"));
        dilateVal2->setMinimumSize(QSize(25, 25));

        horizontalLayout_32->addWidget(dilateVal2);


        verticalLayout_37->addLayout(horizontalLayout_32);


        formLayout_4->setLayout(3, QFormLayout::FieldRole, verticalLayout_37);


        verticalLayout_29->addLayout(formLayout_4);

        stackedWidget->addWidget(warna2);
        warna3 = new QWidget();
        warna3->setObjectName(QStringLiteral("warna3"));
        layoutWidget_4 = new QWidget(warna3);
        layoutWidget_4->setObjectName(QStringLiteral("layoutWidget_4"));
        layoutWidget_4->setGeometry(QRect(0, 0, 501, 600));
        verticalLayout_11 = new QVBoxLayout(layoutWidget_4);
        verticalLayout_11->setObjectName(QStringLiteral("verticalLayout_11"));
        verticalLayout_11->setContentsMargins(0, 0, 0, 0);
        labelWarna3 = new QLabel(layoutWidget_4);
        labelWarna3->setObjectName(QStringLiteral("labelWarna3"));
        labelWarna3->setMinimumSize(QSize(480, 360));
        labelWarna3->setBaseSize(QSize(480, 360));
        labelWarna3->setFrameShape(QFrame::Box);

        verticalLayout_11->addWidget(labelWarna3);

        formLayout_2 = new QFormLayout();
        formLayout_2->setObjectName(QStringLiteral("formLayout_2"));
        verticalLayout_12 = new QVBoxLayout();
        verticalLayout_12->setObjectName(QStringLiteral("verticalLayout_12"));
        label_9 = new QLabel(layoutWidget_4);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setMaximumSize(QSize(16777215, 100));

        verticalLayout_12->addWidget(label_9);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setObjectName(QStringLiteral("horizontalLayout_9"));
        hMin3 = new QSlider(layoutWidget_4);
        hMin3->setObjectName(QStringLiteral("hMin3"));
        hMin3->setMinimumSize(QSize(200, 0));
        hMin3->setBaseSize(QSize(200, 100));
        hMin3->setMaximum(255);
        hMin3->setOrientation(Qt::Horizontal);

        horizontalLayout_9->addWidget(hMin3);

        hMinVal3 = new QLabel(layoutWidget_4);
        hMinVal3->setObjectName(QStringLiteral("hMinVal3"));
        hMinVal3->setMinimumSize(QSize(25, 25));

        horizontalLayout_9->addWidget(hMinVal3);


        verticalLayout_12->addLayout(horizontalLayout_9);


        formLayout_2->setLayout(0, QFormLayout::LabelRole, verticalLayout_12);

        verticalLayout_13 = new QVBoxLayout();
        verticalLayout_13->setObjectName(QStringLiteral("verticalLayout_13"));
        label_10 = new QLabel(layoutWidget_4);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setMaximumSize(QSize(16777215, 100));

        verticalLayout_13->addWidget(label_10);

        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setObjectName(QStringLiteral("horizontalLayout_10"));
        hMax3 = new QSlider(layoutWidget_4);
        hMax3->setObjectName(QStringLiteral("hMax3"));
        hMax3->setMinimumSize(QSize(150, 0));
        hMax3->setBaseSize(QSize(200, 100));
        hMax3->setMaximum(255);
        hMax3->setValue(255);
        hMax3->setOrientation(Qt::Horizontal);

        horizontalLayout_10->addWidget(hMax3);

        hMaxVal3 = new QLabel(layoutWidget_4);
        hMaxVal3->setObjectName(QStringLiteral("hMaxVal3"));
        hMaxVal3->setMinimumSize(QSize(25, 25));

        horizontalLayout_10->addWidget(hMaxVal3);


        verticalLayout_13->addLayout(horizontalLayout_10);


        formLayout_2->setLayout(0, QFormLayout::FieldRole, verticalLayout_13);

        verticalLayout_14 = new QVBoxLayout();
        verticalLayout_14->setObjectName(QStringLiteral("verticalLayout_14"));
        label_11 = new QLabel(layoutWidget_4);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setMaximumSize(QSize(16777215, 100));

        verticalLayout_14->addWidget(label_11);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setObjectName(QStringLiteral("horizontalLayout_11"));
        sMin3 = new QSlider(layoutWidget_4);
        sMin3->setObjectName(QStringLiteral("sMin3"));
        sMin3->setMinimumSize(QSize(200, 0));
        sMin3->setBaseSize(QSize(200, 100));
        sMin3->setMaximum(255);
        sMin3->setOrientation(Qt::Horizontal);

        horizontalLayout_11->addWidget(sMin3);

        sMinVal3 = new QLabel(layoutWidget_4);
        sMinVal3->setObjectName(QStringLiteral("sMinVal3"));
        sMinVal3->setMinimumSize(QSize(25, 25));

        horizontalLayout_11->addWidget(sMinVal3);


        verticalLayout_14->addLayout(horizontalLayout_11);


        formLayout_2->setLayout(1, QFormLayout::LabelRole, verticalLayout_14);

        verticalLayout_15 = new QVBoxLayout();
        verticalLayout_15->setObjectName(QStringLiteral("verticalLayout_15"));
        label_12 = new QLabel(layoutWidget_4);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setMaximumSize(QSize(16777215, 100));

        verticalLayout_15->addWidget(label_12);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setObjectName(QStringLiteral("horizontalLayout_12"));
        sMax3 = new QSlider(layoutWidget_4);
        sMax3->setObjectName(QStringLiteral("sMax3"));
        sMax3->setMinimumSize(QSize(150, 0));
        sMax3->setBaseSize(QSize(200, 100));
        sMax3->setMaximum(255);
        sMax3->setValue(255);
        sMax3->setOrientation(Qt::Horizontal);

        horizontalLayout_12->addWidget(sMax3);

        sMaxVal3 = new QLabel(layoutWidget_4);
        sMaxVal3->setObjectName(QStringLiteral("sMaxVal3"));
        sMaxVal3->setMinimumSize(QSize(25, 25));

        horizontalLayout_12->addWidget(sMaxVal3);


        verticalLayout_15->addLayout(horizontalLayout_12);


        formLayout_2->setLayout(1, QFormLayout::FieldRole, verticalLayout_15);

        verticalLayout_16 = new QVBoxLayout();
        verticalLayout_16->setObjectName(QStringLiteral("verticalLayout_16"));
        label_13 = new QLabel(layoutWidget_4);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setMaximumSize(QSize(16777215, 100));

        verticalLayout_16->addWidget(label_13);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setObjectName(QStringLiteral("horizontalLayout_13"));
        vMin3 = new QSlider(layoutWidget_4);
        vMin3->setObjectName(QStringLiteral("vMin3"));
        vMin3->setMinimumSize(QSize(200, 0));
        vMin3->setBaseSize(QSize(200, 100));
        vMin3->setMaximum(255);
        vMin3->setOrientation(Qt::Horizontal);

        horizontalLayout_13->addWidget(vMin3);

        vMinVal3 = new QLabel(layoutWidget_4);
        vMinVal3->setObjectName(QStringLiteral("vMinVal3"));
        vMinVal3->setMinimumSize(QSize(25, 25));

        horizontalLayout_13->addWidget(vMinVal3);


        verticalLayout_16->addLayout(horizontalLayout_13);


        formLayout_2->setLayout(2, QFormLayout::LabelRole, verticalLayout_16);

        verticalLayout_17 = new QVBoxLayout();
        verticalLayout_17->setObjectName(QStringLiteral("verticalLayout_17"));
        label_14 = new QLabel(layoutWidget_4);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setMaximumSize(QSize(16777215, 100));

        verticalLayout_17->addWidget(label_14);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setObjectName(QStringLiteral("horizontalLayout_14"));
        vMax3 = new QSlider(layoutWidget_4);
        vMax3->setObjectName(QStringLiteral("vMax3"));
        vMax3->setMinimumSize(QSize(150, 0));
        vMax3->setBaseSize(QSize(200, 100));
        vMax3->setMaximum(255);
        vMax3->setValue(255);
        vMax3->setOrientation(Qt::Horizontal);

        horizontalLayout_14->addWidget(vMax3);

        vMaxVal3 = new QLabel(layoutWidget_4);
        vMaxVal3->setObjectName(QStringLiteral("vMaxVal3"));
        vMaxVal3->setMinimumSize(QSize(25, 25));

        horizontalLayout_14->addWidget(vMaxVal3);


        verticalLayout_17->addLayout(horizontalLayout_14);


        formLayout_2->setLayout(2, QFormLayout::FieldRole, verticalLayout_17);

        verticalLayout_18 = new QVBoxLayout();
        verticalLayout_18->setObjectName(QStringLiteral("verticalLayout_18"));
        label_15 = new QLabel(layoutWidget_4);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setMaximumSize(QSize(16777215, 100));

        verticalLayout_18->addWidget(label_15);

        horizontalLayout_15 = new QHBoxLayout();
        horizontalLayout_15->setObjectName(QStringLiteral("horizontalLayout_15"));
        erode3 = new QSlider(layoutWidget_4);
        erode3->setObjectName(QStringLiteral("erode3"));
        erode3->setMinimumSize(QSize(200, 0));
        erode3->setBaseSize(QSize(200, 100));
        erode3->setMaximum(20);
        erode3->setOrientation(Qt::Horizontal);

        horizontalLayout_15->addWidget(erode3);

        erodeVal3 = new QLabel(layoutWidget_4);
        erodeVal3->setObjectName(QStringLiteral("erodeVal3"));
        erodeVal3->setMinimumSize(QSize(25, 25));

        horizontalLayout_15->addWidget(erodeVal3);


        verticalLayout_18->addLayout(horizontalLayout_15);


        formLayout_2->setLayout(3, QFormLayout::LabelRole, verticalLayout_18);

        verticalLayout_19 = new QVBoxLayout();
        verticalLayout_19->setObjectName(QStringLiteral("verticalLayout_19"));
        label_16 = new QLabel(layoutWidget_4);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setMaximumSize(QSize(16777215, 100));

        verticalLayout_19->addWidget(label_16);

        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setObjectName(QStringLiteral("horizontalLayout_16"));
        dilate3 = new QSlider(layoutWidget_4);
        dilate3->setObjectName(QStringLiteral("dilate3"));
        dilate3->setMinimumSize(QSize(150, 0));
        dilate3->setBaseSize(QSize(200, 100));
        dilate3->setMaximum(20);
        dilate3->setValue(0);
        dilate3->setOrientation(Qt::Horizontal);

        horizontalLayout_16->addWidget(dilate3);

        dilateVal3 = new QLabel(layoutWidget_4);
        dilateVal3->setObjectName(QStringLiteral("dilateVal3"));
        dilateVal3->setMinimumSize(QSize(25, 25));

        horizontalLayout_16->addWidget(dilateVal3);


        verticalLayout_19->addLayout(horizontalLayout_16);


        formLayout_2->setLayout(3, QFormLayout::FieldRole, verticalLayout_19);


        verticalLayout_11->addLayout(formLayout_2);

        stackedWidget->addWidget(warna3);
        warna4 = new QWidget();
        warna4->setObjectName(QStringLiteral("warna4"));
        layoutWidget_5 = new QWidget(warna4);
        layoutWidget_5->setObjectName(QStringLiteral("layoutWidget_5"));
        layoutWidget_5->setGeometry(QRect(0, 0, 501, 600));
        verticalLayout_38 = new QVBoxLayout(layoutWidget_5);
        verticalLayout_38->setObjectName(QStringLiteral("verticalLayout_38"));
        verticalLayout_38->setContentsMargins(0, 0, 0, 0);
        labelWarna4 = new QLabel(layoutWidget_5);
        labelWarna4->setObjectName(QStringLiteral("labelWarna4"));
        labelWarna4->setMinimumSize(QSize(480, 360));
        labelWarna4->setBaseSize(QSize(480, 360));
        labelWarna4->setFrameShape(QFrame::Box);

        verticalLayout_38->addWidget(labelWarna4);

        formLayout_5 = new QFormLayout();
        formLayout_5->setObjectName(QStringLiteral("formLayout_5"));
        verticalLayout_39 = new QVBoxLayout();
        verticalLayout_39->setObjectName(QStringLiteral("verticalLayout_39"));
        label_33 = new QLabel(layoutWidget_5);
        label_33->setObjectName(QStringLiteral("label_33"));
        label_33->setMaximumSize(QSize(16777215, 100));

        verticalLayout_39->addWidget(label_33);

        horizontalLayout_33 = new QHBoxLayout();
        horizontalLayout_33->setObjectName(QStringLiteral("horizontalLayout_33"));
        hMin4 = new QSlider(layoutWidget_5);
        hMin4->setObjectName(QStringLiteral("hMin4"));
        hMin4->setMinimumSize(QSize(200, 0));
        hMin4->setBaseSize(QSize(200, 100));
        hMin4->setMaximum(255);
        hMin4->setOrientation(Qt::Horizontal);

        horizontalLayout_33->addWidget(hMin4);

        hMinVal4 = new QLabel(layoutWidget_5);
        hMinVal4->setObjectName(QStringLiteral("hMinVal4"));
        hMinVal4->setMinimumSize(QSize(25, 25));

        horizontalLayout_33->addWidget(hMinVal4);


        verticalLayout_39->addLayout(horizontalLayout_33);


        formLayout_5->setLayout(0, QFormLayout::LabelRole, verticalLayout_39);

        verticalLayout_40 = new QVBoxLayout();
        verticalLayout_40->setObjectName(QStringLiteral("verticalLayout_40"));
        label_34 = new QLabel(layoutWidget_5);
        label_34->setObjectName(QStringLiteral("label_34"));
        label_34->setMaximumSize(QSize(16777215, 100));

        verticalLayout_40->addWidget(label_34);

        horizontalLayout_34 = new QHBoxLayout();
        horizontalLayout_34->setObjectName(QStringLiteral("horizontalLayout_34"));
        hMax4 = new QSlider(layoutWidget_5);
        hMax4->setObjectName(QStringLiteral("hMax4"));
        hMax4->setMinimumSize(QSize(150, 0));
        hMax4->setBaseSize(QSize(200, 100));
        hMax4->setMaximum(255);
        hMax4->setValue(255);
        hMax4->setOrientation(Qt::Horizontal);

        horizontalLayout_34->addWidget(hMax4);

        hMaxVal4 = new QLabel(layoutWidget_5);
        hMaxVal4->setObjectName(QStringLiteral("hMaxVal4"));
        hMaxVal4->setMinimumSize(QSize(25, 25));

        horizontalLayout_34->addWidget(hMaxVal4);


        verticalLayout_40->addLayout(horizontalLayout_34);


        formLayout_5->setLayout(0, QFormLayout::FieldRole, verticalLayout_40);

        verticalLayout_41 = new QVBoxLayout();
        verticalLayout_41->setObjectName(QStringLiteral("verticalLayout_41"));
        label_35 = new QLabel(layoutWidget_5);
        label_35->setObjectName(QStringLiteral("label_35"));
        label_35->setMaximumSize(QSize(16777215, 100));

        verticalLayout_41->addWidget(label_35);

        horizontalLayout_35 = new QHBoxLayout();
        horizontalLayout_35->setObjectName(QStringLiteral("horizontalLayout_35"));
        sMin4 = new QSlider(layoutWidget_5);
        sMin4->setObjectName(QStringLiteral("sMin4"));
        sMin4->setMinimumSize(QSize(200, 0));
        sMin4->setBaseSize(QSize(200, 100));
        sMin4->setMaximum(255);
        sMin4->setOrientation(Qt::Horizontal);

        horizontalLayout_35->addWidget(sMin4);

        sMinVal4 = new QLabel(layoutWidget_5);
        sMinVal4->setObjectName(QStringLiteral("sMinVal4"));
        sMinVal4->setMinimumSize(QSize(25, 25));

        horizontalLayout_35->addWidget(sMinVal4);


        verticalLayout_41->addLayout(horizontalLayout_35);


        formLayout_5->setLayout(1, QFormLayout::LabelRole, verticalLayout_41);

        verticalLayout_42 = new QVBoxLayout();
        verticalLayout_42->setObjectName(QStringLiteral("verticalLayout_42"));
        label_36 = new QLabel(layoutWidget_5);
        label_36->setObjectName(QStringLiteral("label_36"));
        label_36->setMaximumSize(QSize(16777215, 100));

        verticalLayout_42->addWidget(label_36);

        horizontalLayout_36 = new QHBoxLayout();
        horizontalLayout_36->setObjectName(QStringLiteral("horizontalLayout_36"));
        sMax4 = new QSlider(layoutWidget_5);
        sMax4->setObjectName(QStringLiteral("sMax4"));
        sMax4->setMinimumSize(QSize(150, 0));
        sMax4->setBaseSize(QSize(200, 100));
        sMax4->setMaximum(255);
        sMax4->setValue(255);
        sMax4->setOrientation(Qt::Horizontal);

        horizontalLayout_36->addWidget(sMax4);

        sMaxVal4 = new QLabel(layoutWidget_5);
        sMaxVal4->setObjectName(QStringLiteral("sMaxVal4"));
        sMaxVal4->setMinimumSize(QSize(25, 25));

        horizontalLayout_36->addWidget(sMaxVal4);


        verticalLayout_42->addLayout(horizontalLayout_36);


        formLayout_5->setLayout(1, QFormLayout::FieldRole, verticalLayout_42);

        verticalLayout_43 = new QVBoxLayout();
        verticalLayout_43->setObjectName(QStringLiteral("verticalLayout_43"));
        label_37 = new QLabel(layoutWidget_5);
        label_37->setObjectName(QStringLiteral("label_37"));
        label_37->setMaximumSize(QSize(16777215, 100));

        verticalLayout_43->addWidget(label_37);

        horizontalLayout_37 = new QHBoxLayout();
        horizontalLayout_37->setObjectName(QStringLiteral("horizontalLayout_37"));
        vMin4 = new QSlider(layoutWidget_5);
        vMin4->setObjectName(QStringLiteral("vMin4"));
        vMin4->setMinimumSize(QSize(200, 0));
        vMin4->setBaseSize(QSize(200, 100));
        vMin4->setMaximum(255);
        vMin4->setOrientation(Qt::Horizontal);

        horizontalLayout_37->addWidget(vMin4);

        vMinVal4 = new QLabel(layoutWidget_5);
        vMinVal4->setObjectName(QStringLiteral("vMinVal4"));
        vMinVal4->setMinimumSize(QSize(25, 25));

        horizontalLayout_37->addWidget(vMinVal4);


        verticalLayout_43->addLayout(horizontalLayout_37);


        formLayout_5->setLayout(2, QFormLayout::LabelRole, verticalLayout_43);

        verticalLayout_44 = new QVBoxLayout();
        verticalLayout_44->setObjectName(QStringLiteral("verticalLayout_44"));
        label_38 = new QLabel(layoutWidget_5);
        label_38->setObjectName(QStringLiteral("label_38"));
        label_38->setMaximumSize(QSize(16777215, 100));

        verticalLayout_44->addWidget(label_38);

        horizontalLayout_38 = new QHBoxLayout();
        horizontalLayout_38->setObjectName(QStringLiteral("horizontalLayout_38"));
        vMax4 = new QSlider(layoutWidget_5);
        vMax4->setObjectName(QStringLiteral("vMax4"));
        vMax4->setMinimumSize(QSize(150, 0));
        vMax4->setBaseSize(QSize(200, 100));
        vMax4->setMaximum(255);
        vMax4->setValue(255);
        vMax4->setOrientation(Qt::Horizontal);

        horizontalLayout_38->addWidget(vMax4);

        vMaxVal4 = new QLabel(layoutWidget_5);
        vMaxVal4->setObjectName(QStringLiteral("vMaxVal4"));
        vMaxVal4->setMinimumSize(QSize(25, 25));

        horizontalLayout_38->addWidget(vMaxVal4);


        verticalLayout_44->addLayout(horizontalLayout_38);


        formLayout_5->setLayout(2, QFormLayout::FieldRole, verticalLayout_44);

        verticalLayout_45 = new QVBoxLayout();
        verticalLayout_45->setObjectName(QStringLiteral("verticalLayout_45"));
        label_39 = new QLabel(layoutWidget_5);
        label_39->setObjectName(QStringLiteral("label_39"));
        label_39->setMaximumSize(QSize(16777215, 100));

        verticalLayout_45->addWidget(label_39);

        horizontalLayout_39 = new QHBoxLayout();
        horizontalLayout_39->setObjectName(QStringLiteral("horizontalLayout_39"));
        erode4 = new QSlider(layoutWidget_5);
        erode4->setObjectName(QStringLiteral("erode4"));
        erode4->setMinimumSize(QSize(200, 0));
        erode4->setBaseSize(QSize(200, 100));
        erode4->setMaximum(20);
        erode4->setOrientation(Qt::Horizontal);

        horizontalLayout_39->addWidget(erode4);

        erodeVal4 = new QLabel(layoutWidget_5);
        erodeVal4->setObjectName(QStringLiteral("erodeVal4"));
        erodeVal4->setMinimumSize(QSize(25, 25));

        horizontalLayout_39->addWidget(erodeVal4);


        verticalLayout_45->addLayout(horizontalLayout_39);


        formLayout_5->setLayout(3, QFormLayout::LabelRole, verticalLayout_45);

        verticalLayout_46 = new QVBoxLayout();
        verticalLayout_46->setObjectName(QStringLiteral("verticalLayout_46"));
        label_40 = new QLabel(layoutWidget_5);
        label_40->setObjectName(QStringLiteral("label_40"));
        label_40->setMaximumSize(QSize(16777215, 100));

        verticalLayout_46->addWidget(label_40);

        horizontalLayout_40 = new QHBoxLayout();
        horizontalLayout_40->setObjectName(QStringLiteral("horizontalLayout_40"));
        dilate4 = new QSlider(layoutWidget_5);
        dilate4->setObjectName(QStringLiteral("dilate4"));
        dilate4->setMinimumSize(QSize(150, 0));
        dilate4->setBaseSize(QSize(200, 100));
        dilate4->setMaximum(20);
        dilate4->setOrientation(Qt::Horizontal);

        horizontalLayout_40->addWidget(dilate4);

        dilateVal4 = new QLabel(layoutWidget_5);
        dilateVal4->setObjectName(QStringLiteral("dilateVal4"));
        dilateVal4->setMinimumSize(QSize(25, 25));

        horizontalLayout_40->addWidget(dilateVal4);


        verticalLayout_46->addLayout(horizontalLayout_40);


        formLayout_5->setLayout(3, QFormLayout::FieldRole, verticalLayout_46);


        verticalLayout_38->addLayout(formLayout_5);

        stackedWidget->addWidget(warna4);
        warna5 = new QWidget();
        warna5->setObjectName(QStringLiteral("warna5"));
        layoutWidget_6 = new QWidget(warna5);
        layoutWidget_6->setObjectName(QStringLiteral("layoutWidget_6"));
        layoutWidget_6->setGeometry(QRect(0, 0, 501, 631));
        verticalLayout_47 = new QVBoxLayout(layoutWidget_6);
        verticalLayout_47->setObjectName(QStringLiteral("verticalLayout_47"));
        verticalLayout_47->setContentsMargins(0, 0, 0, 0);
        labelWarna5 = new QLabel(layoutWidget_6);
        labelWarna5->setObjectName(QStringLiteral("labelWarna5"));
        labelWarna5->setMinimumSize(QSize(480, 360));
        labelWarna5->setBaseSize(QSize(480, 360));
        labelWarna5->setFrameShape(QFrame::Box);

        verticalLayout_47->addWidget(labelWarna5);

        formLayout_6 = new QFormLayout();
        formLayout_6->setObjectName(QStringLiteral("formLayout_6"));
        verticalLayout_48 = new QVBoxLayout();
        verticalLayout_48->setObjectName(QStringLiteral("verticalLayout_48"));
        label_41 = new QLabel(layoutWidget_6);
        label_41->setObjectName(QStringLiteral("label_41"));
        label_41->setMaximumSize(QSize(16777215, 100));

        verticalLayout_48->addWidget(label_41);

        horizontalLayout_41 = new QHBoxLayout();
        horizontalLayout_41->setObjectName(QStringLiteral("horizontalLayout_41"));
        hMin5 = new QSlider(layoutWidget_6);
        hMin5->setObjectName(QStringLiteral("hMin5"));
        hMin5->setMinimumSize(QSize(200, 0));
        hMin5->setBaseSize(QSize(200, 100));
        hMin5->setMaximum(255);
        hMin5->setOrientation(Qt::Horizontal);

        horizontalLayout_41->addWidget(hMin5);

        hMinVal5 = new QLabel(layoutWidget_6);
        hMinVal5->setObjectName(QStringLiteral("hMinVal5"));
        hMinVal5->setMinimumSize(QSize(25, 25));

        horizontalLayout_41->addWidget(hMinVal5);


        verticalLayout_48->addLayout(horizontalLayout_41);


        formLayout_6->setLayout(0, QFormLayout::LabelRole, verticalLayout_48);

        verticalLayout_49 = new QVBoxLayout();
        verticalLayout_49->setObjectName(QStringLiteral("verticalLayout_49"));
        label_42 = new QLabel(layoutWidget_6);
        label_42->setObjectName(QStringLiteral("label_42"));
        label_42->setMaximumSize(QSize(16777215, 100));

        verticalLayout_49->addWidget(label_42);

        horizontalLayout_42 = new QHBoxLayout();
        horizontalLayout_42->setObjectName(QStringLiteral("horizontalLayout_42"));
        hMax5 = new QSlider(layoutWidget_6);
        hMax5->setObjectName(QStringLiteral("hMax5"));
        hMax5->setMinimumSize(QSize(150, 0));
        hMax5->setBaseSize(QSize(200, 100));
        hMax5->setMaximum(255);
        hMax5->setValue(255);
        hMax5->setOrientation(Qt::Horizontal);

        horizontalLayout_42->addWidget(hMax5);

        hMaxVal5 = new QLabel(layoutWidget_6);
        hMaxVal5->setObjectName(QStringLiteral("hMaxVal5"));
        hMaxVal5->setMinimumSize(QSize(25, 25));

        horizontalLayout_42->addWidget(hMaxVal5);


        verticalLayout_49->addLayout(horizontalLayout_42);


        formLayout_6->setLayout(0, QFormLayout::FieldRole, verticalLayout_49);

        verticalLayout_50 = new QVBoxLayout();
        verticalLayout_50->setObjectName(QStringLiteral("verticalLayout_50"));
        label_43 = new QLabel(layoutWidget_6);
        label_43->setObjectName(QStringLiteral("label_43"));
        label_43->setMaximumSize(QSize(16777215, 100));

        verticalLayout_50->addWidget(label_43);

        horizontalLayout_43 = new QHBoxLayout();
        horizontalLayout_43->setObjectName(QStringLiteral("horizontalLayout_43"));
        sMin5 = new QSlider(layoutWidget_6);
        sMin5->setObjectName(QStringLiteral("sMin5"));
        sMin5->setMinimumSize(QSize(200, 0));
        sMin5->setBaseSize(QSize(200, 100));
        sMin5->setMaximum(255);
        sMin5->setOrientation(Qt::Horizontal);

        horizontalLayout_43->addWidget(sMin5);

        sMinVal5 = new QLabel(layoutWidget_6);
        sMinVal5->setObjectName(QStringLiteral("sMinVal5"));
        sMinVal5->setMinimumSize(QSize(25, 25));

        horizontalLayout_43->addWidget(sMinVal5);


        verticalLayout_50->addLayout(horizontalLayout_43);


        formLayout_6->setLayout(1, QFormLayout::LabelRole, verticalLayout_50);

        verticalLayout_51 = new QVBoxLayout();
        verticalLayout_51->setObjectName(QStringLiteral("verticalLayout_51"));
        label_44 = new QLabel(layoutWidget_6);
        label_44->setObjectName(QStringLiteral("label_44"));
        label_44->setMaximumSize(QSize(16777215, 100));

        verticalLayout_51->addWidget(label_44);

        horizontalLayout_44 = new QHBoxLayout();
        horizontalLayout_44->setObjectName(QStringLiteral("horizontalLayout_44"));
        sMax5 = new QSlider(layoutWidget_6);
        sMax5->setObjectName(QStringLiteral("sMax5"));
        sMax5->setMinimumSize(QSize(150, 0));
        sMax5->setBaseSize(QSize(200, 100));
        sMax5->setMaximum(255);
        sMax5->setValue(255);
        sMax5->setOrientation(Qt::Horizontal);

        horizontalLayout_44->addWidget(sMax5);

        sMaxVal5 = new QLabel(layoutWidget_6);
        sMaxVal5->setObjectName(QStringLiteral("sMaxVal5"));
        sMaxVal5->setMinimumSize(QSize(25, 25));

        horizontalLayout_44->addWidget(sMaxVal5);


        verticalLayout_51->addLayout(horizontalLayout_44);


        formLayout_6->setLayout(1, QFormLayout::FieldRole, verticalLayout_51);

        verticalLayout_52 = new QVBoxLayout();
        verticalLayout_52->setObjectName(QStringLiteral("verticalLayout_52"));
        label_45 = new QLabel(layoutWidget_6);
        label_45->setObjectName(QStringLiteral("label_45"));
        label_45->setMaximumSize(QSize(16777215, 100));

        verticalLayout_52->addWidget(label_45);

        horizontalLayout_45 = new QHBoxLayout();
        horizontalLayout_45->setObjectName(QStringLiteral("horizontalLayout_45"));
        vMin5 = new QSlider(layoutWidget_6);
        vMin5->setObjectName(QStringLiteral("vMin5"));
        vMin5->setMinimumSize(QSize(200, 0));
        vMin5->setBaseSize(QSize(200, 100));
        vMin5->setMaximum(255);
        vMin5->setOrientation(Qt::Horizontal);

        horizontalLayout_45->addWidget(vMin5);

        vMinVal5 = new QLabel(layoutWidget_6);
        vMinVal5->setObjectName(QStringLiteral("vMinVal5"));
        vMinVal5->setMinimumSize(QSize(25, 25));

        horizontalLayout_45->addWidget(vMinVal5);


        verticalLayout_52->addLayout(horizontalLayout_45);


        formLayout_6->setLayout(2, QFormLayout::LabelRole, verticalLayout_52);

        verticalLayout_53 = new QVBoxLayout();
        verticalLayout_53->setObjectName(QStringLiteral("verticalLayout_53"));
        label_46 = new QLabel(layoutWidget_6);
        label_46->setObjectName(QStringLiteral("label_46"));
        label_46->setMaximumSize(QSize(16777215, 100));

        verticalLayout_53->addWidget(label_46);

        horizontalLayout_46 = new QHBoxLayout();
        horizontalLayout_46->setObjectName(QStringLiteral("horizontalLayout_46"));
        vMax5 = new QSlider(layoutWidget_6);
        vMax5->setObjectName(QStringLiteral("vMax5"));
        vMax5->setMinimumSize(QSize(150, 0));
        vMax5->setBaseSize(QSize(200, 100));
        vMax5->setMaximum(255);
        vMax5->setValue(255);
        vMax5->setOrientation(Qt::Horizontal);

        horizontalLayout_46->addWidget(vMax5);

        vMaxVal5 = new QLabel(layoutWidget_6);
        vMaxVal5->setObjectName(QStringLiteral("vMaxVal5"));
        vMaxVal5->setMinimumSize(QSize(25, 25));

        horizontalLayout_46->addWidget(vMaxVal5);


        verticalLayout_53->addLayout(horizontalLayout_46);


        formLayout_6->setLayout(2, QFormLayout::FieldRole, verticalLayout_53);

        verticalLayout_54 = new QVBoxLayout();
        verticalLayout_54->setObjectName(QStringLiteral("verticalLayout_54"));
        label_47 = new QLabel(layoutWidget_6);
        label_47->setObjectName(QStringLiteral("label_47"));
        label_47->setMaximumSize(QSize(16777215, 100));

        verticalLayout_54->addWidget(label_47);

        horizontalLayout_47 = new QHBoxLayout();
        horizontalLayout_47->setObjectName(QStringLiteral("horizontalLayout_47"));
        erode5 = new QSlider(layoutWidget_6);
        erode5->setObjectName(QStringLiteral("erode5"));
        erode5->setMinimumSize(QSize(200, 0));
        erode5->setBaseSize(QSize(200, 100));
        erode5->setMaximum(20);
        erode5->setOrientation(Qt::Horizontal);

        horizontalLayout_47->addWidget(erode5);

        erodeVal5 = new QLabel(layoutWidget_6);
        erodeVal5->setObjectName(QStringLiteral("erodeVal5"));
        erodeVal5->setMinimumSize(QSize(25, 25));

        horizontalLayout_47->addWidget(erodeVal5);


        verticalLayout_54->addLayout(horizontalLayout_47);


        formLayout_6->setLayout(3, QFormLayout::LabelRole, verticalLayout_54);

        verticalLayout_55 = new QVBoxLayout();
        verticalLayout_55->setObjectName(QStringLiteral("verticalLayout_55"));
        label_48 = new QLabel(layoutWidget_6);
        label_48->setObjectName(QStringLiteral("label_48"));
        label_48->setMaximumSize(QSize(16777215, 100));

        verticalLayout_55->addWidget(label_48);

        horizontalLayout_48 = new QHBoxLayout();
        horizontalLayout_48->setObjectName(QStringLiteral("horizontalLayout_48"));
        dilate5 = new QSlider(layoutWidget_6);
        dilate5->setObjectName(QStringLiteral("dilate5"));
        dilate5->setMinimumSize(QSize(150, 0));
        dilate5->setBaseSize(QSize(200, 100));
        dilate5->setMaximum(20);
        dilate5->setOrientation(Qt::Horizontal);

        horizontalLayout_48->addWidget(dilate5);

        dilateVal5 = new QLabel(layoutWidget_6);
        dilateVal5->setObjectName(QStringLiteral("dilateVal5"));
        dilateVal5->setMinimumSize(QSize(25, 25));

        horizontalLayout_48->addWidget(dilateVal5);


        verticalLayout_55->addLayout(horizontalLayout_48);


        formLayout_6->setLayout(3, QFormLayout::FieldRole, verticalLayout_55);


        verticalLayout_47->addLayout(formLayout_6);

        stackedWidget->addWidget(warna5);
        warna6 = new QWidget();
        warna6->setObjectName(QStringLiteral("warna6"));
        layoutWidget_7 = new QWidget(warna6);
        layoutWidget_7->setObjectName(QStringLiteral("layoutWidget_7"));
        layoutWidget_7->setGeometry(QRect(0, 0, 501, 621));
        verticalLayout_56 = new QVBoxLayout(layoutWidget_7);
        verticalLayout_56->setObjectName(QStringLiteral("verticalLayout_56"));
        verticalLayout_56->setContentsMargins(0, 0, 0, 0);
        labelWarna5_2 = new QLabel(layoutWidget_7);
        labelWarna5_2->setObjectName(QStringLiteral("labelWarna5_2"));
        labelWarna5_2->setMinimumSize(QSize(480, 360));
        labelWarna5_2->setBaseSize(QSize(480, 360));
        labelWarna5_2->setFrameShape(QFrame::Box);

        verticalLayout_56->addWidget(labelWarna5_2);

        formLayout_7 = new QFormLayout();
        formLayout_7->setObjectName(QStringLiteral("formLayout_7"));
        verticalLayout_57 = new QVBoxLayout();
        verticalLayout_57->setObjectName(QStringLiteral("verticalLayout_57"));
        label_56 = new QLabel(layoutWidget_7);
        label_56->setObjectName(QStringLiteral("label_56"));
        label_56->setMaximumSize(QSize(16777215, 100));

        verticalLayout_57->addWidget(label_56);

        horizontalLayout_49 = new QHBoxLayout();
        horizontalLayout_49->setObjectName(QStringLiteral("horizontalLayout_49"));
        hMin6 = new QSlider(layoutWidget_7);
        hMin6->setObjectName(QStringLiteral("hMin6"));
        hMin6->setMinimumSize(QSize(200, 0));
        hMin6->setBaseSize(QSize(200, 100));
        hMin6->setMaximum(255);
        hMin6->setOrientation(Qt::Horizontal);

        horizontalLayout_49->addWidget(hMin6);

        hMinVal6 = new QLabel(layoutWidget_7);
        hMinVal6->setObjectName(QStringLiteral("hMinVal6"));
        hMinVal6->setMinimumSize(QSize(25, 25));

        horizontalLayout_49->addWidget(hMinVal6);


        verticalLayout_57->addLayout(horizontalLayout_49);


        formLayout_7->setLayout(0, QFormLayout::LabelRole, verticalLayout_57);

        verticalLayout_58 = new QVBoxLayout();
        verticalLayout_58->setObjectName(QStringLiteral("verticalLayout_58"));
        label_57 = new QLabel(layoutWidget_7);
        label_57->setObjectName(QStringLiteral("label_57"));
        label_57->setMaximumSize(QSize(16777215, 100));

        verticalLayout_58->addWidget(label_57);

        horizontalLayout_53 = new QHBoxLayout();
        horizontalLayout_53->setObjectName(QStringLiteral("horizontalLayout_53"));
        hMax6 = new QSlider(layoutWidget_7);
        hMax6->setObjectName(QStringLiteral("hMax6"));
        hMax6->setMinimumSize(QSize(150, 0));
        hMax6->setBaseSize(QSize(200, 100));
        hMax6->setMaximum(255);
        hMax6->setValue(255);
        hMax6->setOrientation(Qt::Horizontal);

        horizontalLayout_53->addWidget(hMax6);

        hMaxVal6 = new QLabel(layoutWidget_7);
        hMaxVal6->setObjectName(QStringLiteral("hMaxVal6"));
        hMaxVal6->setMinimumSize(QSize(25, 25));

        horizontalLayout_53->addWidget(hMaxVal6);


        verticalLayout_58->addLayout(horizontalLayout_53);


        formLayout_7->setLayout(0, QFormLayout::FieldRole, verticalLayout_58);

        verticalLayout_59 = new QVBoxLayout();
        verticalLayout_59->setObjectName(QStringLiteral("verticalLayout_59"));
        label_61 = new QLabel(layoutWidget_7);
        label_61->setObjectName(QStringLiteral("label_61"));
        label_61->setMaximumSize(QSize(16777215, 100));

        verticalLayout_59->addWidget(label_61);

        horizontalLayout_54 = new QHBoxLayout();
        horizontalLayout_54->setObjectName(QStringLiteral("horizontalLayout_54"));
        sMin6 = new QSlider(layoutWidget_7);
        sMin6->setObjectName(QStringLiteral("sMin6"));
        sMin6->setMinimumSize(QSize(200, 0));
        sMin6->setBaseSize(QSize(200, 100));
        sMin6->setMaximum(255);
        sMin6->setOrientation(Qt::Horizontal);

        horizontalLayout_54->addWidget(sMin6);

        sMinVal6 = new QLabel(layoutWidget_7);
        sMinVal6->setObjectName(QStringLiteral("sMinVal6"));
        sMinVal6->setMinimumSize(QSize(25, 25));

        horizontalLayout_54->addWidget(sMinVal6);


        verticalLayout_59->addLayout(horizontalLayout_54);


        formLayout_7->setLayout(1, QFormLayout::LabelRole, verticalLayout_59);

        verticalLayout_60 = new QVBoxLayout();
        verticalLayout_60->setObjectName(QStringLiteral("verticalLayout_60"));
        label_123 = new QLabel(layoutWidget_7);
        label_123->setObjectName(QStringLiteral("label_123"));
        label_123->setMaximumSize(QSize(16777215, 100));

        verticalLayout_60->addWidget(label_123);

        horizontalLayout_55 = new QHBoxLayout();
        horizontalLayout_55->setObjectName(QStringLiteral("horizontalLayout_55"));
        sMax6 = new QSlider(layoutWidget_7);
        sMax6->setObjectName(QStringLiteral("sMax6"));
        sMax6->setMinimumSize(QSize(150, 0));
        sMax6->setBaseSize(QSize(200, 100));
        sMax6->setMaximum(255);
        sMax6->setValue(255);
        sMax6->setOrientation(Qt::Horizontal);

        horizontalLayout_55->addWidget(sMax6);

        sMaxVal6 = new QLabel(layoutWidget_7);
        sMaxVal6->setObjectName(QStringLiteral("sMaxVal6"));
        sMaxVal6->setMinimumSize(QSize(25, 25));

        horizontalLayout_55->addWidget(sMaxVal6);


        verticalLayout_60->addLayout(horizontalLayout_55);


        formLayout_7->setLayout(1, QFormLayout::FieldRole, verticalLayout_60);

        verticalLayout_61 = new QVBoxLayout();
        verticalLayout_61->setObjectName(QStringLiteral("verticalLayout_61"));
        label_124 = new QLabel(layoutWidget_7);
        label_124->setObjectName(QStringLiteral("label_124"));
        label_124->setMaximumSize(QSize(16777215, 100));

        verticalLayout_61->addWidget(label_124);

        horizontalLayout_56 = new QHBoxLayout();
        horizontalLayout_56->setObjectName(QStringLiteral("horizontalLayout_56"));
        vMin6 = new QSlider(layoutWidget_7);
        vMin6->setObjectName(QStringLiteral("vMin6"));
        vMin6->setMinimumSize(QSize(200, 0));
        vMin6->setBaseSize(QSize(200, 100));
        vMin6->setMaximum(255);
        vMin6->setOrientation(Qt::Horizontal);

        horizontalLayout_56->addWidget(vMin6);

        vMinVal6 = new QLabel(layoutWidget_7);
        vMinVal6->setObjectName(QStringLiteral("vMinVal6"));
        vMinVal6->setMinimumSize(QSize(25, 25));

        horizontalLayout_56->addWidget(vMinVal6);


        verticalLayout_61->addLayout(horizontalLayout_56);


        formLayout_7->setLayout(2, QFormLayout::LabelRole, verticalLayout_61);

        verticalLayout_62 = new QVBoxLayout();
        verticalLayout_62->setObjectName(QStringLiteral("verticalLayout_62"));
        label_125 = new QLabel(layoutWidget_7);
        label_125->setObjectName(QStringLiteral("label_125"));
        label_125->setMaximumSize(QSize(16777215, 100));

        verticalLayout_62->addWidget(label_125);

        horizontalLayout_57 = new QHBoxLayout();
        horizontalLayout_57->setObjectName(QStringLiteral("horizontalLayout_57"));
        vMax6 = new QSlider(layoutWidget_7);
        vMax6->setObjectName(QStringLiteral("vMax6"));
        vMax6->setMinimumSize(QSize(150, 0));
        vMax6->setBaseSize(QSize(200, 100));
        vMax6->setMaximum(255);
        vMax6->setValue(255);
        vMax6->setOrientation(Qt::Horizontal);

        horizontalLayout_57->addWidget(vMax6);

        vMaxVal6 = new QLabel(layoutWidget_7);
        vMaxVal6->setObjectName(QStringLiteral("vMaxVal6"));
        vMaxVal6->setMinimumSize(QSize(25, 25));

        horizontalLayout_57->addWidget(vMaxVal6);


        verticalLayout_62->addLayout(horizontalLayout_57);


        formLayout_7->setLayout(2, QFormLayout::FieldRole, verticalLayout_62);

        verticalLayout_63 = new QVBoxLayout();
        verticalLayout_63->setObjectName(QStringLiteral("verticalLayout_63"));
        label_126 = new QLabel(layoutWidget_7);
        label_126->setObjectName(QStringLiteral("label_126"));
        label_126->setMaximumSize(QSize(16777215, 100));

        verticalLayout_63->addWidget(label_126);

        horizontalLayout_58 = new QHBoxLayout();
        horizontalLayout_58->setObjectName(QStringLiteral("horizontalLayout_58"));
        erode6 = new QSlider(layoutWidget_7);
        erode6->setObjectName(QStringLiteral("erode6"));
        erode6->setMinimumSize(QSize(200, 0));
        erode6->setBaseSize(QSize(200, 100));
        erode6->setMaximum(20);
        erode6->setOrientation(Qt::Horizontal);

        horizontalLayout_58->addWidget(erode6);

        erodeVal6 = new QLabel(layoutWidget_7);
        erodeVal6->setObjectName(QStringLiteral("erodeVal6"));
        erodeVal6->setMinimumSize(QSize(25, 25));

        horizontalLayout_58->addWidget(erodeVal6);


        verticalLayout_63->addLayout(horizontalLayout_58);


        formLayout_7->setLayout(3, QFormLayout::LabelRole, verticalLayout_63);

        verticalLayout_64 = new QVBoxLayout();
        verticalLayout_64->setObjectName(QStringLiteral("verticalLayout_64"));
        label_127 = new QLabel(layoutWidget_7);
        label_127->setObjectName(QStringLiteral("label_127"));
        label_127->setMaximumSize(QSize(16777215, 100));

        verticalLayout_64->addWidget(label_127);

        horizontalLayout_59 = new QHBoxLayout();
        horizontalLayout_59->setObjectName(QStringLiteral("horizontalLayout_59"));
        dilate6 = new QSlider(layoutWidget_7);
        dilate6->setObjectName(QStringLiteral("dilate6"));
        dilate6->setMinimumSize(QSize(150, 0));
        dilate6->setBaseSize(QSize(200, 100));
        dilate6->setMaximum(20);
        dilate6->setOrientation(Qt::Horizontal);

        horizontalLayout_59->addWidget(dilate6);

        dilateVal6 = new QLabel(layoutWidget_7);
        dilateVal6->setObjectName(QStringLiteral("dilateVal6"));
        dilateVal6->setMinimumSize(QSize(25, 25));

        horizontalLayout_59->addWidget(dilateVal6);


        verticalLayout_64->addLayout(horizontalLayout_59);


        formLayout_7->setLayout(3, QFormLayout::FieldRole, verticalLayout_64);


        verticalLayout_56->addLayout(formLayout_7);

        stackedWidget->addWidget(warna6);
        page = new QWidget();
        page->setObjectName(QStringLiteral("page"));
        layoutWidget_8 = new QWidget(page);
        layoutWidget_8->setObjectName(QStringLiteral("layoutWidget_8"));
        layoutWidget_8->setGeometry(QRect(0, 0, 501, 621));
        verticalLayout_65 = new QVBoxLayout(layoutWidget_8);
        verticalLayout_65->setObjectName(QStringLiteral("verticalLayout_65"));
        verticalLayout_65->setContentsMargins(0, 0, 0, 0);
        labelWarna5_3 = new QLabel(layoutWidget_8);
        labelWarna5_3->setObjectName(QStringLiteral("labelWarna5_3"));
        labelWarna5_3->setMinimumSize(QSize(480, 360));
        labelWarna5_3->setBaseSize(QSize(480, 360));
        labelWarna5_3->setFrameShape(QFrame::Box);

        verticalLayout_65->addWidget(labelWarna5_3);

        formLayout_8 = new QFormLayout();
        formLayout_8->setObjectName(QStringLiteral("formLayout_8"));
        verticalLayout_66 = new QVBoxLayout();
        verticalLayout_66->setObjectName(QStringLiteral("verticalLayout_66"));
        label_128 = new QLabel(layoutWidget_8);
        label_128->setObjectName(QStringLiteral("label_128"));
        label_128->setMaximumSize(QSize(16777215, 100));

        verticalLayout_66->addWidget(label_128);

        horizontalLayout_60 = new QHBoxLayout();
        horizontalLayout_60->setObjectName(QStringLiteral("horizontalLayout_60"));
        hMin7 = new QSlider(layoutWidget_8);
        hMin7->setObjectName(QStringLiteral("hMin7"));
        hMin7->setMinimumSize(QSize(200, 0));
        hMin7->setBaseSize(QSize(200, 100));
        hMin7->setMaximum(255);
        hMin7->setOrientation(Qt::Horizontal);

        horizontalLayout_60->addWidget(hMin7);

        hMinVal7 = new QLabel(layoutWidget_8);
        hMinVal7->setObjectName(QStringLiteral("hMinVal7"));
        hMinVal7->setMinimumSize(QSize(25, 25));

        horizontalLayout_60->addWidget(hMinVal7);


        verticalLayout_66->addLayout(horizontalLayout_60);


        formLayout_8->setLayout(0, QFormLayout::LabelRole, verticalLayout_66);

        verticalLayout_67 = new QVBoxLayout();
        verticalLayout_67->setObjectName(QStringLiteral("verticalLayout_67"));
        label_129 = new QLabel(layoutWidget_8);
        label_129->setObjectName(QStringLiteral("label_129"));
        label_129->setMaximumSize(QSize(16777215, 100));

        verticalLayout_67->addWidget(label_129);

        horizontalLayout_61 = new QHBoxLayout();
        horizontalLayout_61->setObjectName(QStringLiteral("horizontalLayout_61"));
        hMax7 = new QSlider(layoutWidget_8);
        hMax7->setObjectName(QStringLiteral("hMax7"));
        hMax7->setMinimumSize(QSize(150, 0));
        hMax7->setBaseSize(QSize(200, 100));
        hMax7->setMaximum(255);
        hMax7->setValue(255);
        hMax7->setOrientation(Qt::Horizontal);

        horizontalLayout_61->addWidget(hMax7);

        hMaxVal7 = new QLabel(layoutWidget_8);
        hMaxVal7->setObjectName(QStringLiteral("hMaxVal7"));
        hMaxVal7->setMinimumSize(QSize(25, 25));

        horizontalLayout_61->addWidget(hMaxVal7);


        verticalLayout_67->addLayout(horizontalLayout_61);


        formLayout_8->setLayout(0, QFormLayout::FieldRole, verticalLayout_67);

        verticalLayout_68 = new QVBoxLayout();
        verticalLayout_68->setObjectName(QStringLiteral("verticalLayout_68"));
        label_130 = new QLabel(layoutWidget_8);
        label_130->setObjectName(QStringLiteral("label_130"));
        label_130->setMaximumSize(QSize(16777215, 100));

        verticalLayout_68->addWidget(label_130);

        horizontalLayout_62 = new QHBoxLayout();
        horizontalLayout_62->setObjectName(QStringLiteral("horizontalLayout_62"));
        sMin7 = new QSlider(layoutWidget_8);
        sMin7->setObjectName(QStringLiteral("sMin7"));
        sMin7->setMinimumSize(QSize(200, 0));
        sMin7->setBaseSize(QSize(200, 100));
        sMin7->setMaximum(255);
        sMin7->setOrientation(Qt::Horizontal);

        horizontalLayout_62->addWidget(sMin7);

        sMinVal7 = new QLabel(layoutWidget_8);
        sMinVal7->setObjectName(QStringLiteral("sMinVal7"));
        sMinVal7->setMinimumSize(QSize(25, 25));

        horizontalLayout_62->addWidget(sMinVal7);


        verticalLayout_68->addLayout(horizontalLayout_62);


        formLayout_8->setLayout(1, QFormLayout::LabelRole, verticalLayout_68);

        verticalLayout_69 = new QVBoxLayout();
        verticalLayout_69->setObjectName(QStringLiteral("verticalLayout_69"));
        label_131 = new QLabel(layoutWidget_8);
        label_131->setObjectName(QStringLiteral("label_131"));
        label_131->setMaximumSize(QSize(16777215, 100));

        verticalLayout_69->addWidget(label_131);

        horizontalLayout_63 = new QHBoxLayout();
        horizontalLayout_63->setObjectName(QStringLiteral("horizontalLayout_63"));
        sMax7 = new QSlider(layoutWidget_8);
        sMax7->setObjectName(QStringLiteral("sMax7"));
        sMax7->setMinimumSize(QSize(150, 0));
        sMax7->setBaseSize(QSize(200, 100));
        sMax7->setMaximum(255);
        sMax7->setValue(255);
        sMax7->setOrientation(Qt::Horizontal);

        horizontalLayout_63->addWidget(sMax7);

        sMaxVal7 = new QLabel(layoutWidget_8);
        sMaxVal7->setObjectName(QStringLiteral("sMaxVal7"));
        sMaxVal7->setMinimumSize(QSize(25, 25));

        horizontalLayout_63->addWidget(sMaxVal7);


        verticalLayout_69->addLayout(horizontalLayout_63);


        formLayout_8->setLayout(1, QFormLayout::FieldRole, verticalLayout_69);

        verticalLayout_70 = new QVBoxLayout();
        verticalLayout_70->setObjectName(QStringLiteral("verticalLayout_70"));
        label_132 = new QLabel(layoutWidget_8);
        label_132->setObjectName(QStringLiteral("label_132"));
        label_132->setMaximumSize(QSize(16777215, 100));

        verticalLayout_70->addWidget(label_132);

        horizontalLayout_64 = new QHBoxLayout();
        horizontalLayout_64->setObjectName(QStringLiteral("horizontalLayout_64"));
        vMin7 = new QSlider(layoutWidget_8);
        vMin7->setObjectName(QStringLiteral("vMin7"));
        vMin7->setMinimumSize(QSize(200, 0));
        vMin7->setBaseSize(QSize(200, 100));
        vMin7->setMaximum(255);
        vMin7->setOrientation(Qt::Horizontal);

        horizontalLayout_64->addWidget(vMin7);

        vMinVal7 = new QLabel(layoutWidget_8);
        vMinVal7->setObjectName(QStringLiteral("vMinVal7"));
        vMinVal7->setMinimumSize(QSize(25, 25));

        horizontalLayout_64->addWidget(vMinVal7);


        verticalLayout_70->addLayout(horizontalLayout_64);


        formLayout_8->setLayout(2, QFormLayout::LabelRole, verticalLayout_70);

        verticalLayout_71 = new QVBoxLayout();
        verticalLayout_71->setObjectName(QStringLiteral("verticalLayout_71"));
        label_133 = new QLabel(layoutWidget_8);
        label_133->setObjectName(QStringLiteral("label_133"));
        label_133->setMaximumSize(QSize(16777215, 100));

        verticalLayout_71->addWidget(label_133);

        horizontalLayout_65 = new QHBoxLayout();
        horizontalLayout_65->setObjectName(QStringLiteral("horizontalLayout_65"));
        vMax7 = new QSlider(layoutWidget_8);
        vMax7->setObjectName(QStringLiteral("vMax7"));
        vMax7->setMinimumSize(QSize(150, 0));
        vMax7->setBaseSize(QSize(200, 100));
        vMax7->setMaximum(255);
        vMax7->setValue(255);
        vMax7->setOrientation(Qt::Horizontal);

        horizontalLayout_65->addWidget(vMax7);

        vMaxVal7 = new QLabel(layoutWidget_8);
        vMaxVal7->setObjectName(QStringLiteral("vMaxVal7"));
        vMaxVal7->setMinimumSize(QSize(25, 25));

        horizontalLayout_65->addWidget(vMaxVal7);


        verticalLayout_71->addLayout(horizontalLayout_65);


        formLayout_8->setLayout(2, QFormLayout::FieldRole, verticalLayout_71);

        verticalLayout_72 = new QVBoxLayout();
        verticalLayout_72->setObjectName(QStringLiteral("verticalLayout_72"));
        label_134 = new QLabel(layoutWidget_8);
        label_134->setObjectName(QStringLiteral("label_134"));
        label_134->setMaximumSize(QSize(16777215, 100));

        verticalLayout_72->addWidget(label_134);

        horizontalLayout_66 = new QHBoxLayout();
        horizontalLayout_66->setObjectName(QStringLiteral("horizontalLayout_66"));
        erode7 = new QSlider(layoutWidget_8);
        erode7->setObjectName(QStringLiteral("erode7"));
        erode7->setMinimumSize(QSize(200, 0));
        erode7->setBaseSize(QSize(200, 100));
        erode7->setMaximum(20);
        erode7->setOrientation(Qt::Horizontal);

        horizontalLayout_66->addWidget(erode7);

        erodeVal7 = new QLabel(layoutWidget_8);
        erodeVal7->setObjectName(QStringLiteral("erodeVal7"));
        erodeVal7->setMinimumSize(QSize(25, 25));

        horizontalLayout_66->addWidget(erodeVal7);


        verticalLayout_72->addLayout(horizontalLayout_66);


        formLayout_8->setLayout(3, QFormLayout::LabelRole, verticalLayout_72);

        verticalLayout_73 = new QVBoxLayout();
        verticalLayout_73->setObjectName(QStringLiteral("verticalLayout_73"));
        label_135 = new QLabel(layoutWidget_8);
        label_135->setObjectName(QStringLiteral("label_135"));
        label_135->setMaximumSize(QSize(16777215, 100));

        verticalLayout_73->addWidget(label_135);

        horizontalLayout_67 = new QHBoxLayout();
        horizontalLayout_67->setObjectName(QStringLiteral("horizontalLayout_67"));
        dilate7 = new QSlider(layoutWidget_8);
        dilate7->setObjectName(QStringLiteral("dilate7"));
        dilate7->setMinimumSize(QSize(150, 0));
        dilate7->setBaseSize(QSize(200, 100));
        dilate7->setMaximum(20);
        dilate7->setOrientation(Qt::Horizontal);

        horizontalLayout_67->addWidget(dilate7);

        dilateVal7 = new QLabel(layoutWidget_8);
        dilateVal7->setObjectName(QStringLiteral("dilateVal7"));
        dilateVal7->setMinimumSize(QSize(25, 25));

        horizontalLayout_67->addWidget(dilateVal7);


        verticalLayout_73->addLayout(horizontalLayout_67);


        formLayout_8->setLayout(3, QFormLayout::FieldRole, verticalLayout_73);


        verticalLayout_65->addLayout(formLayout_8);

        stackedWidget->addWidget(page);

        verticalLayout_10->addWidget(stackedWidget);

        groupBox_13 = new QGroupBox(tabCamera);
        groupBox_13->setObjectName(QStringLiteral("groupBox_13"));
        groupBox_13->setGeometry(QRect(20, 460, 161, 131));
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(true);
        font1.setItalic(true);
        font1.setWeight(75);
        groupBox_13->setFont(font1);
        label_69 = new QLabel(groupBox_13);
        label_69->setObjectName(QStringLiteral("label_69"));
        label_69->setGeometry(QRect(10, 40, 55, 16));
        QFont font2;
        font2.setPointSize(8);
        font2.setBold(false);
        font2.setItalic(false);
        font2.setWeight(50);
        label_69->setFont(font2);
        label_106 = new QLabel(groupBox_13);
        label_106->setObjectName(QStringLiteral("label_106"));
        label_106->setGeometry(QRect(10, 100, 55, 16));
        label_106->setFont(font2);
        label_107 = new QLabel(groupBox_13);
        label_107->setObjectName(QStringLiteral("label_107"));
        label_107->setGeometry(QRect(10, 70, 55, 16));
        label_107->setFont(font2);
        spinBoxP1 = new QSpinBox(groupBox_13);
        spinBoxP1->setObjectName(QStringLiteral("spinBoxP1"));
        spinBoxP1->setGeometry(QRect(50, 40, 91, 22));
        QFont font3;
        font3.setPointSize(10);
        font3.setBold(false);
        font3.setItalic(false);
        font3.setWeight(50);
        spinBoxP1->setFont(font3);
        spinBoxP1->setMaximum(1000);
        spinBoxI1 = new QSpinBox(groupBox_13);
        spinBoxI1->setObjectName(QStringLiteral("spinBoxI1"));
        spinBoxI1->setGeometry(QRect(50, 70, 91, 22));
        spinBoxI1->setFont(font3);
        spinBoxI1->setMaximum(1000);
        spinBoxD1 = new QSpinBox(groupBox_13);
        spinBoxD1->setObjectName(QStringLiteral("spinBoxD1"));
        spinBoxD1->setGeometry(QRect(50, 100, 91, 22));
        spinBoxD1->setFont(font3);
        spinBoxD1->setMaximum(1000);
        groupBox_14 = new QGroupBox(tabCamera);
        groupBox_14->setObjectName(QStringLiteral("groupBox_14"));
        groupBox_14->setGeometry(QRect(180, 460, 161, 131));
        groupBox_14->setFont(font1);
        label_80 = new QLabel(groupBox_14);
        label_80->setObjectName(QStringLiteral("label_80"));
        label_80->setGeometry(QRect(10, 40, 55, 16));
        label_80->setFont(font2);
        label_108 = new QLabel(groupBox_14);
        label_108->setObjectName(QStringLiteral("label_108"));
        label_108->setGeometry(QRect(10, 100, 55, 16));
        label_108->setFont(font2);
        label_109 = new QLabel(groupBox_14);
        label_109->setObjectName(QStringLiteral("label_109"));
        label_109->setGeometry(QRect(10, 70, 55, 16));
        label_109->setFont(font2);
        spinBoxP2 = new QSpinBox(groupBox_14);
        spinBoxP2->setObjectName(QStringLiteral("spinBoxP2"));
        spinBoxP2->setGeometry(QRect(50, 40, 81, 22));
        spinBoxP2->setFont(font3);
        spinBoxI2 = new QSpinBox(groupBox_14);
        spinBoxI2->setObjectName(QStringLiteral("spinBoxI2"));
        spinBoxI2->setGeometry(QRect(50, 70, 81, 22));
        spinBoxI2->setFont(font3);
        spinBoxD2 = new QSpinBox(groupBox_14);
        spinBoxD2->setObjectName(QStringLiteral("spinBoxD2"));
        spinBoxD2->setGeometry(QRect(50, 100, 81, 22));
        spinBoxD2->setFont(font3);
        groupBox_15 = new QGroupBox(tabCamera);
        groupBox_15->setObjectName(QStringLiteral("groupBox_15"));
        groupBox_15->setGeometry(QRect(340, 460, 161, 131));
        groupBox_15->setFont(font1);
        label_87 = new QLabel(groupBox_15);
        label_87->setObjectName(QStringLiteral("label_87"));
        label_87->setGeometry(QRect(10, 40, 55, 16));
        label_87->setFont(font2);
        label_110 = new QLabel(groupBox_15);
        label_110->setObjectName(QStringLiteral("label_110"));
        label_110->setGeometry(QRect(10, 100, 55, 16));
        label_110->setFont(font2);
        spinBoxP3 = new QSpinBox(groupBox_15);
        spinBoxP3->setObjectName(QStringLiteral("spinBoxP3"));
        spinBoxP3->setGeometry(QRect(30, 40, 91, 22));
        spinBoxP3->setFont(font3);
        spinBoxP3->setMaximum(1000);
        spinBoxP3->setValue(10);
        label_111 = new QLabel(groupBox_15);
        label_111->setObjectName(QStringLiteral("label_111"));
        label_111->setGeometry(QRect(10, 70, 55, 16));
        label_111->setFont(font2);
        spinBoxD3 = new QSpinBox(groupBox_15);
        spinBoxD3->setObjectName(QStringLiteral("spinBoxD3"));
        spinBoxD3->setGeometry(QRect(30, 100, 91, 22));
        spinBoxD3->setFont(font3);
        spinBoxD3->setMaximum(1000);
        spinBoxD3->setValue(3);
        spinBoxI3 = new QSpinBox(groupBox_15);
        spinBoxI3->setObjectName(QStringLiteral("spinBoxI3"));
        spinBoxI3->setGeometry(QRect(30, 70, 91, 22));
        spinBoxI3->setFont(font3);
        spinBoxI3->setMaximum(500);
        spinBoxI3->setValue(1);
        groupBox_16 = new QGroupBox(tabCamera);
        groupBox_16->setObjectName(QStringLiteral("groupBox_16"));
        groupBox_16->setGeometry(QRect(20, 630, 161, 161));
        QFont font4;
        font4.setPointSize(10);
        font4.setBold(true);
        font4.setWeight(75);
        groupBox_16->setFont(font4);
        label_54 = new QLabel(groupBox_16);
        label_54->setObjectName(QStringLiteral("label_54"));
        label_54->setGeometry(QRect(10, 30, 61, 16));
        QFont font5;
        font5.setPointSize(8);
        font5.setBold(false);
        font5.setWeight(50);
        label_54->setFont(font5);
        spinBoxBatasY = new QSpinBox(groupBox_16);
        spinBoxBatasY->setObjectName(QStringLiteral("spinBoxBatasY"));
        spinBoxBatasY->setGeometry(QRect(70, 30, 61, 22));
        QFont font6;
        font6.setBold(false);
        font6.setWeight(50);
        spinBoxBatasY->setFont(font6);
        spinBoxBatasY->setMaximum(480);
        spinBoxBatasY->setValue(80);
        labelBarunastra1 = new QLabel(tabCamera);
        labelBarunastra1->setObjectName(QStringLiteral("labelBarunastra1"));
        labelBarunastra1->setGeometry(QRect(530, 670, 601, 111));
        labelBarunastra1->setPixmap(QPixmap(QString::fromUtf8("../../.designer/backup/Barunastra.png")));
        labelBarunastra1->setScaledContents(true);
        tabWidget->addTab(tabCamera, QString());
        labelBarunastra1->raise();
        startButton->raise();
        labelOri->raise();
        stopButton->raise();
        layoutWidget->raise();
        groupBox_13->raise();
        groupBox_14->raise();
        groupBox_15->raise();
        groupBox_16->raise();
        tabDroneConnection = new QWidget();
        tabDroneConnection->setObjectName(QStringLiteral("tabDroneConnection"));
        imgDrone = new QLabel(tabDroneConnection);
        imgDrone->setObjectName(QStringLiteral("imgDrone"));
        imgDrone->setGeometry(QRect(450, 40, 480, 720));
        imgDrone->setMinimumSize(QSize(480, 720));
        imgDrone->setMaximumSize(QSize(480, 720));
        imgDrone->setBaseSize(QSize(480, 720));
        imgDrone->setFrameShape(QFrame::Box);
        labelPrediction = new QLabel(tabDroneConnection);
        labelPrediction->setObjectName(QStringLiteral("labelPrediction"));
        labelPrediction->setGeometry(QRect(570, 800, 200, 41));
        labelPrediction->setMinimumSize(QSize(200, 0));
        labelPrediction->setFrameShape(QFrame::Box);
        layoutWidget1 = new QWidget(tabDroneConnection);
        layoutWidget1->setObjectName(QStringLiteral("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(20, 180, 253, 171));
        verticalLayout_22 = new QVBoxLayout(layoutWidget1);
        verticalLayout_22->setSpacing(10);
        verticalLayout_22->setObjectName(QStringLiteral("verticalLayout_22"));
        verticalLayout_22->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_52 = new QHBoxLayout();
        horizontalLayout_52->setObjectName(QStringLiteral("horizontalLayout_52"));
        label_50 = new QLabel(layoutWidget1);
        label_50->setObjectName(QStringLiteral("label_50"));

        horizontalLayout_52->addWidget(label_50);

        ipHP = new QLineEdit(layoutWidget1);
        ipHP->setObjectName(QStringLiteral("ipHP"));
        ipHP->setMinimumSize(QSize(200, 0));

        horizontalLayout_52->addWidget(ipHP);


        verticalLayout_22->addLayout(horizontalLayout_52);

        horizontalLayout_51 = new QHBoxLayout();
        horizontalLayout_51->setObjectName(QStringLiteral("horizontalLayout_51"));
        label_51 = new QLabel(layoutWidget1);
        label_51->setObjectName(QStringLiteral("label_51"));

        horizontalLayout_51->addWidget(label_51);

        portHP = new QLineEdit(layoutWidget1);
        portHP->setObjectName(QStringLiteral("portHP"));
        portHP->setMinimumSize(QSize(200, 0));

        horizontalLayout_51->addWidget(portHP);


        verticalLayout_22->addLayout(horizontalLayout_51);

        horizontalLayout_50 = new QHBoxLayout();
        horizontalLayout_50->setObjectName(QStringLiteral("horizontalLayout_50"));
        buttonConnectDrone = new QPushButton(layoutWidget1);
        buttonConnectDrone->setObjectName(QStringLiteral("buttonConnectDrone"));
        buttonConnectDrone->setMinimumSize(QSize(100, 0));

        horizontalLayout_50->addWidget(buttonConnectDrone);

        buttonDisconnectDrone = new QPushButton(layoutWidget1);
        buttonDisconnectDrone->setObjectName(QStringLiteral("buttonDisconnectDrone"));
        buttonDisconnectDrone->setMinimumSize(QSize(100, 0));

        horizontalLayout_50->addWidget(buttonDisconnectDrone);


        verticalLayout_22->addLayout(horizontalLayout_50);

        pushButtonTakePict = new QPushButton(tabDroneConnection);
        pushButtonTakePict->setObjectName(QStringLiteral("pushButtonTakePict"));
        pushButtonTakePict->setGeometry(QRect(30, 360, 93, 28));
        tabWidget->addTab(tabDroneConnection, QString());
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        scrollArea = new QScrollArea(tab);
        scrollArea->setObjectName(QStringLiteral("scrollArea"));
        scrollArea->setGeometry(QRect(20, 10, 611, 811));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QStringLiteral("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 609, 809));
        labelMapping = new kliklabelmappping(scrollAreaWidgetContents);
        labelMapping->setObjectName(QStringLiteral("labelMapping"));
        labelMapping->setEnabled(true);
        labelMapping->setGeometry(QRect(4, 5, 600, 800));
        labelMapping->setStyleSheet(QStringLiteral(""));
        labelMapping->setFrameShape(QFrame::Box);
        labelMapping->setLineWidth(1);
        scrollArea->setWidget(scrollAreaWidgetContents);
        tableWidgetWaypoint = new QTableWidget(tab);
        if (tableWidgetWaypoint->columnCount() < 2)
            tableWidgetWaypoint->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidgetWaypoint->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidgetWaypoint->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        if (tableWidgetWaypoint->rowCount() < 38)
            tableWidgetWaypoint->setRowCount(38);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(0, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(1, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(2, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(3, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(4, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(5, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(6, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(7, __qtablewidgetitem9);
        QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(8, __qtablewidgetitem10);
        QTableWidgetItem *__qtablewidgetitem11 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(9, __qtablewidgetitem11);
        QTableWidgetItem *__qtablewidgetitem12 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(10, __qtablewidgetitem12);
        QTableWidgetItem *__qtablewidgetitem13 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(11, __qtablewidgetitem13);
        QTableWidgetItem *__qtablewidgetitem14 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(12, __qtablewidgetitem14);
        QTableWidgetItem *__qtablewidgetitem15 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(13, __qtablewidgetitem15);
        QTableWidgetItem *__qtablewidgetitem16 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(14, __qtablewidgetitem16);
        QTableWidgetItem *__qtablewidgetitem17 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(15, __qtablewidgetitem17);
        QTableWidgetItem *__qtablewidgetitem18 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(16, __qtablewidgetitem18);
        QTableWidgetItem *__qtablewidgetitem19 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(17, __qtablewidgetitem19);
        QTableWidgetItem *__qtablewidgetitem20 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(18, __qtablewidgetitem20);
        QTableWidgetItem *__qtablewidgetitem21 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(19, __qtablewidgetitem21);
        QTableWidgetItem *__qtablewidgetitem22 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(20, __qtablewidgetitem22);
        QTableWidgetItem *__qtablewidgetitem23 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(21, __qtablewidgetitem23);
        QTableWidgetItem *__qtablewidgetitem24 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(22, __qtablewidgetitem24);
        QTableWidgetItem *__qtablewidgetitem25 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(23, __qtablewidgetitem25);
        QTableWidgetItem *__qtablewidgetitem26 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(24, __qtablewidgetitem26);
        QTableWidgetItem *__qtablewidgetitem27 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(25, __qtablewidgetitem27);
        QTableWidgetItem *__qtablewidgetitem28 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(26, __qtablewidgetitem28);
        QTableWidgetItem *__qtablewidgetitem29 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(27, __qtablewidgetitem29);
        QTableWidgetItem *__qtablewidgetitem30 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(28, __qtablewidgetitem30);
        QTableWidgetItem *__qtablewidgetitem31 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(29, __qtablewidgetitem31);
        QTableWidgetItem *__qtablewidgetitem32 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(30, __qtablewidgetitem32);
        QTableWidgetItem *__qtablewidgetitem33 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(31, __qtablewidgetitem33);
        QTableWidgetItem *__qtablewidgetitem34 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(32, __qtablewidgetitem34);
        QTableWidgetItem *__qtablewidgetitem35 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(33, __qtablewidgetitem35);
        QTableWidgetItem *__qtablewidgetitem36 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(34, __qtablewidgetitem36);
        QTableWidgetItem *__qtablewidgetitem37 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(35, __qtablewidgetitem37);
        QTableWidgetItem *__qtablewidgetitem38 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(36, __qtablewidgetitem38);
        QTableWidgetItem *__qtablewidgetitem39 = new QTableWidgetItem();
        tableWidgetWaypoint->setVerticalHeaderItem(37, __qtablewidgetitem39);
        tableWidgetWaypoint->setObjectName(QStringLiteral("tableWidgetWaypoint"));
        tableWidgetWaypoint->setGeometry(QRect(650, 500, 301, 321));
        groupBox = new QGroupBox(tab);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(880, 310, 171, 121));
        groupBox->setFont(font1);
        label_78 = new QLabel(groupBox);
        label_78->setObjectName(QStringLiteral("label_78"));
        label_78->setGeometry(QRect(20, 30, 55, 16));
        label_78->setFont(font2);
        label_79 = new QLabel(groupBox);
        label_79->setObjectName(QStringLiteral("label_79"));
        label_79->setGeometry(QRect(20, 60, 55, 16));
        label_79->setFont(font2);
        lineEditXposition = new QLineEdit(groupBox);
        lineEditXposition->setObjectName(QStringLiteral("lineEditXposition"));
        lineEditXposition->setGeometry(QRect(50, 30, 111, 22));
        lineEditXposition->setFont(font2);
        lineEditYposition = new QLineEdit(groupBox);
        lineEditYposition->setObjectName(QStringLiteral("lineEditYposition"));
        lineEditYposition->setGeometry(QRect(50, 60, 111, 22));
        lineEditYposition->setFont(font2);
        lineEditKondisiMouse = new QLineEdit(groupBox);
        lineEditKondisiMouse->setObjectName(QStringLiteral("lineEditKondisiMouse"));
        lineEditKondisiMouse->setGeometry(QRect(50, 90, 111, 22));
        lineEditKondisiMouse->setFont(font2);
        groupBox_2 = new QGroupBox(tab);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(830, 120, 231, 171));
        groupBox_2->setFont(font1);
        lineEditTujuanLat = new QLineEdit(groupBox_2);
        lineEditTujuanLat->setObjectName(QStringLiteral("lineEditTujuanLat"));
        lineEditTujuanLat->setGeometry(QRect(10, 40, 191, 22));
        lineEditTujuanLat->setFont(font2);
        lineEditTujuanLong = new QLineEdit(groupBox_2);
        lineEditTujuanLong->setObjectName(QStringLiteral("lineEditTujuanLong"));
        lineEditTujuanLong->setGeometry(QRect(10, 60, 191, 22));
        lineEditTujuanLong->setFont(font2);
        label_81 = new QLabel(groupBox_2);
        label_81->setObjectName(QStringLiteral("label_81"));
        label_81->setGeometry(QRect(10, 90, 71, 20));
        label_81->setFont(font2);
        label_82 = new QLabel(groupBox_2);
        label_82->setObjectName(QStringLiteral("label_82"));
        label_82->setGeometry(QRect(10, 110, 71, 20));
        label_82->setFont(font2);
        lineEditErrorSudut = new QLineEdit(groupBox_2);
        lineEditErrorSudut->setObjectName(QStringLiteral("lineEditErrorSudut"));
        lineEditErrorSudut->setGeometry(QRect(90, 90, 113, 22));
        lineEditErrorSudut->setFont(font2);
        lineEditSudutTujuan = new QLineEdit(groupBox_2);
        lineEditSudutTujuan->setObjectName(QStringLiteral("lineEditSudutTujuan"));
        lineEditSudutTujuan->setGeometry(QRect(90, 110, 113, 22));
        lineEditSudutTujuan->setFont(font2);
        label_24 = new QLabel(groupBox_2);
        label_24->setObjectName(QStringLiteral("label_24"));
        label_24->setGeometry(QRect(20, 130, 55, 16));
        label_24->setFont(font2);
        lineEditJarak = new QLineEdit(groupBox_2);
        lineEditJarak->setObjectName(QStringLiteral("lineEditJarak"));
        lineEditJarak->setGeometry(QRect(90, 130, 113, 22));
        lineEditJarak->setFont(font2);
        groupBox_12 = new QGroupBox(tab);
        groupBox_12->setObjectName(QStringLiteral("groupBox_12"));
        groupBox_12->setGeometry(QRect(650, 310, 221, 171));
        groupBox_12->setFont(font1);
        label_104 = new QLabel(groupBox_12);
        label_104->setObjectName(QStringLiteral("label_104"));
        label_104->setGeometry(QRect(10, 80, 31, 16));
        label_104->setFont(font2);
        label_105 = new QLabel(groupBox_12);
        label_105->setObjectName(QStringLiteral("label_105"));
        label_105->setGeometry(QRect(10, 100, 31, 16));
        label_105->setFont(font2);
        lineEditInputLatt = new QLineEdit(groupBox_12);
        lineEditInputLatt->setObjectName(QStringLiteral("lineEditInputLatt"));
        lineEditInputLatt->setGeometry(QRect(60, 80, 151, 22));
        lineEditInputLatt->setFont(font2);
        lineEditInputLong = new QLineEdit(groupBox_12);
        lineEditInputLong->setObjectName(QStringLiteral("lineEditInputLong"));
        lineEditInputLong->setGeometry(QRect(60, 100, 151, 22));
        lineEditInputLong->setFont(font2);
        pushButtonInputWaypoint = new QPushButton(groupBox_12);
        pushButtonInputWaypoint->setObjectName(QStringLiteral("pushButtonInputWaypoint"));
        pushButtonInputWaypoint->setGeometry(QRect(60, 130, 111, 21));
        pushButtonInputWaypoint->setFont(font2);
        pushButtonSetWaypoint = new QPushButton(groupBox_12);
        pushButtonSetWaypoint->setObjectName(QStringLiteral("pushButtonSetWaypoint"));
        pushButtonSetWaypoint->setGeometry(QRect(10, 40, 121, 28));
        pushButtonSetWaypoint->setFont(font2);
        spinBoxWaypoint = new QSpinBox(groupBox_12);
        spinBoxWaypoint->setObjectName(QStringLiteral("spinBoxWaypoint"));
        spinBoxWaypoint->setGeometry(QRect(160, 40, 40, 22));
        spinBoxWaypoint->setFont(font2);
        spinBoxWaypoint->setMinimum(1);
        spinBoxWaypoint->setMaximum(40);
        spinBoxWaypoint->setValue(1);
        groupBox_3 = new QGroupBox(tab);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        groupBox_3->setGeometry(QRect(650, 20, 411, 91));
        groupBox_3->setFont(font1);
        pushButtonSaveAsWaypoint = new QPushButton(groupBox_3);
        pushButtonSaveAsWaypoint->setObjectName(QStringLiteral("pushButtonSaveAsWaypoint"));
        pushButtonSaveAsWaypoint->setGeometry(QRect(10, 50, 111, 28));
        pushButtonSaveAsWaypoint->setFont(font2);
        pushButtonSaveWaypoint = new QPushButton(groupBox_3);
        pushButtonSaveWaypoint->setObjectName(QStringLiteral("pushButtonSaveWaypoint"));
        pushButtonSaveWaypoint->setGeometry(QRect(150, 50, 111, 28));
        pushButtonSaveWaypoint->setFont(font2);
        pushButtonLoadWaypoint = new QPushButton(groupBox_3);
        pushButtonLoadWaypoint->setObjectName(QStringLiteral("pushButtonLoadWaypoint"));
        pushButtonLoadWaypoint->setGeometry(QRect(290, 50, 111, 28));
        pushButtonLoadWaypoint->setFont(font2);
        groupBox_19 = new QGroupBox(tab);
        groupBox_19->setObjectName(QStringLiteral("groupBox_19"));
        groupBox_19->setGeometry(QRect(650, 120, 171, 171));
        groupBox_19->setFont(font1);
        pushButtonStartMission = new QPushButton(groupBox_19);
        pushButtonStartMission->setObjectName(QStringLiteral("pushButtonStartMission"));
        pushButtonStartMission->setGeometry(QRect(10, 40, 151, 28));
        pushButtonStartMission->setFont(font2);
        pushButtonStopMission = new QPushButton(groupBox_19);
        pushButtonStopMission->setObjectName(QStringLiteral("pushButtonStopMission"));
        pushButtonStopMission->setEnabled(false);
        pushButtonStopMission->setGeometry(QRect(10, 70, 151, 28));
        pushButtonStopMission->setFont(font2);
        pushButtonReset = new QPushButton(groupBox_19);
        pushButtonReset->setObjectName(QStringLiteral("pushButtonReset"));
        pushButtonReset->setGeometry(QRect(10, 130, 81, 28));
        pushButtonReset->setFont(font2);
        pushButtonRetry = new QPushButton(groupBox_19);
        pushButtonRetry->setObjectName(QStringLiteral("pushButtonRetry"));
        pushButtonRetry->setGeometry(QRect(90, 130, 71, 28));
        pushButtonRetry->setFont(font2);
        pushButtonRetry2 = new QPushButton(groupBox_19);
        pushButtonRetry2->setObjectName(QStringLiteral("pushButtonRetry2"));
        pushButtonRetry2->setGeometry(QRect(10, 100, 151, 28));
        pushButtonRetry2->setFont(font2);
        labelArahKapal = new QLabel(tab);
        labelArahKapal->setObjectName(QStringLiteral("labelArahKapal"));
        labelArahKapal->setGeometry(QRect(1000, 500, 150, 150));
        labelArahKapal->setPixmap(QPixmap(QString::fromUtf8("../../.designer/backup/rocket.png")));
        labelArahKapal->setScaledContents(true);
        label_60 = new QLabel(tab);
        label_60->setObjectName(QStringLiteral("label_60"));
        label_60->setGeometry(QRect(1067, 660, 21, 21));
        QFont font7;
        font7.setPointSize(14);
        font7.setBold(true);
        font7.setWeight(75);
        label_60->setFont(font7);
        lcdNumberWaypoint = new QLCDNumber(tab);
        lcdNumberWaypoint->setObjectName(QStringLiteral("lcdNumberWaypoint"));
        lcdNumberWaypoint->setGeometry(QRect(883, 432, 61, 51));
        lcdNumberWaypoint->setDigitCount(2);
        pushButtonEast = new QPushButton(tab);
        pushButtonEast->setObjectName(QStringLiteral("pushButtonEast"));
        pushButtonEast->setGeometry(QRect(1160, 560, 31, 28));
        QFont font8;
        font8.setPointSize(12);
        font8.setBold(true);
        font8.setItalic(false);
        font8.setWeight(75);
        pushButtonEast->setFont(font8);
        pushButtonSouth = new QPushButton(tab);
        pushButtonSouth->setObjectName(QStringLiteral("pushButtonSouth"));
        pushButtonSouth->setGeometry(QRect(1060, 660, 31, 28));
        QFont font9;
        font9.setPointSize(12);
        font9.setBold(true);
        font9.setWeight(75);
        pushButtonSouth->setFont(font9);
        pushButtonWest = new QPushButton(tab);
        pushButtonWest->setObjectName(QStringLiteral("pushButtonWest"));
        pushButtonWest->setGeometry(QRect(960, 560, 31, 28));
        pushButtonWest->setFont(font9);
        pushButtonNorth = new QPushButton(tab);
        pushButtonNorth->setObjectName(QStringLiteral("pushButtonNorth"));
        pushButtonNorth->setGeometry(QRect(1060, 460, 31, 28));
        pushButtonNorth->setFont(font9);
        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        groupBox_4 = new QGroupBox(tab_2);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        groupBox_4->setGeometry(QRect(20, 20, 301, 171));
        groupBox_4->setFont(font1);
        label_49 = new QLabel(groupBox_4);
        label_49->setObjectName(QStringLiteral("label_49"));
        label_49->setGeometry(QRect(10, 40, 55, 16));
        label_49->setFont(font2);
        label_52 = new QLabel(groupBox_4);
        label_52->setObjectName(QStringLiteral("label_52"));
        label_52->setGeometry(QRect(10, 130, 55, 16));
        label_52->setFont(font2);
        label_90 = new QLabel(groupBox_4);
        label_90->setObjectName(QStringLiteral("label_90"));
        label_90->setGeometry(QRect(10, 100, 55, 16));
        label_90->setFont(font2);
        spinBoxWaypointMisi1 = new QSpinBox(groupBox_4);
        spinBoxWaypointMisi1->setObjectName(QStringLiteral("spinBoxWaypointMisi1"));
        spinBoxWaypointMisi1->setGeometry(QRect(91, 40, 161, 22));
        spinBoxWaypointMisi1->setFont(font3);
        spinBoxWaypointMisi1->setValue(6);
        spinBoxSudutMisi1 = new QSpinBox(groupBox_4);
        spinBoxSudutMisi1->setObjectName(QStringLiteral("spinBoxSudutMisi1"));
        spinBoxSudutMisi1->setGeometry(QRect(90, 130, 161, 22));
        spinBoxSudutMisi1->setFont(font3);
        spinBoxSpeedMisi1 = new QSpinBox(groupBox_4);
        spinBoxSpeedMisi1->setObjectName(QStringLiteral("spinBoxSpeedMisi1"));
        spinBoxSpeedMisi1->setGeometry(QRect(90, 100, 161, 22));
        spinBoxSpeedMisi1->setFont(font3);
        spinBoxSpeedMisi1->setMinimum(1500);
        spinBoxSpeedMisi1->setMaximum(2000);
        spinBoxSpeedMisi1->setSingleStep(25);
        spinBoxSpeedMisi1->setValue(1750);
        label_98 = new QLabel(groupBox_4);
        label_98->setObjectName(QStringLiteral("label_98"));
        label_98->setGeometry(QRect(10, 70, 55, 16));
        label_98->setFont(font2);
        spinBoxStopMisi1 = new QSpinBox(groupBox_4);
        spinBoxStopMisi1->setObjectName(QStringLiteral("spinBoxStopMisi1"));
        spinBoxStopMisi1->setGeometry(QRect(90, 70, 161, 22));
        spinBoxStopMisi1->setFont(font3);
        spinBoxStopMisi1->setValue(7);
        groupBox_5 = new QGroupBox(tab_2);
        groupBox_5->setObjectName(QStringLiteral("groupBox_5"));
        groupBox_5->setGeometry(QRect(20, 200, 301, 171));
        groupBox_5->setFont(font1);
        label_59 = new QLabel(groupBox_5);
        label_59->setObjectName(QStringLiteral("label_59"));
        label_59->setGeometry(QRect(10, 40, 55, 16));
        label_59->setFont(font2);
        label_91 = new QLabel(groupBox_5);
        label_91->setObjectName(QStringLiteral("label_91"));
        label_91->setGeometry(QRect(10, 100, 55, 16));
        label_91->setFont(font2);
        spinBoxWaypointMisi2 = new QSpinBox(groupBox_5);
        spinBoxWaypointMisi2->setObjectName(QStringLiteral("spinBoxWaypointMisi2"));
        spinBoxWaypointMisi2->setGeometry(QRect(91, 40, 161, 22));
        spinBoxWaypointMisi2->setFont(font3);
        spinBoxWaypointMisi2->setValue(10);
        spinBoxSpeedMisi2 = new QSpinBox(groupBox_5);
        spinBoxSpeedMisi2->setObjectName(QStringLiteral("spinBoxSpeedMisi2"));
        spinBoxSpeedMisi2->setGeometry(QRect(90, 100, 161, 22));
        spinBoxSpeedMisi2->setFont(font3);
        spinBoxSpeedMisi2->setMinimum(1500);
        spinBoxSpeedMisi2->setMaximum(2000);
        spinBoxSpeedMisi2->setSingleStep(25);
        spinBoxSpeedMisi2->setValue(1800);
        label_99 = new QLabel(groupBox_5);
        label_99->setObjectName(QStringLiteral("label_99"));
        label_99->setGeometry(QRect(10, 70, 55, 16));
        label_99->setFont(font2);
        spinBoxStopMisi2 = new QSpinBox(groupBox_5);
        spinBoxStopMisi2->setObjectName(QStringLiteral("spinBoxStopMisi2"));
        spinBoxStopMisi2->setGeometry(QRect(90, 70, 161, 22));
        spinBoxStopMisi2->setFont(font3);
        spinBoxStopMisi2->setValue(11);
        groupBox_6 = new QGroupBox(tab_2);
        groupBox_6->setObjectName(QStringLiteral("groupBox_6"));
        groupBox_6->setGeometry(QRect(650, 200, 311, 411));
        groupBox_6->setFont(font1);
        label_83 = new QLabel(groupBox_6);
        label_83->setObjectName(QStringLiteral("label_83"));
        label_83->setGeometry(QRect(10, 40, 71, 16));
        label_83->setFont(font2);
        label_95 = new QLabel(groupBox_6);
        label_95->setObjectName(QStringLiteral("label_95"));
        label_95->setGeometry(QRect(10, 100, 55, 16));
        label_95->setFont(font2);
        spinBoxWaypointMisi3 = new QSpinBox(groupBox_6);
        spinBoxWaypointMisi3->setObjectName(QStringLiteral("spinBoxWaypointMisi3"));
        spinBoxWaypointMisi3->setGeometry(QRect(80, 40, 61, 22));
        spinBoxWaypointMisi3->setFont(font3);
        spinBoxWaypointMisi3->setMinimum(0);
        spinBoxWaypointMisi3->setMaximum(99);
        spinBoxWaypointMisi3->setSingleStep(1);
        spinBoxWaypointMisi3->setValue(14);
        spinBoxSpeedMisi3 = new QSpinBox(groupBox_6);
        spinBoxSpeedMisi3->setObjectName(QStringLiteral("spinBoxSpeedMisi3"));
        spinBoxSpeedMisi3->setGeometry(QRect(80, 100, 61, 22));
        spinBoxSpeedMisi3->setFont(font3);
        spinBoxSpeedMisi3->setMinimum(1500);
        spinBoxSpeedMisi3->setMaximum(2000);
        spinBoxSpeedMisi3->setSingleStep(25);
        spinBoxSpeedMisi3->setValue(1650);
        label_100 = new QLabel(groupBox_6);
        label_100->setObjectName(QStringLiteral("label_100"));
        label_100->setGeometry(QRect(150, 40, 55, 16));
        label_100->setFont(font2);
        spinBoxStopMisi3 = new QSpinBox(groupBox_6);
        spinBoxStopMisi3->setObjectName(QStringLiteral("spinBoxStopMisi3"));
        spinBoxStopMisi3->setGeometry(QRect(220, 40, 61, 22));
        spinBoxStopMisi3->setFont(font3);
        spinBoxStopMisi3->setValue(17);
        label_70 = new QLabel(groupBox_6);
        label_70->setObjectName(QStringLiteral("label_70"));
        label_70->setGeometry(QRect(150, 70, 55, 16));
        label_70->setFont(font2);
        spinBoxSetpointMisi3 = new QSpinBox(groupBox_6);
        spinBoxSetpointMisi3->setObjectName(QStringLiteral("spinBoxSetpointMisi3"));
        spinBoxSetpointMisi3->setGeometry(QRect(220, 70, 61, 22));
        spinBoxSetpointMisi3->setFont(font3);
        spinBoxSetpointMisi3->setMaximum(250);
        spinBoxSetpointMisi3->setValue(80);
        label_72 = new QLabel(groupBox_6);
        label_72->setObjectName(QStringLiteral("label_72"));
        label_72->setGeometry(QRect(10, 280, 81, 17));
        QFont font10;
        font10.setPointSize(12);
        font10.setBold(false);
        font10.setItalic(false);
        font10.setWeight(50);
        label_72->setFont(font10);
        label_74 = new QLabel(groupBox_6);
        label_74->setObjectName(QStringLiteral("label_74"));
        label_74->setGeometry(QRect(150, 100, 59, 17));
        label_74->setFont(font2);
        spinBoxSpeedMisi3Atas = new QSpinBox(groupBox_6);
        spinBoxSpeedMisi3Atas->setObjectName(QStringLiteral("spinBoxSpeedMisi3Atas"));
        spinBoxSpeedMisi3Atas->setGeometry(QRect(220, 100, 61, 23));
        spinBoxSpeedMisi3Atas->setFont(font3);
        spinBoxSpeedMisi3Atas->setMinimum(1500);
        spinBoxSpeedMisi3Atas->setMaximum(2000);
        spinBoxSpeedMisi3Atas->setSingleStep(25);
        spinBoxSpeedMisi3Atas->setValue(1700);
        label_84 = new QLabel(groupBox_6);
        label_84->setObjectName(QStringLiteral("label_84"));
        label_84->setGeometry(QRect(10, 70, 71, 16));
        label_84->setFont(font2);
        spinBoxWaypointMisi3_2 = new QSpinBox(groupBox_6);
        spinBoxWaypointMisi3_2->setObjectName(QStringLiteral("spinBoxWaypointMisi3_2"));
        spinBoxWaypointMisi3_2->setGeometry(QRect(80, 70, 61, 22));
        spinBoxWaypointMisi3_2->setFont(font3);
        spinBoxWaypointMisi3_2->setValue(16);
        lcdNumberCounterMisi3 = new QLCDNumber(groupBox_6);
        lcdNumberCounterMisi3->setObjectName(QStringLiteral("lcdNumberCounterMisi3"));
        lcdNumberCounterMisi3->setGeometry(QRect(130, 270, 101, 41));
        lcdNumberCounterMisi3->setDigitCount(4);
        lineEditStatusMisi3 = new QLineEdit(groupBox_6);
        lineEditStatusMisi3->setObjectName(QStringLiteral("lineEditStatusMisi3"));
        lineEditStatusMisi3->setGeometry(QRect(10, 361, 291, 31));
        lineEditStatusMisi3->setFont(font3);
        label_114 = new QLabel(groupBox_6);
        label_114->setObjectName(QStringLiteral("label_114"));
        label_114->setGeometry(QRect(150, 130, 55, 16));
        label_114->setFont(font2);
        label_115 = new QLabel(groupBox_6);
        label_115->setObjectName(QStringLiteral("label_115"));
        label_115->setGeometry(QRect(10, 160, 55, 16));
        label_115->setFont(font2);
        spinBoxSudutMisi3 = new QSpinBox(groupBox_6);
        spinBoxSudutMisi3->setObjectName(QStringLiteral("spinBoxSudutMisi3"));
        spinBoxSudutMisi3->setGeometry(QRect(80, 160, 61, 22));
        spinBoxSudutMisi3->setFont(font3);
        spinBoxSudutMisi3->setMaximum(180);
        spinBoxSudutMisi3->setValue(90);
        label_117 = new QLabel(groupBox_6);
        label_117->setObjectName(QStringLiteral("label_117"));
        label_117->setGeometry(QRect(10, 310, 81, 31));
        QFont font11;
        font11.setBold(false);
        font11.setItalic(false);
        font11.setWeight(50);
        label_117->setFont(font11);
        lineEditDock = new QLineEdit(groupBox_6);
        lineEditDock->setObjectName(QStringLiteral("lineEditDock"));
        lineEditDock->setGeometry(QRect(220, 130, 61, 22));
        lineEditDock->setFont(font3);
        lcdNumberPenandaMisi3 = new QLCDNumber(groupBox_6);
        lcdNumberPenandaMisi3->setObjectName(QStringLiteral("lcdNumberPenandaMisi3"));
        lcdNumberPenandaMisi3->setGeometry(QRect(130, 310, 101, 41));
        lcdNumberPenandaMisi3->setDigitCount(4);
        label_116 = new QLabel(groupBox_6);
        label_116->setObjectName(QStringLiteral("label_116"));
        label_116->setGeometry(QRect(10, 130, 61, 16));
        label_116->setFont(font2);
        spinBoxThresholdPinger = new QSpinBox(groupBox_6);
        spinBoxThresholdPinger->setObjectName(QStringLiteral("spinBoxThresholdPinger"));
        spinBoxThresholdPinger->setGeometry(QRect(80, 130, 61, 22));
        spinBoxThresholdPinger->setFont(font3);
        spinBoxThresholdPinger->setMaximum(200);
        spinBoxThresholdPinger->setValue(40);
        spinBoxMaxPinger = new QSpinBox(groupBox_6);
        spinBoxMaxPinger->setObjectName(QStringLiteral("spinBoxMaxPinger"));
        spinBoxMaxPinger->setGeometry(QRect(220, 160, 61, 22));
        spinBoxMaxPinger->setFont(font3);
        spinBoxMaxPinger->setMaximum(200);
        spinBoxMaxPinger->setValue(40);
        label_118 = new QLabel(groupBox_6);
        label_118->setObjectName(QStringLiteral("label_118"));
        label_118->setGeometry(QRect(150, 160, 71, 16));
        label_118->setFont(font2);
        label_121 = new QLabel(groupBox_6);
        label_121->setObjectName(QStringLiteral("label_121"));
        label_121->setGeometry(QRect(10, 190, 55, 16));
        label_121->setFont(font2);
        spinBoxThresholdFrequency = new QSpinBox(groupBox_6);
        spinBoxThresholdFrequency->setObjectName(QStringLiteral("spinBoxThresholdFrequency"));
        spinBoxThresholdFrequency->setGeometry(QRect(80, 190, 201, 22));
        spinBoxThresholdFrequency->setFont(font3);
        spinBoxThresholdFrequency->setMinimum(10000);
        spinBoxThresholdFrequency->setMaximum(90000);
        spinBoxThresholdFrequency->setValue(55000);
        groupBox_7 = new QGroupBox(tab_2);
        groupBox_7->setObjectName(QStringLiteral("groupBox_7"));
        groupBox_7->setGeometry(QRect(20, 380, 301, 161));
        groupBox_7->setFont(font1);
        label_86 = new QLabel(groupBox_7);
        label_86->setObjectName(QStringLiteral("label_86"));
        label_86->setGeometry(QRect(10, 40, 55, 16));
        label_86->setFont(font2);
        comboBox_2 = new QComboBox(groupBox_7);
        comboBox_2->setObjectName(QStringLiteral("comboBox_2"));
        comboBox_2->setGeometry(QRect(10, 130, 241, 22));
        comboBox_2->setFont(font2);
        label_94 = new QLabel(groupBox_7);
        label_94->setObjectName(QStringLiteral("label_94"));
        label_94->setGeometry(QRect(10, 100, 55, 16));
        label_94->setFont(font2);
        spinBoxWaypointMisi4 = new QSpinBox(groupBox_7);
        spinBoxWaypointMisi4->setObjectName(QStringLiteral("spinBoxWaypointMisi4"));
        spinBoxWaypointMisi4->setGeometry(QRect(91, 40, 161, 22));
        spinBoxWaypointMisi4->setFont(font3);
        spinBoxWaypointMisi4->setValue(18);
        spinBoxSpeedMisi4 = new QSpinBox(groupBox_7);
        spinBoxSpeedMisi4->setObjectName(QStringLiteral("spinBoxSpeedMisi4"));
        spinBoxSpeedMisi4->setGeometry(QRect(90, 100, 161, 22));
        spinBoxSpeedMisi4->setFont(font3);
        spinBoxSpeedMisi4->setMinimum(1500);
        spinBoxSpeedMisi4->setMaximum(2000);
        spinBoxSpeedMisi4->setSingleStep(25);
        spinBoxSpeedMisi4->setValue(1650);
        label_101 = new QLabel(groupBox_7);
        label_101->setObjectName(QStringLiteral("label_101"));
        label_101->setGeometry(QRect(10, 70, 55, 16));
        label_101->setFont(font2);
        spinBoxStopMisi4 = new QSpinBox(groupBox_7);
        spinBoxStopMisi4->setObjectName(QStringLiteral("spinBoxStopMisi4"));
        spinBoxStopMisi4->setGeometry(QRect(90, 70, 161, 22));
        spinBoxStopMisi4->setFont(font3);
        spinBoxStopMisi4->setValue(19);
        groupBox_8 = new QGroupBox(tab_2);
        groupBox_8->setObjectName(QStringLiteral("groupBox_8"));
        groupBox_8->setGeometry(QRect(340, 20, 301, 201));
        groupBox_8->setFont(font1);
        label_88 = new QLabel(groupBox_8);
        label_88->setObjectName(QStringLiteral("label_88"));
        label_88->setGeometry(QRect(10, 40, 55, 16));
        label_88->setFont(font2);
        label_93 = new QLabel(groupBox_8);
        label_93->setObjectName(QStringLiteral("label_93"));
        label_93->setGeometry(QRect(10, 100, 55, 16));
        label_93->setFont(font2);
        spinBoxWaypointMisi5 = new QSpinBox(groupBox_8);
        spinBoxWaypointMisi5->setObjectName(QStringLiteral("spinBoxWaypointMisi5"));
        spinBoxWaypointMisi5->setGeometry(QRect(91, 40, 161, 22));
        spinBoxWaypointMisi5->setFont(font3);
        spinBoxWaypointMisi5->setValue(22);
        spinBoxSpeedMisi5 = new QSpinBox(groupBox_8);
        spinBoxSpeedMisi5->setObjectName(QStringLiteral("spinBoxSpeedMisi5"));
        spinBoxSpeedMisi5->setGeometry(QRect(90, 100, 161, 22));
        spinBoxSpeedMisi5->setFont(font3);
        spinBoxSpeedMisi5->setMinimum(1500);
        spinBoxSpeedMisi5->setMaximum(2000);
        spinBoxSpeedMisi5->setSingleStep(25);
        spinBoxSpeedMisi5->setValue(1700);
        label_102 = new QLabel(groupBox_8);
        label_102->setObjectName(QStringLiteral("label_102"));
        label_102->setGeometry(QRect(10, 70, 55, 16));
        label_102->setFont(font2);
        spinBoxStopMisi5 = new QSpinBox(groupBox_8);
        spinBoxStopMisi5->setObjectName(QStringLiteral("spinBoxStopMisi5"));
        spinBoxStopMisi5->setGeometry(QRect(90, 70, 161, 22));
        spinBoxStopMisi5->setFont(font3);
        spinBoxStopMisi5->setValue(23);
        label_66 = new QLabel(groupBox_8);
        label_66->setObjectName(QStringLiteral("label_66"));
        label_66->setGeometry(QRect(10, 130, 55, 16));
        label_66->setFont(font2);
        spinBoxSpeedMisi5Bawah = new QSpinBox(groupBox_8);
        spinBoxSpeedMisi5Bawah->setObjectName(QStringLiteral("spinBoxSpeedMisi5Bawah"));
        spinBoxSpeedMisi5Bawah->setGeometry(QRect(90, 130, 161, 22));
        spinBoxSpeedMisi5Bawah->setFont(font3);
        spinBoxSpeedMisi5Bawah->setMinimum(1000);
        spinBoxSpeedMisi5Bawah->setMaximum(2000);
        spinBoxSpeedMisi5Bawah->setSingleStep(5);
        spinBoxSpeedMisi5Bawah->setValue(1550);
        label_122 = new QLabel(groupBox_8);
        label_122->setObjectName(QStringLiteral("label_122"));
        label_122->setGeometry(QRect(10, 160, 55, 16));
        label_122->setFont(font2);
        spinBoxSetpointMisi5 = new QSpinBox(groupBox_8);
        spinBoxSetpointMisi5->setObjectName(QStringLiteral("spinBoxSetpointMisi5"));
        spinBoxSetpointMisi5->setGeometry(QRect(90, 160, 161, 22));
        spinBoxSetpointMisi5->setFont(font3);
        spinBoxSetpointMisi5->setMaximum(400);
        spinBoxSetpointMisi5->setSingleStep(5);
        spinBoxSetpointMisi5->setValue(240);
        groupBox_9 = new QGroupBox(tab_2);
        groupBox_9->setObjectName(QStringLiteral("groupBox_9"));
        groupBox_9->setGeometry(QRect(340, 230, 301, 141));
        groupBox_9->setFont(font1);
        label_89 = new QLabel(groupBox_9);
        label_89->setObjectName(QStringLiteral("label_89"));
        label_89->setGeometry(QRect(10, 40, 55, 16));
        label_89->setFont(font2);
        label_92 = new QLabel(groupBox_9);
        label_92->setObjectName(QStringLiteral("label_92"));
        label_92->setGeometry(QRect(10, 100, 55, 16));
        label_92->setFont(font2);
        spinBoxWaypointReturn = new QSpinBox(groupBox_9);
        spinBoxWaypointReturn->setObjectName(QStringLiteral("spinBoxWaypointReturn"));
        spinBoxWaypointReturn->setGeometry(QRect(90, 40, 161, 22));
        spinBoxWaypointReturn->setFont(font3);
        spinBoxWaypointReturn->setValue(26);
        spinBoxSpeedReturn = new QSpinBox(groupBox_9);
        spinBoxSpeedReturn->setObjectName(QStringLiteral("spinBoxSpeedReturn"));
        spinBoxSpeedReturn->setGeometry(QRect(90, 100, 161, 22));
        spinBoxSpeedReturn->setFont(font3);
        spinBoxSpeedReturn->setMinimum(1500);
        spinBoxSpeedReturn->setMaximum(2000);
        spinBoxSpeedReturn->setSingleStep(25);
        spinBoxSpeedReturn->setValue(1900);
        label_103 = new QLabel(groupBox_9);
        label_103->setObjectName(QStringLiteral("label_103"));
        label_103->setGeometry(QRect(10, 70, 55, 16));
        label_103->setFont(font2);
        spinBoxStopReturn = new QSpinBox(groupBox_9);
        spinBoxStopReturn->setObjectName(QStringLiteral("spinBoxStopReturn"));
        spinBoxStopReturn->setGeometry(QRect(90, 70, 161, 22));
        spinBoxStopReturn->setFont(font3);
        spinBoxStopReturn->setValue(27);
        groupBox_10 = new QGroupBox(tab_2);
        groupBox_10->setObjectName(QStringLiteral("groupBox_10"));
        groupBox_10->setGeometry(QRect(660, 630, 301, 101));
        groupBox_10->setFont(font1);
        lineEditMissionStatus = new QLineEdit(groupBox_10);
        lineEditMissionStatus->setObjectName(QStringLiteral("lineEditMissionStatus"));
        lineEditMissionStatus->setGeometry(QRect(10, 40, 271, 31));
        lineEditMissionStatus->setFont(font3);
        groupBox_11 = new QGroupBox(tab_2);
        groupBox_11->setObjectName(QStringLiteral("groupBox_11"));
        groupBox_11->setGeometry(QRect(660, 20, 301, 171));
        groupBox_11->setFont(font1);
        label_58 = new QLabel(groupBox_11);
        label_58->setObjectName(QStringLiteral("label_58"));
        label_58->setGeometry(QRect(20, 40, 55, 16));
        label_58->setFont(font2);
        spinBoxSpeedNav = new QSpinBox(groupBox_11);
        spinBoxSpeedNav->setObjectName(QStringLiteral("spinBoxSpeedNav"));
        spinBoxSpeedNav->setGeometry(QRect(110, 40, 171, 22));
        spinBoxSpeedNav->setFont(font3);
        spinBoxSpeedNav->setMinimum(1500);
        spinBoxSpeedNav->setMaximum(2000);
        spinBoxSpeedNav->setSingleStep(25);
        spinBoxSpeedNav->setValue(1750);
        label_96 = new QLabel(groupBox_11);
        label_96->setObjectName(QStringLiteral("label_96"));
        label_96->setGeometry(QRect(20, 70, 61, 16));
        label_96->setFont(font2);
        spinBoxServoCamera = new QSpinBox(groupBox_11);
        spinBoxServoCamera->setObjectName(QStringLiteral("spinBoxServoCamera"));
        spinBoxServoCamera->setGeometry(QRect(110, 70, 171, 22));
        spinBoxServoCamera->setFont(font3);
        spinBoxServoCamera->setMinimum(1200);
        spinBoxServoCamera->setMaximum(2000);
        spinBoxServoCamera->setSingleStep(25);
        spinBoxServoCamera->setValue(1450);
        label_55 = new QLabel(groupBox_11);
        label_55->setObjectName(QStringLiteral("label_55"));
        label_55->setGeometry(QRect(20, 130, 55, 16));
        label_55->setFont(font2);
        spinBoxTrim = new QSpinBox(groupBox_11);
        spinBoxTrim->setObjectName(QStringLiteral("spinBoxTrim"));
        spinBoxTrim->setGeometry(QRect(110, 130, 171, 22));
        spinBoxTrim->setFont(font3);
        spinBoxTrim->setMinimum(-100);
        spinBoxTrim->setMaximum(100);
        label_73 = new QLabel(groupBox_11);
        label_73->setObjectName(QStringLiteral("label_73"));
        label_73->setGeometry(QRect(20, 100, 71, 17));
        label_73->setFont(font2);
        spinBoxServoCamera2 = new QSpinBox(groupBox_11);
        spinBoxServoCamera2->setObjectName(QStringLiteral("spinBoxServoCamera2"));
        spinBoxServoCamera2->setGeometry(QRect(110, 100, 171, 23));
        spinBoxServoCamera2->setFont(font3);
        spinBoxServoCamera2->setMinimum(500);
        spinBoxServoCamera2->setMaximum(2500);
        spinBoxServoCamera2->setSingleStep(25);
        spinBoxServoCamera2->setValue(1500);
        groupBox_17 = new QGroupBox(tab_2);
        groupBox_17->setObjectName(QStringLiteral("groupBox_17"));
        groupBox_17->setGeometry(QRect(970, 20, 301, 431));
        groupBox_17->setFont(font1);
        pushButtonOpenPort = new QPushButton(groupBox_17);
        pushButtonOpenPort->setObjectName(QStringLiteral("pushButtonOpenPort"));
        pushButtonOpenPort->setGeometry(QRect(20, 40, 111, 28));
        pushButtonOpenPort->setFont(font2);
        pushButtonClosePort = new QPushButton(groupBox_17);
        pushButtonClosePort->setObjectName(QStringLiteral("pushButtonClosePort"));
        pushButtonClosePort->setGeometry(QRect(150, 40, 111, 28));
        pushButtonClosePort->setFont(font2);
        label_17 = new QLabel(groupBox_17);
        label_17->setObjectName(QStringLiteral("label_17"));
        label_17->setGeometry(QRect(30, 80, 55, 16));
        label_17->setFont(font2);
        label_20 = new QLabel(groupBox_17);
        label_20->setObjectName(QStringLiteral("label_20"));
        label_20->setGeometry(QRect(30, 110, 55, 16));
        label_20->setFont(font2);
        label_21 = new QLabel(groupBox_17);
        label_21->setObjectName(QStringLiteral("label_21"));
        label_21->setGeometry(QRect(30, 140, 55, 16));
        label_21->setFont(font2);
        lineEditLattitude = new QLineEdit(groupBox_17);
        lineEditLattitude->setObjectName(QStringLiteral("lineEditLattitude"));
        lineEditLattitude->setGeometry(QRect(120, 80, 141, 22));
        lineEditLattitude->setFont(font2);
        lineEditLongitude = new QLineEdit(groupBox_17);
        lineEditLongitude->setObjectName(QStringLiteral("lineEditLongitude"));
        lineEditLongitude->setGeometry(QRect(120, 110, 141, 21));
        lineEditLongitude->setFont(font2);
        lineEditCompass = new QLineEdit(groupBox_17);
        lineEditCompass->setObjectName(QStringLiteral("lineEditCompass"));
        lineEditCompass->setGeometry(QRect(120, 140, 141, 22));
        lineEditCompass->setFont(font2);
        label_22 = new QLabel(groupBox_17);
        label_22->setObjectName(QStringLiteral("label_22"));
        label_22->setGeometry(QRect(40, 180, 81, 16));
        label_22->setFont(font2);
        label_71 = new QLabel(groupBox_17);
        label_71->setObjectName(QStringLiteral("label_71"));
        label_71->setGeometry(QRect(170, 180, 81, 16));
        label_71->setFont(font2);
        label_75 = new QLabel(groupBox_17);
        label_75->setObjectName(QStringLiteral("label_75"));
        label_75->setGeometry(QRect(40, 230, 55, 16));
        label_75->setFont(font2);
        label_76 = new QLabel(groupBox_17);
        label_76->setObjectName(QStringLiteral("label_76"));
        label_76->setGeometry(QRect(170, 230, 71, 16));
        label_76->setFont(font2);
        lineEditSRFTengah1 = new QLineEdit(groupBox_17);
        lineEditSRFTengah1->setObjectName(QStringLiteral("lineEditSRFTengah1"));
        lineEditSRFTengah1->setGeometry(QRect(30, 200, 101, 22));
        lineEditSRFTengah1->setFont(font2);
        lineEditSRFTengah2 = new QLineEdit(groupBox_17);
        lineEditSRFTengah2->setObjectName(QStringLiteral("lineEditSRFTengah2"));
        lineEditSRFTengah2->setGeometry(QRect(160, 200, 101, 22));
        lineEditSRFTengah2->setFont(font2);
        lineEditSRFKiri = new QLineEdit(groupBox_17);
        lineEditSRFKiri->setObjectName(QStringLiteral("lineEditSRFKiri"));
        lineEditSRFKiri->setGeometry(QRect(30, 250, 101, 22));
        lineEditSRFKiri->setFont(font2);
        lineEditSRFKanan = new QLineEdit(groupBox_17);
        lineEditSRFKanan->setObjectName(QStringLiteral("lineEditSRFKanan"));
        lineEditSRFKanan->setGeometry(QRect(160, 250, 101, 22));
        lineEditSRFKanan->setFont(font2);
        label_77 = new QLabel(groupBox_17);
        label_77->setObjectName(QStringLiteral("label_77"));
        label_77->setGeometry(QRect(20, 330, 141, 16));
        label_77->setFont(font2);
        lineEditFrequency = new QLineEdit(groupBox_17);
        lineEditFrequency->setObjectName(QStringLiteral("lineEditFrequency"));
        lineEditFrequency->setGeometry(QRect(170, 330, 91, 21));
        lineEditFrequency->setFont(font2);
        label_112 = new QLabel(groupBox_17);
        label_112->setObjectName(QStringLiteral("label_112"));
        label_112->setGeometry(QRect(20, 360, 91, 16));
        label_112->setFont(font2);
        label_113 = new QLabel(groupBox_17);
        label_113->setObjectName(QStringLiteral("label_113"));
        label_113->setGeometry(QRect(20, 390, 101, 16));
        label_113->setFont(font2);
        lineEditAmplitudoKiri = new QLineEdit(groupBox_17);
        lineEditAmplitudoKiri->setObjectName(QStringLiteral("lineEditAmplitudoKiri"));
        lineEditAmplitudoKiri->setGeometry(QRect(150, 360, 113, 22));
        lineEditAmplitudoKiri->setFont(font2);
        lineEditAmplitudoKanan = new QLineEdit(groupBox_17);
        lineEditAmplitudoKanan->setObjectName(QStringLiteral("lineEditAmplitudoKanan"));
        lineEditAmplitudoKanan->setGeometry(QRect(150, 390, 113, 22));
        lineEditAmplitudoKanan->setFont(font2);
        label_67 = new QLabel(groupBox_17);
        label_67->setObjectName(QStringLiteral("label_67"));
        label_67->setGeometry(QRect(40, 290, 91, 16));
        label_67->setFont(font2);
        lineEditSRFSamping = new QLineEdit(groupBox_17);
        lineEditSRFSamping->setObjectName(QStringLiteral("lineEditSRFSamping"));
        lineEditSRFSamping->setGeometry(QRect(160, 290, 101, 22));
        lineEditSRFSamping->setFont(font2);
        groupBox_18 = new QGroupBox(tab_2);
        groupBox_18->setObjectName(QStringLiteral("groupBox_18"));
        groupBox_18->setGeometry(QRect(340, 570, 301, 161));
        groupBox_18->setFont(font1);
        label_18 = new QLabel(groupBox_18);
        label_18->setObjectName(QStringLiteral("label_18"));
        label_18->setGeometry(QRect(20, 70, 55, 16));
        label_18->setFont(font2);
        label_19 = new QLabel(groupBox_18);
        label_19->setObjectName(QStringLiteral("label_19"));
        label_19->setGeometry(QRect(150, 70, 81, 16));
        label_19->setFont(font2);
        label_23 = new QLabel(groupBox_18);
        label_23->setObjectName(QStringLiteral("label_23"));
        label_23->setGeometry(QRect(20, 110, 55, 16));
        label_23->setFont(font2);
        label_53 = new QLabel(groupBox_18);
        label_53->setObjectName(QStringLiteral("label_53"));
        label_53->setGeometry(QRect(150, 110, 71, 16));
        label_53->setFont(font2);
        lineEditMotorKiri = new QLineEdit(groupBox_18);
        lineEditMotorKiri->setObjectName(QStringLiteral("lineEditMotorKiri"));
        lineEditMotorKiri->setGeometry(QRect(10, 90, 113, 22));
        QFont font12;
        font12.setPointSize(10);
        font12.setItalic(false);
        lineEditMotorKiri->setFont(font12);
        lineEditMotorKanan = new QLineEdit(groupBox_18);
        lineEditMotorKanan->setObjectName(QStringLiteral("lineEditMotorKanan"));
        lineEditMotorKanan->setGeometry(QRect(140, 90, 113, 22));
        lineEditMotorKanan->setFont(font12);
        lineEditServoKiri = new QLineEdit(groupBox_18);
        lineEditServoKiri->setObjectName(QStringLiteral("lineEditServoKiri"));
        lineEditServoKiri->setGeometry(QRect(10, 130, 113, 22));
        lineEditServoKiri->setFont(font12);
        lineEditServoKanan = new QLineEdit(groupBox_18);
        lineEditServoKanan->setObjectName(QStringLiteral("lineEditServoKanan"));
        lineEditServoKanan->setGeometry(QRect(140, 130, 113, 22));
        lineEditServoKanan->setFont(font12);
        label_68 = new QLabel(groupBox_18);
        label_68->setObjectName(QStringLiteral("label_68"));
        label_68->setGeometry(QRect(150, 30, 101, 16));
        label_68->setFont(font2);
        lineEditMotorTengah = new QLineEdit(groupBox_18);
        lineEditMotorTengah->setObjectName(QStringLiteral("lineEditMotorTengah"));
        lineEditMotorTengah->setGeometry(QRect(140, 50, 113, 22));
        QFont font13;
        font13.setPointSize(10);
        font13.setBold(true);
        font13.setItalic(false);
        font13.setWeight(75);
        lineEditMotorTengah->setFont(font13);
        groupBox_20 = new QGroupBox(tab_2);
        groupBox_20->setObjectName(QStringLiteral("groupBox_20"));
        groupBox_20->setGeometry(QRect(20, 550, 301, 201));
        groupBox_20->setFont(font1);
        label_62 = new QLabel(groupBox_20);
        label_62->setObjectName(QStringLiteral("label_62"));
        label_62->setGeometry(QRect(20, 40, 55, 16));
        label_62->setFont(font2);
        label_97 = new QLabel(groupBox_20);
        label_97->setObjectName(QStringLiteral("label_97"));
        label_97->setGeometry(QRect(20, 60, 61, 16));
        label_97->setFont(font2);
        label_63 = new QLabel(groupBox_20);
        label_63->setObjectName(QStringLiteral("label_63"));
        label_63->setGeometry(QRect(20, 80, 55, 16));
        label_63->setFont(font2);
        serverUrl = new QLineEdit(groupBox_20);
        serverUrl->setObjectName(QStringLiteral("serverUrl"));
        serverUrl->setGeometry(QRect(120, 40, 113, 20));
        serverIP = new QLineEdit(groupBox_20);
        serverIP->setObjectName(QStringLiteral("serverIP"));
        serverIP->setGeometry(QRect(120, 60, 113, 20));
        serverPort = new QLineEdit(groupBox_20);
        serverPort->setObjectName(QStringLiteral("serverPort"));
        serverPort->setGeometry(QRect(120, 80, 113, 20));
        label_64 = new QLabel(groupBox_20);
        label_64->setObjectName(QStringLiteral("label_64"));
        label_64->setGeometry(QRect(20, 160, 271, 21));
        label_64->setFont(font12);
        label_64->setStyleSheet(QStringLiteral("color: rgb(255, 0, 0);"));
        btnStartConnServer = new QPushButton(groupBox_20);
        btnStartConnServer->setObjectName(QStringLiteral("btnStartConnServer"));
        btnStartConnServer->setGeometry(QRect(20, 130, 75, 23));
        btnStartConnServer->setFont(font2);
        btnStopConnServer = new QPushButton(groupBox_20);
        btnStopConnServer->setObjectName(QStringLiteral("btnStopConnServer"));
        btnStopConnServer->setGeometry(QRect(130, 130, 75, 23));
        btnStopConnServer->setFont(font2);
        label_65 = new QLabel(groupBox_20);
        label_65->setObjectName(QStringLiteral("label_65"));
        label_65->setGeometry(QRect(20, 100, 55, 16));
        label_65->setFont(font2);
        course = new QLineEdit(groupBox_20);
        course->setObjectName(QStringLiteral("course"));
        course->setGeometry(QRect(120, 100, 113, 20));
        groupBox_22 = new QGroupBox(tab_2);
        groupBox_22->setObjectName(QStringLiteral("groupBox_22"));
        groupBox_22->setGeometry(QRect(339, 379, 301, 161));
        groupBox_22->setFont(font1);
        label_85 = new QLabel(groupBox_22);
        label_85->setObjectName(QStringLiteral("label_85"));
        label_85->setGeometry(QRect(20, 40, 55, 16));
        label_85->setFont(font2);
        label_119 = new QLabel(groupBox_22);
        label_119->setObjectName(QStringLiteral("label_119"));
        label_119->setGeometry(QRect(20, 70, 55, 16));
        label_119->setFont(font2);
        label_120 = new QLabel(groupBox_22);
        label_120->setObjectName(QStringLiteral("label_120"));
        label_120->setGeometry(QRect(20, 100, 55, 16));
        label_120->setFont(font2);
        spinBoxWaypointMisi6 = new QSpinBox(groupBox_22);
        spinBoxWaypointMisi6->setObjectName(QStringLiteral("spinBoxWaypointMisi6"));
        spinBoxWaypointMisi6->setGeometry(QRect(120, 40, 141, 22));
        spinBoxWaypointMisi6->setFont(font3);
        spinBoxWaypointMisi6->setValue(24);
        spinBoxStopMisi6 = new QSpinBox(groupBox_22);
        spinBoxStopMisi6->setObjectName(QStringLiteral("spinBoxStopMisi6"));
        spinBoxStopMisi6->setGeometry(QRect(120, 70, 141, 22));
        spinBoxStopMisi6->setFont(font3);
        spinBoxStopMisi6->setValue(25);
        spinBoxSpeedMisi6 = new QSpinBox(groupBox_22);
        spinBoxSpeedMisi6->setObjectName(QStringLiteral("spinBoxSpeedMisi6"));
        spinBoxSpeedMisi6->setGeometry(QRect(120, 100, 141, 22));
        spinBoxSpeedMisi6->setFont(font3);
        spinBoxSpeedMisi6->setMinimum(1000);
        spinBoxSpeedMisi6->setMaximum(2000);
        spinBoxSpeedMisi6->setSingleStep(25);
        spinBoxSpeedMisi6->setValue(1700);
        tabWidget->addTab(tab_2, QString());
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 1317, 21));
        menuFIle = new QMenu(menubar);
        menuFIle->setObjectName(QStringLiteral("menuFIle"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(menuFIle->menuAction());
        menuFIle->addAction(actionSave);
        menuFIle->addAction(actionSave_As);
        menuFIle->addAction(actionOpen);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(0);
        stackedWidget->setCurrentIndex(4);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        actionSave->setText(QApplication::translate("MainWindow", "Save", Q_NULLPTR));
        actionSave_As->setText(QApplication::translate("MainWindow", "Save As...", Q_NULLPTR));
        actionOpen->setText(QApplication::translate("MainWindow", "Open", Q_NULLPTR));
        startButton->setText(QApplication::translate("MainWindow", "Start Camera", Q_NULLPTR));
        labelOri->setText(QString());
        stopButton->setText(QApplication::translate("MainWindow", "Stop Camera", Q_NULLPTR));
        warnaSelector->clear();
        warnaSelector->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Warna 1", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Warna 2", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Warna 3", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Warna 4", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Warna 5", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Warna 6", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Warna 7", Q_NULLPTR)
        );
        labelWarna1->setText(QString());
        label->setText(QApplication::translate("MainWindow", "Hue Minimum", Q_NULLPTR));
        hMinVal1->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_2->setText(QApplication::translate("MainWindow", "Hue Maksimum", Q_NULLPTR));
        hMaxVal1->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label_5->setText(QApplication::translate("MainWindow", "Saturation Minimum", Q_NULLPTR));
        sMinVal1->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_6->setText(QApplication::translate("MainWindow", "Saturation Maximum", Q_NULLPTR));
        sMaxVal1->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label_3->setText(QApplication::translate("MainWindow", "Value Minimum", Q_NULLPTR));
        vMinVal1->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_4->setText(QApplication::translate("MainWindow", "Value Maksimum", Q_NULLPTR));
        vMaxVal1->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label_8->setText(QApplication::translate("MainWindow", "Erode", Q_NULLPTR));
        erodeVal1->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_7->setText(QApplication::translate("MainWindow", "Dilate", Q_NULLPTR));
        dilateVal1->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        labelWarna2->setText(QString());
        label_25->setText(QApplication::translate("MainWindow", "Hue Minimum", Q_NULLPTR));
        hMinVal2->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_26->setText(QApplication::translate("MainWindow", "Hue Maksimum", Q_NULLPTR));
        hMaxVal2->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label_27->setText(QApplication::translate("MainWindow", "Saturation Minimum", Q_NULLPTR));
        sMinVal2->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_28->setText(QApplication::translate("MainWindow", "Saturation Maximum", Q_NULLPTR));
        sMaxVal2->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label_29->setText(QApplication::translate("MainWindow", "Value Minimum", Q_NULLPTR));
        vMinVal2->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_30->setText(QApplication::translate("MainWindow", "Value Maksimum", Q_NULLPTR));
        vMaxVal2->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label_31->setText(QApplication::translate("MainWindow", "Erode", Q_NULLPTR));
        erodeVal2->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_32->setText(QApplication::translate("MainWindow", "Dilate", Q_NULLPTR));
        dilateVal2->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        labelWarna3->setText(QString());
        label_9->setText(QApplication::translate("MainWindow", "Hue Minimum", Q_NULLPTR));
        hMinVal3->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_10->setText(QApplication::translate("MainWindow", "Hue Maksimum", Q_NULLPTR));
        hMaxVal3->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label_11->setText(QApplication::translate("MainWindow", "Saturation Minimum", Q_NULLPTR));
        sMinVal3->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_12->setText(QApplication::translate("MainWindow", "Saturation Maximum", Q_NULLPTR));
        sMaxVal3->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label_13->setText(QApplication::translate("MainWindow", "Value Minimum", Q_NULLPTR));
        vMinVal3->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_14->setText(QApplication::translate("MainWindow", "Value Maksimum", Q_NULLPTR));
        vMaxVal3->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label_15->setText(QApplication::translate("MainWindow", "Erode", Q_NULLPTR));
        erodeVal3->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_16->setText(QApplication::translate("MainWindow", "Dilate", Q_NULLPTR));
        dilateVal3->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        labelWarna4->setText(QString());
        label_33->setText(QApplication::translate("MainWindow", "Hue Minimum", Q_NULLPTR));
        hMinVal4->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_34->setText(QApplication::translate("MainWindow", "Hue Maksimum", Q_NULLPTR));
        hMaxVal4->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label_35->setText(QApplication::translate("MainWindow", "Saturation Minimum", Q_NULLPTR));
        sMinVal4->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_36->setText(QApplication::translate("MainWindow", "Saturation Maximum", Q_NULLPTR));
        sMaxVal4->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label_37->setText(QApplication::translate("MainWindow", "Value Minimum", Q_NULLPTR));
        vMinVal4->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_38->setText(QApplication::translate("MainWindow", "Value Maksimum", Q_NULLPTR));
        vMaxVal4->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label_39->setText(QApplication::translate("MainWindow", "Erode", Q_NULLPTR));
        erodeVal4->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_40->setText(QApplication::translate("MainWindow", "Dilate", Q_NULLPTR));
        dilateVal4->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        labelWarna5->setText(QString());
        label_41->setText(QApplication::translate("MainWindow", "Hue Minimum", Q_NULLPTR));
        hMinVal5->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_42->setText(QApplication::translate("MainWindow", "Hue Maksimum", Q_NULLPTR));
        hMaxVal5->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label_43->setText(QApplication::translate("MainWindow", "Saturation Minimum", Q_NULLPTR));
        sMinVal5->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_44->setText(QApplication::translate("MainWindow", "Saturation Maximum", Q_NULLPTR));
        sMaxVal5->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label_45->setText(QApplication::translate("MainWindow", "Value Minimum", Q_NULLPTR));
        vMinVal5->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_46->setText(QApplication::translate("MainWindow", "Value Maksimum", Q_NULLPTR));
        vMaxVal5->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label_47->setText(QApplication::translate("MainWindow", "Erode", Q_NULLPTR));
        erodeVal5->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_48->setText(QApplication::translate("MainWindow", "Dilate", Q_NULLPTR));
        dilateVal5->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        labelWarna5_2->setText(QString());
        label_56->setText(QApplication::translate("MainWindow", "Hue Minimum", Q_NULLPTR));
        hMinVal6->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_57->setText(QApplication::translate("MainWindow", "Hue Maksimum", Q_NULLPTR));
        hMaxVal6->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label_61->setText(QApplication::translate("MainWindow", "Saturation Minimum", Q_NULLPTR));
        sMinVal6->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_123->setText(QApplication::translate("MainWindow", "Saturation Maximum", Q_NULLPTR));
        sMaxVal6->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label_124->setText(QApplication::translate("MainWindow", "Value Minimum", Q_NULLPTR));
        vMinVal6->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_125->setText(QApplication::translate("MainWindow", "Value Maksimum", Q_NULLPTR));
        vMaxVal6->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label_126->setText(QApplication::translate("MainWindow", "Erode", Q_NULLPTR));
        erodeVal6->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_127->setText(QApplication::translate("MainWindow", "Dilate", Q_NULLPTR));
        dilateVal6->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        labelWarna5_3->setText(QString());
        label_128->setText(QApplication::translate("MainWindow", "Hue Minimum", Q_NULLPTR));
        hMinVal7->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_129->setText(QApplication::translate("MainWindow", "Hue Maksimum", Q_NULLPTR));
        hMaxVal7->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label_130->setText(QApplication::translate("MainWindow", "Saturation Minimum", Q_NULLPTR));
        sMinVal7->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_131->setText(QApplication::translate("MainWindow", "Saturation Maximum", Q_NULLPTR));
        sMaxVal7->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label_132->setText(QApplication::translate("MainWindow", "Value Minimum", Q_NULLPTR));
        vMinVal7->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_133->setText(QApplication::translate("MainWindow", "Value Maksimum", Q_NULLPTR));
        vMaxVal7->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label_134->setText(QApplication::translate("MainWindow", "Erode", Q_NULLPTR));
        erodeVal7->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_135->setText(QApplication::translate("MainWindow", "Dilate", Q_NULLPTR));
        dilateVal7->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        groupBox_13->setTitle(QApplication::translate("MainWindow", "PID 1", Q_NULLPTR));
        label_69->setText(QApplication::translate("MainWindow", "P", Q_NULLPTR));
        label_106->setText(QApplication::translate("MainWindow", "D", Q_NULLPTR));
        label_107->setText(QApplication::translate("MainWindow", "I", Q_NULLPTR));
        groupBox_14->setTitle(QApplication::translate("MainWindow", "PID 2", Q_NULLPTR));
        label_80->setText(QApplication::translate("MainWindow", "P", Q_NULLPTR));
        label_108->setText(QApplication::translate("MainWindow", "D", Q_NULLPTR));
        label_109->setText(QApplication::translate("MainWindow", "I", Q_NULLPTR));
        groupBox_15->setTitle(QApplication::translate("MainWindow", "PID 3", Q_NULLPTR));
        label_87->setText(QApplication::translate("MainWindow", "P", Q_NULLPTR));
        label_110->setText(QApplication::translate("MainWindow", "D", Q_NULLPTR));
        label_111->setText(QApplication::translate("MainWindow", "I", Q_NULLPTR));
        groupBox_16->setTitle(QApplication::translate("MainWindow", "Variable Misi 5", Q_NULLPTR));
        label_54->setText(QApplication::translate("MainWindow", "Batas Y", Q_NULLPTR));
        labelBarunastra1->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(tabCamera), QApplication::translate("MainWindow", "Camera", Q_NULLPTR));
#ifndef QT_NO_ACCESSIBILITY
        tabDroneConnection->setAccessibleName(QString());
#endif // QT_NO_ACCESSIBILITY
        imgDrone->setText(QString());
        labelPrediction->setText(QString());
        label_50->setText(QApplication::translate("MainWindow", "IP HP", Q_NULLPTR));
        label_51->setText(QApplication::translate("MainWindow", "Port HP", Q_NULLPTR));
        buttonConnectDrone->setText(QApplication::translate("MainWindow", "Connect", Q_NULLPTR));
        buttonDisconnectDrone->setText(QApplication::translate("MainWindow", "Disconnect", Q_NULLPTR));
        pushButtonTakePict->setText(QApplication::translate("MainWindow", "Take Pict", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tabDroneConnection), QApplication::translate("MainWindow", "Drone Communication", Q_NULLPTR));
        labelMapping->setText(QString());
        QTableWidgetItem *___qtablewidgetitem = tableWidgetWaypoint->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("MainWindow", "1", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidgetWaypoint->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("MainWindow", "2", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidgetWaypoint->verticalHeaderItem(0);
        ___qtablewidgetitem2->setText(QApplication::translate("MainWindow", "1", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidgetWaypoint->verticalHeaderItem(1);
        ___qtablewidgetitem3->setText(QApplication::translate("MainWindow", "2", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem4 = tableWidgetWaypoint->verticalHeaderItem(2);
        ___qtablewidgetitem4->setText(QApplication::translate("MainWindow", "3", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidgetWaypoint->verticalHeaderItem(3);
        ___qtablewidgetitem5->setText(QApplication::translate("MainWindow", "4", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem6 = tableWidgetWaypoint->verticalHeaderItem(4);
        ___qtablewidgetitem6->setText(QApplication::translate("MainWindow", "5", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem7 = tableWidgetWaypoint->verticalHeaderItem(5);
        ___qtablewidgetitem7->setText(QApplication::translate("MainWindow", "6", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem8 = tableWidgetWaypoint->verticalHeaderItem(6);
        ___qtablewidgetitem8->setText(QApplication::translate("MainWindow", "7", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem9 = tableWidgetWaypoint->verticalHeaderItem(7);
        ___qtablewidgetitem9->setText(QApplication::translate("MainWindow", "8", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem10 = tableWidgetWaypoint->verticalHeaderItem(8);
        ___qtablewidgetitem10->setText(QApplication::translate("MainWindow", "9", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem11 = tableWidgetWaypoint->verticalHeaderItem(9);
        ___qtablewidgetitem11->setText(QApplication::translate("MainWindow", "10", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem12 = tableWidgetWaypoint->verticalHeaderItem(10);
        ___qtablewidgetitem12->setText(QApplication::translate("MainWindow", "11", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem13 = tableWidgetWaypoint->verticalHeaderItem(11);
        ___qtablewidgetitem13->setText(QApplication::translate("MainWindow", "12", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem14 = tableWidgetWaypoint->verticalHeaderItem(12);
        ___qtablewidgetitem14->setText(QApplication::translate("MainWindow", "13", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem15 = tableWidgetWaypoint->verticalHeaderItem(13);
        ___qtablewidgetitem15->setText(QApplication::translate("MainWindow", "14", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem16 = tableWidgetWaypoint->verticalHeaderItem(14);
        ___qtablewidgetitem16->setText(QApplication::translate("MainWindow", "15", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem17 = tableWidgetWaypoint->verticalHeaderItem(15);
        ___qtablewidgetitem17->setText(QApplication::translate("MainWindow", "16", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem18 = tableWidgetWaypoint->verticalHeaderItem(16);
        ___qtablewidgetitem18->setText(QApplication::translate("MainWindow", "17", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem19 = tableWidgetWaypoint->verticalHeaderItem(17);
        ___qtablewidgetitem19->setText(QApplication::translate("MainWindow", "18", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem20 = tableWidgetWaypoint->verticalHeaderItem(18);
        ___qtablewidgetitem20->setText(QApplication::translate("MainWindow", "19", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem21 = tableWidgetWaypoint->verticalHeaderItem(19);
        ___qtablewidgetitem21->setText(QApplication::translate("MainWindow", "20", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem22 = tableWidgetWaypoint->verticalHeaderItem(20);
        ___qtablewidgetitem22->setText(QApplication::translate("MainWindow", "21", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem23 = tableWidgetWaypoint->verticalHeaderItem(21);
        ___qtablewidgetitem23->setText(QApplication::translate("MainWindow", "22", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem24 = tableWidgetWaypoint->verticalHeaderItem(22);
        ___qtablewidgetitem24->setText(QApplication::translate("MainWindow", "23", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem25 = tableWidgetWaypoint->verticalHeaderItem(23);
        ___qtablewidgetitem25->setText(QApplication::translate("MainWindow", "24", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem26 = tableWidgetWaypoint->verticalHeaderItem(24);
        ___qtablewidgetitem26->setText(QApplication::translate("MainWindow", "25", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem27 = tableWidgetWaypoint->verticalHeaderItem(25);
        ___qtablewidgetitem27->setText(QApplication::translate("MainWindow", "26", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem28 = tableWidgetWaypoint->verticalHeaderItem(26);
        ___qtablewidgetitem28->setText(QApplication::translate("MainWindow", "27", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem29 = tableWidgetWaypoint->verticalHeaderItem(27);
        ___qtablewidgetitem29->setText(QApplication::translate("MainWindow", "28", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem30 = tableWidgetWaypoint->verticalHeaderItem(28);
        ___qtablewidgetitem30->setText(QApplication::translate("MainWindow", "29", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem31 = tableWidgetWaypoint->verticalHeaderItem(29);
        ___qtablewidgetitem31->setText(QApplication::translate("MainWindow", "30", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem32 = tableWidgetWaypoint->verticalHeaderItem(30);
        ___qtablewidgetitem32->setText(QApplication::translate("MainWindow", "31", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem33 = tableWidgetWaypoint->verticalHeaderItem(31);
        ___qtablewidgetitem33->setText(QApplication::translate("MainWindow", "32", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem34 = tableWidgetWaypoint->verticalHeaderItem(32);
        ___qtablewidgetitem34->setText(QApplication::translate("MainWindow", "33", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem35 = tableWidgetWaypoint->verticalHeaderItem(33);
        ___qtablewidgetitem35->setText(QApplication::translate("MainWindow", "34", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem36 = tableWidgetWaypoint->verticalHeaderItem(34);
        ___qtablewidgetitem36->setText(QApplication::translate("MainWindow", "36", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem37 = tableWidgetWaypoint->verticalHeaderItem(35);
        ___qtablewidgetitem37->setText(QApplication::translate("MainWindow", "37", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem38 = tableWidgetWaypoint->verticalHeaderItem(36);
        ___qtablewidgetitem38->setText(QApplication::translate("MainWindow", "38", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem39 = tableWidgetWaypoint->verticalHeaderItem(37);
        ___qtablewidgetitem39->setText(QApplication::translate("MainWindow", "39", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("MainWindow", "Mouse Position", Q_NULLPTR));
        label_78->setText(QApplication::translate("MainWindow", "X :", Q_NULLPTR));
        label_79->setText(QApplication::translate("MainWindow", "Y :", Q_NULLPTR));
        groupBox_2->setTitle(QApplication::translate("MainWindow", "Tujuan", Q_NULLPTR));
        label_81->setText(QApplication::translate("MainWindow", "error tujuan", Q_NULLPTR));
        label_82->setText(QApplication::translate("MainWindow", "sudut tujuan", Q_NULLPTR));
        label_24->setText(QApplication::translate("MainWindow", "jarak", Q_NULLPTR));
        groupBox_12->setTitle(QApplication::translate("MainWindow", "Input Waypoint", Q_NULLPTR));
        label_104->setText(QApplication::translate("MainWindow", "Latt", Q_NULLPTR));
        label_105->setText(QApplication::translate("MainWindow", "Long", Q_NULLPTR));
        pushButtonInputWaypoint->setText(QApplication::translate("MainWindow", "Input", Q_NULLPTR));
        pushButtonSetWaypoint->setText(QApplication::translate("MainWindow", "Set Waypoint", Q_NULLPTR));
        groupBox_3->setTitle(QApplication::translate("MainWindow", "Load and Save", Q_NULLPTR));
        pushButtonSaveAsWaypoint->setText(QApplication::translate("MainWindow", "Save As", Q_NULLPTR));
        pushButtonSaveWaypoint->setText(QApplication::translate("MainWindow", "Save", Q_NULLPTR));
        pushButtonLoadWaypoint->setText(QApplication::translate("MainWindow", "Load", Q_NULLPTR));
        groupBox_19->setTitle(QApplication::translate("MainWindow", "Mission", Q_NULLPTR));
        pushButtonStartMission->setText(QApplication::translate("MainWindow", "Start Mission", Q_NULLPTR));
        pushButtonStopMission->setText(QApplication::translate("MainWindow", "Stop Mission", Q_NULLPTR));
        pushButtonReset->setText(QApplication::translate("MainWindow", "Reset", Q_NULLPTR));
        pushButtonRetry->setText(QApplication::translate("MainWindow", "Retry", Q_NULLPTR));
        pushButtonRetry2->setText(QApplication::translate("MainWindow", "Retry to Misi2", Q_NULLPTR));
        labelArahKapal->setText(QString());
        label_60->setText(QApplication::translate("MainWindow", "S", Q_NULLPTR));
        pushButtonEast->setText(QApplication::translate("MainWindow", "E", Q_NULLPTR));
        pushButtonSouth->setText(QApplication::translate("MainWindow", "S", Q_NULLPTR));
        pushButtonWest->setText(QApplication::translate("MainWindow", "W", Q_NULLPTR));
        pushButtonNorth->setText(QApplication::translate("MainWindow", "N", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("MainWindow", "Mapping", Q_NULLPTR));
        groupBox_4->setTitle(QApplication::translate("MainWindow", "Mission 1 Gate", Q_NULLPTR));
        label_49->setText(QApplication::translate("MainWindow", "waypoint", Q_NULLPTR));
        label_52->setText(QApplication::translate("MainWindow", "sudut", Q_NULLPTR));
        label_90->setText(QApplication::translate("MainWindow", "Speed", Q_NULLPTR));
        label_98->setText(QApplication::translate("MainWindow", "Stop", Q_NULLPTR));
        groupBox_5->setTitle(QApplication::translate("MainWindow", " Mission 2 Speed", Q_NULLPTR));
        label_59->setText(QApplication::translate("MainWindow", "waypoint", Q_NULLPTR));
        label_91->setText(QApplication::translate("MainWindow", "Speed", Q_NULLPTR));
        label_99->setText(QApplication::translate("MainWindow", "Stop", Q_NULLPTR));
        groupBox_6->setTitle(QApplication::translate("MainWindow", "Mission 3 Auto Dock", Q_NULLPTR));
        label_83->setText(QApplication::translate("MainWindow", "waypoint_1", Q_NULLPTR));
        label_95->setText(QApplication::translate("MainWindow", "Speed", Q_NULLPTR));
        label_100->setText(QApplication::translate("MainWindow", "Stop", Q_NULLPTR));
        label_70->setText(QApplication::translate("MainWindow", "Setpoint", Q_NULLPTR));
        label_72->setText(QApplication::translate("MainWindow", "counter", Q_NULLPTR));
        label_74->setText(QApplication::translate("MainWindow", "Speed_A", Q_NULLPTR));
        label_84->setText(QApplication::translate("MainWindow", "waypoint_2", Q_NULLPTR));
        lineEditStatusMisi3->setText(QApplication::translate("MainWindow", "waiting other mission...", Q_NULLPTR));
        label_114->setText(QApplication::translate("MainWindow", "Dock", Q_NULLPTR));
        label_115->setText(QApplication::translate("MainWindow", "Sudut", Q_NULLPTR));
        label_117->setText(QApplication::translate("MainWindow", "Pinger", Q_NULLPTR));
        label_116->setText(QApplication::translate("MainWindow", "Threshold", Q_NULLPTR));
        label_118->setText(QApplication::translate("MainWindow", "Max Pinger", Q_NULLPTR));
        label_121->setText(QApplication::translate("MainWindow", "frequency", Q_NULLPTR));
        groupBox_7->setTitle(QApplication::translate("MainWindow", "Mission 4 Find the Path", Q_NULLPTR));
        label_86->setText(QApplication::translate("MainWindow", "waypoint", Q_NULLPTR));
        comboBox_2->clear();
        comboBox_2->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "image processing", Q_NULLPTR)
         << QApplication::translate("MainWindow", "proximity sensor", Q_NULLPTR)
        );
        label_94->setText(QApplication::translate("MainWindow", "Speed", Q_NULLPTR));
        label_101->setText(QApplication::translate("MainWindow", "Stop", Q_NULLPTR));
        groupBox_8->setTitle(QApplication::translate("MainWindow", "Mission 5 Follow the Leader", Q_NULLPTR));
        label_88->setText(QApplication::translate("MainWindow", "waypoint", Q_NULLPTR));
        label_93->setText(QApplication::translate("MainWindow", "Speed", Q_NULLPTR));
        label_102->setText(QApplication::translate("MainWindow", "Stop", Q_NULLPTR));
        label_66->setText(QApplication::translate("MainWindow", "Speed_B", Q_NULLPTR));
        label_122->setText(QApplication::translate("MainWindow", "Setpoint", Q_NULLPTR));
        groupBox_9->setTitle(QApplication::translate("MainWindow", "Return to Home", Q_NULLPTR));
        label_89->setText(QApplication::translate("MainWindow", "waypoint", Q_NULLPTR));
        label_92->setText(QApplication::translate("MainWindow", "Speed", Q_NULLPTR));
        label_103->setText(QApplication::translate("MainWindow", "Stop", Q_NULLPTR));
        groupBox_10->setTitle(QApplication::translate("MainWindow", "Mission Status", Q_NULLPTR));
        groupBox_11->setTitle(QApplication::translate("MainWindow", "Navigation", Q_NULLPTR));
        label_58->setText(QApplication::translate("MainWindow", "Speed", Q_NULLPTR));
        label_96->setText(QApplication::translate("MainWindow", "Serv_Cam", Q_NULLPTR));
        label_55->setText(QApplication::translate("MainWindow", "Trim", Q_NULLPTR));
        label_73->setText(QApplication::translate("MainWindow", "Serv Cam2", Q_NULLPTR));
        groupBox_17->setTitle(QApplication::translate("MainWindow", "Sensor", Q_NULLPTR));
        pushButtonOpenPort->setText(QApplication::translate("MainWindow", "Open", Q_NULLPTR));
        pushButtonClosePort->setText(QApplication::translate("MainWindow", "Close", Q_NULLPTR));
        label_17->setText(QApplication::translate("MainWindow", "Lattitude", Q_NULLPTR));
        label_20->setText(QApplication::translate("MainWindow", "Longitude", Q_NULLPTR));
        label_21->setText(QApplication::translate("MainWindow", "Compass", Q_NULLPTR));
        label_22->setText(QApplication::translate("MainWindow", "SRF Tengah1", Q_NULLPTR));
        label_71->setText(QApplication::translate("MainWindow", "SRF Tengah2", Q_NULLPTR));
        label_75->setText(QApplication::translate("MainWindow", "SRF Kiri", Q_NULLPTR));
        label_76->setText(QApplication::translate("MainWindow", "SRF Kanan", Q_NULLPTR));
        label_77->setText(QApplication::translate("MainWindow", "Hydrophone Frequency", Q_NULLPTR));
        label_112->setText(QApplication::translate("MainWindow", "Amplitudo Kiri", Q_NULLPTR));
        label_113->setText(QApplication::translate("MainWindow", "Amplitudo Kanan", Q_NULLPTR));
        label_67->setText(QApplication::translate("MainWindow", "SRF Samping", Q_NULLPTR));
        groupBox_18->setTitle(QApplication::translate("MainWindow", "Output", Q_NULLPTR));
        label_18->setText(QApplication::translate("MainWindow", "Motor Kiri", Q_NULLPTR));
        label_19->setText(QApplication::translate("MainWindow", "Motor Kanan", Q_NULLPTR));
        label_23->setText(QApplication::translate("MainWindow", "Servo Kiri", Q_NULLPTR));
        label_53->setText(QApplication::translate("MainWindow", "Servo Kanan", Q_NULLPTR));
        label_68->setText(QApplication::translate("MainWindow", "Motor Tengah", Q_NULLPTR));
        groupBox_20->setTitle(QApplication::translate("MainWindow", "Connection to server", Q_NULLPTR));
        label_62->setText(QApplication::translate("MainWindow", "URL", Q_NULLPTR));
        label_97->setText(QApplication::translate("MainWindow", "IP", Q_NULLPTR));
        label_63->setText(QApplication::translate("MainWindow", "Port", Q_NULLPTR));
        label_64->setText(QApplication::translate("MainWindow", "Note: Isi salah satu url atau IP dan Port", Q_NULLPTR));
        btnStartConnServer->setText(QApplication::translate("MainWindow", "Start", Q_NULLPTR));
        btnStopConnServer->setText(QApplication::translate("MainWindow", "Stop", Q_NULLPTR));
        label_65->setText(QApplication::translate("MainWindow", "Course", Q_NULLPTR));
        groupBox_22->setTitle(QApplication::translate("MainWindow", "Mission 6 Slalom", Q_NULLPTR));
        label_85->setText(QApplication::translate("MainWindow", "waypoint", Q_NULLPTR));
        label_119->setText(QApplication::translate("MainWindow", "Stop", Q_NULLPTR));
        label_120->setText(QApplication::translate("MainWindow", "Speed", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("MainWindow", "Mission Planner", Q_NULLPTR));
        menuFIle->setTitle(QApplication::translate("MainWindow", "FIle", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
