/****************************************************************************
** Meta object code from reading C++ file 'serialconnection.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../serialconnection.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'serialconnection.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_SerialConnection_t {
    QByteArrayData data[20];
    char stringdata0[300];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SerialConnection_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SerialConnection_t qt_meta_stringdata_SerialConnection = {
    {
QT_MOC_LITERAL(0, 0, 16), // "SerialConnection"
QT_MOC_LITERAL(1, 17, 21), // "serial_kirim_data_SRF"
QT_MOC_LITERAL(2, 39, 0), // ""
QT_MOC_LITERAL(3, 40, 21), // "serial_kirim_data_GPS"
QT_MOC_LITERAL(4, 62, 23), // "serial_kirim_data_Hydro"
QT_MOC_LITERAL(5, 86, 23), // "serial_kirim_data_Drone"
QT_MOC_LITERAL(6, 110, 20), // "drone_status_changed"
QT_MOC_LITERAL(7, 131, 14), // "initSerPortGPS"
QT_MOC_LITERAL(8, 146, 14), // "initSerPortSRF"
QT_MOC_LITERAL(9, 161, 16), // "initSerPortHydro"
QT_MOC_LITERAL(10, 178, 16), // "initSerPortDrone"
QT_MOC_LITERAL(11, 195, 7), // "readGPS"
QT_MOC_LITERAL(12, 203, 7), // "readSRF"
QT_MOC_LITERAL(13, 211, 9), // "readHydro"
QT_MOC_LITERAL(14, 221, 9), // "readDrone"
QT_MOC_LITERAL(15, 231, 13), // "sendDatatoSTM"
QT_MOC_LITERAL(16, 245, 15), // "sendDatatoDrone"
QT_MOC_LITERAL(17, 261, 5), // "close"
QT_MOC_LITERAL(18, 267, 14), // "terima_kontrol"
QT_MOC_LITERAL(19, 282, 17) // "ubah_status_drone"

    },
    "SerialConnection\0serial_kirim_data_SRF\0"
    "\0serial_kirim_data_GPS\0serial_kirim_data_Hydro\0"
    "serial_kirim_data_Drone\0drone_status_changed\0"
    "initSerPortGPS\0initSerPortSRF\0"
    "initSerPortHydro\0initSerPortDrone\0"
    "readGPS\0readSRF\0readHydro\0readDrone\0"
    "sendDatatoSTM\0sendDatatoDrone\0close\0"
    "terima_kontrol\0ubah_status_drone"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SerialConnection[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    5,  104,    2, 0x06 /* Public */,
       3,    3,  115,    2, 0x06 /* Public */,
       4,    2,  122,    2, 0x06 /* Public */,
       5,    2,  127,    2, 0x06 /* Public */,
       6,    1,  132,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       7,    0,  135,    2, 0x0a /* Public */,
       8,    0,  136,    2, 0x0a /* Public */,
       9,    0,  137,    2, 0x0a /* Public */,
      10,    0,  138,    2, 0x0a /* Public */,
      11,    0,  139,    2, 0x0a /* Public */,
      12,    0,  140,    2, 0x0a /* Public */,
      13,    0,  141,    2, 0x0a /* Public */,
      14,    0,  142,    2, 0x0a /* Public */,
      15,    0,  143,    2, 0x0a /* Public */,
      16,    0,  144,    2, 0x0a /* Public */,
      17,    0,  145,    2, 0x0a /* Public */,
      18,    4,  146,    2, 0x0a /* Public */,
      19,    1,  155,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,    2,    2,    2,    2,    2,
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Float,    2,    2,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::Int,    2,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,    2,    2,    2,    2,
    QMetaType::Void, QMetaType::Int,    2,

       0        // eod
};

void SerialConnection::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        SerialConnection *_t = static_cast<SerialConnection *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->serial_kirim_data_SRF((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])),(*reinterpret_cast< int(*)>(_a[5]))); break;
        case 1: _t->serial_kirim_data_GPS((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3]))); break;
        case 2: _t->serial_kirim_data_Hydro((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 3: _t->serial_kirim_data_Drone((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 4: _t->drone_status_changed((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->initSerPortGPS(); break;
        case 6: _t->initSerPortSRF(); break;
        case 7: _t->initSerPortHydro(); break;
        case 8: _t->initSerPortDrone(); break;
        case 9: _t->readGPS(); break;
        case 10: _t->readSRF(); break;
        case 11: _t->readHydro(); break;
        case 12: _t->readDrone(); break;
        case 13: _t->sendDatatoSTM(); break;
        case 14: _t->sendDatatoDrone(); break;
        case 15: _t->close(); break;
        case 16: _t->terima_kontrol((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4]))); break;
        case 17: _t->ubah_status_drone((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (SerialConnection::*_t)(int , int , int , int , int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SerialConnection::serial_kirim_data_SRF)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (SerialConnection::*_t)(double , double , float );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SerialConnection::serial_kirim_data_GPS)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (SerialConnection::*_t)(int , int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SerialConnection::serial_kirim_data_Hydro)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (SerialConnection::*_t)(int , int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SerialConnection::serial_kirim_data_Drone)) {
                *result = 3;
                return;
            }
        }
        {
            typedef void (SerialConnection::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SerialConnection::drone_status_changed)) {
                *result = 4;
                return;
            }
        }
    }
}

const QMetaObject SerialConnection::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_SerialConnection.data,
      qt_meta_data_SerialConnection,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *SerialConnection::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SerialConnection::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_SerialConnection.stringdata0))
        return static_cast<void*>(const_cast< SerialConnection*>(this));
    return QObject::qt_metacast(_clname);
}

int SerialConnection::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 18;
    }
    return _id;
}

// SIGNAL 0
void SerialConnection::serial_kirim_data_SRF(int _t1, int _t2, int _t3, int _t4, int _t5)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)), const_cast<void*>(reinterpret_cast<const void*>(&_t5)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void SerialConnection::serial_kirim_data_GPS(double _t1, double _t2, float _t3)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void SerialConnection::serial_kirim_data_Hydro(int _t1, int _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void SerialConnection::serial_kirim_data_Drone(int _t1, int _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void SerialConnection::drone_status_changed(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}
QT_END_MOC_NAMESPACE
