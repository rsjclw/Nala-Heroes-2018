/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[69];
    char stringdata0[929];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 8), // "finished"
QT_MOC_LITERAL(2, 20, 0), // ""
QT_MOC_LITERAL(3, 21, 9), // "statusCam"
QT_MOC_LITERAL(4, 31, 7), // "sendHSV"
QT_MOC_LITERAL(5, 39, 9), // "updateHSV"
QT_MOC_LITERAL(6, 49, 11), // "changeSpeed"
QT_MOC_LITERAL(7, 61, 9), // "changePID"
QT_MOC_LITERAL(8, 71, 11), // "changePID_2"
QT_MOC_LITERAL(9, 83, 11), // "changePID_3"
QT_MOC_LITERAL(10, 95, 14), // "currentColorId"
QT_MOC_LITERAL(11, 110, 16), // "kontrol_waypoint"
QT_MOC_LITERAL(12, 127, 24), // "send_index_plot_waypoint"
QT_MOC_LITERAL(13, 152, 16), // "ubah_kontrol_PID"
QT_MOC_LITERAL(14, 169, 12), // "kirim_ke_STM"
QT_MOC_LITERAL(15, 182, 18), // "imageDroneRecieved"
QT_MOC_LITERAL(16, 201, 8), // "startCam"
QT_MOC_LITERAL(17, 210, 7), // "stopCam"
QT_MOC_LITERAL(18, 218, 15), // "changeSliderval"
QT_MOC_LITERAL(19, 234, 11), // "updateLabel"
QT_MOC_LITERAL(20, 246, 7), // "on_save"
QT_MOC_LITERAL(21, 254, 10), // "on_save_as"
QT_MOC_LITERAL(22, 265, 7), // "on_load"
QT_MOC_LITERAL(23, 273, 7), // "loadHSV"
QT_MOC_LITERAL(24, 281, 15), // "changeViewWarna"
QT_MOC_LITERAL(25, 297, 10), // "pidChanged"
QT_MOC_LITERAL(26, 308, 12), // "pidChanged_2"
QT_MOC_LITERAL(27, 321, 12), // "pidChanged_3"
QT_MOC_LITERAL(28, 334, 16), // "on_save_waypoint"
QT_MOC_LITERAL(29, 351, 16), // "on_load_waypoint"
QT_MOC_LITERAL(30, 368, 11), // "on_save_new"
QT_MOC_LITERAL(31, 380, 11), // "on_load_new"
QT_MOC_LITERAL(32, 392, 14), // "on_save_as_new"
QT_MOC_LITERAL(33, 407, 11), // "startSerial"
QT_MOC_LITERAL(34, 419, 10), // "stopSerial"
QT_MOC_LITERAL(35, 430, 11), // "showDataGPS"
QT_MOC_LITERAL(36, 442, 11), // "showDataSRF"
QT_MOC_LITERAL(37, 454, 13), // "showDataHydro"
QT_MOC_LITERAL(38, 468, 13), // "showDataDrone"
QT_MOC_LITERAL(39, 482, 15), // "updateDataKirim"
QT_MOC_LITERAL(40, 498, 18), // "takePictOnWaypoint"
QT_MOC_LITERAL(41, 517, 12), // "connectDrone"
QT_MOC_LITERAL(42, 530, 15), // "disconnectDrone"
QT_MOC_LITERAL(43, 546, 10), // "imageDrone"
QT_MOC_LITERAL(44, 557, 17), // "showMousePosition"
QT_MOC_LITERAL(45, 575, 7), // "QPoint&"
QT_MOC_LITERAL(46, 583, 3), // "pos"
QT_MOC_LITERAL(47, 587, 9), // "startplot"
QT_MOC_LITERAL(48, 597, 8), // "stopplot"
QT_MOC_LITERAL(49, 606, 11), // "setWaypoint"
QT_MOC_LITERAL(50, 618, 5), // "reset"
QT_MOC_LITERAL(51, 624, 5), // "retry"
QT_MOC_LITERAL(52, 630, 12), // "retrytomisi2"
QT_MOC_LITERAL(53, 643, 14), // "input_waypoint"
QT_MOC_LITERAL(54, 658, 16), // "setIndexWaypoint"
QT_MOC_LITERAL(55, 675, 12), // "left_clicked"
QT_MOC_LITERAL(56, 688, 13), // "right_clicked"
QT_MOC_LITERAL(57, 702, 18), // "ambil_olah_kontrol"
QT_MOC_LITERAL(58, 721, 18), // "ubah_posisi_camera"
QT_MOC_LITERAL(59, 740, 19), // "ubah_posisi_camera2"
QT_MOC_LITERAL(60, 760, 23), // "ubah_posisi_camera_misi"
QT_MOC_LITERAL(61, 784, 18), // "tampil_status_misi"
QT_MOC_LITERAL(62, 803, 10), // "paintEvent"
QT_MOC_LITERAL(63, 814, 8), // "startNet"
QT_MOC_LITERAL(64, 823, 7), // "stopNet"
QT_MOC_LITERAL(65, 831, 23), // "all_waypoint_geser_atas"
QT_MOC_LITERAL(66, 855, 23), // "all_waypoint_geser_kiri"
QT_MOC_LITERAL(67, 879, 24), // "all_waypoint_geser_kanan"
QT_MOC_LITERAL(68, 904, 24) // "all_waypoint_geser_bawah"

    },
    "MainWindow\0finished\0\0statusCam\0sendHSV\0"
    "updateHSV\0changeSpeed\0changePID\0"
    "changePID_2\0changePID_3\0currentColorId\0"
    "kontrol_waypoint\0send_index_plot_waypoint\0"
    "ubah_kontrol_PID\0kirim_ke_STM\0"
    "imageDroneRecieved\0startCam\0stopCam\0"
    "changeSliderval\0updateLabel\0on_save\0"
    "on_save_as\0on_load\0loadHSV\0changeViewWarna\0"
    "pidChanged\0pidChanged_2\0pidChanged_3\0"
    "on_save_waypoint\0on_load_waypoint\0"
    "on_save_new\0on_load_new\0on_save_as_new\0"
    "startSerial\0stopSerial\0showDataGPS\0"
    "showDataSRF\0showDataHydro\0showDataDrone\0"
    "updateDataKirim\0takePictOnWaypoint\0"
    "connectDrone\0disconnectDrone\0imageDrone\0"
    "showMousePosition\0QPoint&\0pos\0startplot\0"
    "stopplot\0setWaypoint\0reset\0retry\0"
    "retrytomisi2\0input_waypoint\0"
    "setIndexWaypoint\0left_clicked\0"
    "right_clicked\0ambil_olah_kontrol\0"
    "ubah_posisi_camera\0ubah_posisi_camera2\0"
    "ubah_posisi_camera_misi\0tampil_status_misi\0"
    "paintEvent\0startNet\0stopNet\0"
    "all_waypoint_geser_atas\0all_waypoint_geser_kiri\0"
    "all_waypoint_geser_kanan\0"
    "all_waypoint_geser_bawah"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      65,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      14,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  339,    2, 0x06 /* Public */,
       3,    1,  342,    2, 0x06 /* Public */,
       4,    9,  345,    2, 0x06 /* Public */,
       5,    0,  364,    2, 0x06 /* Public */,
       6,    1,  365,    2, 0x06 /* Public */,
       7,    3,  368,    2, 0x06 /* Public */,
       8,    3,  375,    2, 0x06 /* Public */,
       9,    3,  382,    2, 0x06 /* Public */,
      10,    1,  389,    2, 0x06 /* Public */,
      11,    3,  392,    2, 0x06 /* Public */,
      12,    1,  399,    2, 0x06 /* Public */,
      13,    3,  402,    2, 0x06 /* Public */,
      14,    4,  409,    2, 0x06 /* Public */,
      15,    0,  418,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      16,    0,  419,    2, 0x0a /* Public */,
      17,    0,  420,    2, 0x0a /* Public */,
      18,    0,  421,    2, 0x0a /* Public */,
      19,    0,  422,    2, 0x0a /* Public */,
      20,    0,  423,    2, 0x0a /* Public */,
      21,    0,  424,    2, 0x0a /* Public */,
      22,    0,  425,    2, 0x0a /* Public */,
      23,    0,  426,    2, 0x0a /* Public */,
      24,    0,  427,    2, 0x0a /* Public */,
      25,    0,  428,    2, 0x0a /* Public */,
      26,    0,  429,    2, 0x0a /* Public */,
      27,    0,  430,    2, 0x0a /* Public */,
      28,    0,  431,    2, 0x0a /* Public */,
      29,    0,  432,    2, 0x0a /* Public */,
      30,    0,  433,    2, 0x0a /* Public */,
      31,    0,  434,    2, 0x0a /* Public */,
      32,    0,  435,    2, 0x0a /* Public */,
      33,    0,  436,    2, 0x0a /* Public */,
      34,    0,  437,    2, 0x0a /* Public */,
      35,    3,  438,    2, 0x0a /* Public */,
      36,    5,  445,    2, 0x0a /* Public */,
      37,    2,  456,    2, 0x0a /* Public */,
      38,    2,  461,    2, 0x0a /* Public */,
      39,    0,  466,    2, 0x0a /* Public */,
      40,    1,  467,    2, 0x0a /* Public */,
      41,    0,  470,    2, 0x0a /* Public */,
      42,    0,  471,    2, 0x0a /* Public */,
      43,    1,  472,    2, 0x0a /* Public */,
      44,    1,  475,    2, 0x0a /* Public */,
      47,    0,  478,    2, 0x0a /* Public */,
      48,    0,  479,    2, 0x0a /* Public */,
      49,    0,  480,    2, 0x0a /* Public */,
      50,    0,  481,    2, 0x0a /* Public */,
      51,    0,  482,    2, 0x0a /* Public */,
      52,    0,  483,    2, 0x0a /* Public */,
      53,    0,  484,    2, 0x0a /* Public */,
      54,    1,  485,    2, 0x0a /* Public */,
      55,    0,  488,    2, 0x0a /* Public */,
      56,    0,  489,    2, 0x0a /* Public */,
      57,    7,  490,    2, 0x0a /* Public */,
      58,    1,  505,    2, 0x0a /* Public */,
      59,    1,  508,    2, 0x0a /* Public */,
      60,    2,  511,    2, 0x0a /* Public */,
      61,    2,  516,    2, 0x0a /* Public */,
      62,    0,  521,    2, 0x0a /* Public */,
      63,    0,  522,    2, 0x0a /* Public */,
      64,    0,  523,    2, 0x0a /* Public */,
      65,    0,  524,    2, 0x0a /* Public */,
      66,    0,  525,    2, 0x0a /* Public */,
      67,    0,  526,    2, 0x0a /* Public */,
      68,    0,  527,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,    2,    2,    2,    2,    2,    2,    2,    2,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Float, QMetaType::Float, QMetaType::Float,    2,    2,    2,
    QMetaType::Void, QMetaType::Float, QMetaType::Float, QMetaType::Float,    2,    2,    2,
    QMetaType::Void, QMetaType::Float, QMetaType::Float, QMetaType::Float,    2,    2,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Int,    2,    2,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Double,    2,    2,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,    2,    2,    2,    2,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Float,    2,    2,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,    2,    2,    2,    2,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QImage,    2,
    QMetaType::Void, 0x80000000 | 45,   46,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Float, QMetaType::Float, QMetaType::Float, QMetaType::Int,    2,    2,    2,    2,    2,    2,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->finished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->statusCam((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->sendHSV((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])),(*reinterpret_cast< int(*)>(_a[5])),(*reinterpret_cast< int(*)>(_a[6])),(*reinterpret_cast< int(*)>(_a[7])),(*reinterpret_cast< int(*)>(_a[8])),(*reinterpret_cast< int(*)>(_a[9]))); break;
        case 3: _t->updateHSV(); break;
        case 4: _t->changeSpeed((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->changePID((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3]))); break;
        case 6: _t->changePID_2((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3]))); break;
        case 7: _t->changePID_3((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3]))); break;
        case 8: _t->currentColorId((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->kontrol_waypoint((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 10: _t->send_index_plot_waypoint((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->ubah_kontrol_PID((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3]))); break;
        case 12: _t->kirim_ke_STM((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4]))); break;
        case 13: _t->imageDroneRecieved(); break;
        case 14: _t->startCam(); break;
        case 15: _t->stopCam(); break;
        case 16: _t->changeSliderval(); break;
        case 17: _t->updateLabel(); break;
        case 18: _t->on_save(); break;
        case 19: _t->on_save_as(); break;
        case 20: _t->on_load(); break;
        case 21: _t->loadHSV(); break;
        case 22: _t->changeViewWarna(); break;
        case 23: _t->pidChanged(); break;
        case 24: _t->pidChanged_2(); break;
        case 25: _t->pidChanged_3(); break;
        case 26: _t->on_save_waypoint(); break;
        case 27: _t->on_load_waypoint(); break;
        case 28: _t->on_save_new(); break;
        case 29: _t->on_load_new(); break;
        case 30: _t->on_save_as_new(); break;
        case 31: _t->startSerial(); break;
        case 32: _t->stopSerial(); break;
        case 33: _t->showDataGPS((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3]))); break;
        case 34: _t->showDataSRF((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])),(*reinterpret_cast< int(*)>(_a[5]))); break;
        case 35: _t->showDataHydro((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 36: _t->showDataDrone((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 37: _t->updateDataKirim(); break;
        case 38: _t->takePictOnWaypoint((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 39: _t->connectDrone(); break;
        case 40: _t->disconnectDrone(); break;
        case 41: _t->imageDrone((*reinterpret_cast< QImage(*)>(_a[1]))); break;
        case 42: _t->showMousePosition((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 43: _t->startplot(); break;
        case 44: _t->stopplot(); break;
        case 45: _t->setWaypoint(); break;
        case 46: _t->reset(); break;
        case 47: _t->retry(); break;
        case 48: _t->retrytomisi2(); break;
        case 49: _t->input_waypoint(); break;
        case 50: _t->setIndexWaypoint((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 51: _t->left_clicked(); break;
        case 52: _t->right_clicked(); break;
        case 53: _t->ambil_olah_kontrol((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< float(*)>(_a[4])),(*reinterpret_cast< float(*)>(_a[5])),(*reinterpret_cast< float(*)>(_a[6])),(*reinterpret_cast< int(*)>(_a[7]))); break;
        case 54: _t->ubah_posisi_camera((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 55: _t->ubah_posisi_camera2((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 56: _t->ubah_posisi_camera_misi((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 57: _t->tampil_status_misi((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 58: _t->paintEvent(); break;
        case 59: _t->startNet(); break;
        case 60: _t->stopNet(); break;
        case 61: _t->all_waypoint_geser_atas(); break;
        case 62: _t->all_waypoint_geser_kiri(); break;
        case 63: _t->all_waypoint_geser_kanan(); break;
        case 64: _t->all_waypoint_geser_bawah(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (MainWindow::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::finished)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::statusCam)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)(int , int , int , int , int , int , int , int , int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::sendHSV)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::updateHSV)) {
                *result = 3;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::changeSpeed)) {
                *result = 4;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)(float , float , float );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::changePID)) {
                *result = 5;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)(float , float , float );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::changePID_2)) {
                *result = 6;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)(float , float , float );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::changePID_3)) {
                *result = 7;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::currentColorId)) {
                *result = 8;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)(double , double , int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::kontrol_waypoint)) {
                *result = 9;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::send_index_plot_waypoint)) {
                *result = 10;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)(double , double , double );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::ubah_kontrol_PID)) {
                *result = 11;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)(int , int , int , int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::kirim_ke_STM)) {
                *result = 12;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::imageDroneRecieved)) {
                *result = 13;
                return;
            }
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 65)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 65;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 65)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 65;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::finished(bool _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MainWindow::statusCam(bool _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void MainWindow::sendHSV(int _t1, int _t2, int _t3, int _t4, int _t5, int _t6, int _t7, int _t8, int _t9)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)), const_cast<void*>(reinterpret_cast<const void*>(&_t5)), const_cast<void*>(reinterpret_cast<const void*>(&_t6)), const_cast<void*>(reinterpret_cast<const void*>(&_t7)), const_cast<void*>(reinterpret_cast<const void*>(&_t8)), const_cast<void*>(reinterpret_cast<const void*>(&_t9)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void MainWindow::updateHSV()
{
    QMetaObject::activate(this, &staticMetaObject, 3, Q_NULLPTR);
}

// SIGNAL 4
void MainWindow::changeSpeed(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void MainWindow::changePID(float _t1, float _t2, float _t3)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void MainWindow::changePID_2(float _t1, float _t2, float _t3)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void MainWindow::changePID_3(float _t1, float _t2, float _t3)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void MainWindow::currentColorId(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void MainWindow::kontrol_waypoint(double _t1, double _t2, int _t3)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void MainWindow::send_index_plot_waypoint(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void MainWindow::ubah_kontrol_PID(double _t1, double _t2, double _t3)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void MainWindow::kirim_ke_STM(int _t1, int _t2, int _t3, int _t4)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}

// SIGNAL 13
void MainWindow::imageDroneRecieved()
{
    QMetaObject::activate(this, &staticMetaObject, 13, Q_NULLPTR);
}
QT_END_MOC_NAMESPACE
