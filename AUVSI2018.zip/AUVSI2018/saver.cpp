#include "saver.h"

Saver::Saver(QObject *parent)
	: QObject(parent)
{

}

Saver::~Saver()
{

}
